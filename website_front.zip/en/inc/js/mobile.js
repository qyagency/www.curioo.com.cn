$(function(){
    //手风琴
    var isStartId = 1;
    $('.started_list').eq(0).find('.heng_box').animate({
        'height':'430px'
    },500)
    $('.started_list').eq(0).find('.started_c1').css({
        'backgroundColor':'#FF5959'
    })
    $('.started_list').click(function(){
        switch(parseInt(isStartId)){
            case 1:
                $('.started_list').eq(isStartId-1).find('.started_c1').css({
                    'backgroundColor':'#009ABF'
                })
                $('.started_list').eq(isStartId-1).find('.started_c1').removeClass('started_c1').addClass('started_c1_2')
                break;
            case 2:
                $('.started_list').eq(isStartId-1).find('.started_c1').css({
                    'backgroundColor':'#009ABF'
                })
                $('.started_list').eq(isStartId-1).find('.started_c1').removeClass('started_c1').addClass('started_c1_2')

                break;
            case 3:
                $('.started_list').eq(isStartId-1).find('.started_c1').css({
                    'backgroundColor':'#009ABF'
                })
                $('.started_list').eq(isStartId-1).find('.started_c1').removeClass('started_c1').addClass('started_c1_3')
                break;
        }
        $('.heng_box').eq(isStartId-1).animate({
            'height':'0px'
        },500)
         $(this).find('.heng_box').animate({
             'height':'430px'
         },500)

        isStartId = $(this).data('num');
        switch(parseInt(isStartId)){
            case 1:
                $(this).find('.started_c1_2').removeClass('started_c1_2').addClass('started_c1')
                $(this).find('.started_c1').css({
                    'backgroundColor':'#FF5959'
                })

                break;
            case 2:
                $(this).find('.started_c1_2').css({
                    'backgroundColor':'#FF5959'
                })
                $(this).find('.started_c1_2').removeClass('started_c1_2').addClass('started_c1')

                break;
            case 3:
                $(this).find('.started_c1_3').css({
                    'backgroundColor':'#FF5959'
                })
                $(this).find('.started_c1_3').removeClass('started_c1_3').addClass('started_c1')
                break;
        }
    })

  //news
    var mySwiper = new Swiper('.swiper-studio', {
        loop: true, // 循环模式选项
        autoplay:true,
        pagination: {
            el: '.swiper-pagination',
        },
        // 如果需要分页器
    })

    //reson
  var mySwiper1 = new Swiper('.swiper-container1', {
        loop: true, // 循环模式选项
        autoplay:true,
      slidesPerView: 1.7,
      spaceBetween: 30,
      freeMode: true,
    })
    //星球
    var curId=4,curName;nameArr=['小小外交官','小小领袖家','天生创意官','科技小达人'],nameArrEn = ['English Communication','Entrepreneur','Creative Design','Technology'];
    $('.ball').click(function () {
        if(en){
            curName = nameArrEn
        }else{
            curName = nameArr
        }
        var leave_right= $(this).css('right');
        var leave_top= $(this).css('top');
        var curSit = $(this).data('sit');
        $(this).animate({
            'top':'380px',
            'right':'141px',
            'width':'500px'
        },800);
        $('.ball_name'+curSit).html(curName[curId-1])
        $('.ball_name'+curSit).css({
            'opacity':0,
        });
        $('.ball_name'+curSit).animate({
            'opacity':1
        },800)
        $('.ball').eq(curId-1).data('sit',curSit);
        $('.ball').eq(curId-1).animate({
            'top':leave_top,
            'right':leave_right,
            'width':'300px'
        },800)
        curId = $(this).data('num');
        $('.ball_desc_title').html(curName[curId-1])
        $('.ball_desc_title').css({'opacity':0})
        $('.ball_desc_title').animate({
            'opacity':1
        },800)
        if(curId==1&&en){
            $('.ball_desc_title').css({
                'height':'200px'
            })
        }else{
            $('.ball_desc_title').css({
                'height':'120px'
            })
        }
    })
    //下拉


    $('.click_video_en').click(function(){
        $('#videoBox').removeClass('disNone')
    })
    $('#videoBox').click(function(){
        $('#videoBox').addClass('disNone')
    })
})