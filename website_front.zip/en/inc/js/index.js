$(function () {
    laydate.render({
        elem: '#book_date', //指定元素
        lang: 'en'
    });
    function joinImg(id, len, cg) {
        for (var i = 2; i <= len; i++) {
            $(id).append("<img  src='" + ROOT_URL + "/images/" + cg + "/" + i + ".png'/>")
        }
    }
    var cityData={
        CHINA:['Hong Kong'],
        MALAYSIA:['Kuala Lumpur'],
        OTHER:['OTHER']
    };
    // $('#c_country').change(function(){
    //     $('#c_province').html('')
    //     $('#c_province').append("<option>City</option>")
    //     if($('#c_country').val()=='CHINA'){
    //         for(var i=0;i<cityData['CHINA'].length;i++){
    //             $('#c_province').append("<option>"+cityData['CHINA'][i]+"</option>")
    //         }
    //     }else if($('#c_country').val()=='MALAYSIA'){
    //         for(var i=0;i<cityData['MALAYSIA'].length;i++){
    //             $('#c_province').append("<option>"+cityData['MALAYSIA'][i]+"</option>")
    //         }
    //     }else if($('#c_country').val()=='OTHER'){
    //         for(var i=0;i<cityData['MALAYSIA'].length;i++){
    //             $('#c_province').append("<option>"+cityData['OTHER'][i]+"</option>")
    //         }
    //     }
    // })

    $.ajax({
        url: 'https://www.curioo.com.cn/backend/StudioWeb/studioLocation',
        type: 'post',
        data: {
            uid: UID,
            lang: 'en',
        },
        success: function (res) {
            var countryData=[];
            for(var c in res.data){
                countryData[c] = [];
                for(var b =0;b<res.data[c].length;b++){
                    if (countryData[c].indexOf(res.data[c][b].filter_city) < 0) {
                        console.log('in')
                        countryData[c].push(res.data[c][b].filter_city)
                    }
                }
            }
            // console.log(res.data);
            // console.log(countryData);
            if (countryData) {
                for(var c in countryData){
                    $('#c_country').append("<option>" + c + "</option>")
                }

            }
            $('#c_country').append("<option>" + "OTHER" + "</option>")

            $('#c_country').change(function () {
                $('#c_province').html('')
                $('#c_province').append("<option>City</option>")
                var cityData = countryData[$('#c_country').val()]
                if (cityData) {
                    for (var a = 0; a < cityData.length; a++) {
                        $('#c_province').append("<option>" + cityData[a] + "</option>")
                    }
                }
                $('#c_province').append("<option>" + "OTHER" + "</option>")


            })

        }
    })

    joinImg('#planet1', 32, 'cg1')
    joinImg('#planet2', 44, 'cg2')
    joinImg('#planet3', 34, 'cg3')
    joinImg('#planet4', 63, 'cg4')
    var objArr = {};

    function playCar(id, len, timeId, num) {
        objArr[timeId] = setInterval(function () {
            $(id).find('img').css({
                'opacity': 0
            })
            $(id).find('img').eq(num - 1).css({
                'opacity': 1
            })
            if (num >= len) {
                num = 1
            } else {
                num++;
            }
        }, 100)
    }

    loadImg('#planet1', 30, 0, function () {
        playCar('#planet1', 32, 'cg1', 0)
    })
    loadImg('#planet2', 42, 0, function () {
        playCar('#planet2', 43, 'cg2', 0)
    })
    loadImg('#planet3', 32, 0, function () {
        playCar('#planet3', 33, 'cg3', 0)
    })
    loadImg('#planet4', 61, 0, function () {
        playCar('#planet4', 62, 'cg4', 0)
    })

    function loadImg(id, num, i, fn) {
        $(id).find('img').load(function () {
            i++;
            if (i > num) {
                fn()
            }
        })
    }

    $('.started_list').eq(0).animate({
        'width': '9.36rem',
    }, 500);
    $('.started_list').eq(0).css({
        'backgroundColor': '#67CFE3'
    });
    $('.started_list').eq(0).find('.started_c1').animate({
        'width': '6rem',
    }, 500, function () {
        $('.started_list').eq(0).find('.started_c1').animate({
            'marginTop': '-0.30rem'
        }, 200)
    })
    $('.started_list').eq(0).find('.started_c1').css({
        'backgroundColor': '#FF5959'
    }, 500)
    $('.started_list').eq(0).find('.started_big').hide()
    $('.started_list').eq(0).find('.started_big_en').hide()
    $('.started_list').eq(0).find('.heng_box').show()
    $('.started_list').eq(1).find('.heng_box').hide()
    $('.started_list').eq(2).find('.heng_box').hide()
    //轮播


    //点击视频
    $('.click_video').click(function () {
        $('#videoBox').removeClass('disNone')
    })
    $('.click_video_en').click(function () {
        $('#videoBox').removeClass('disNone')
    })
    $('.closeVideo').click(function () {
        $('#videoBox').addClass('disNone');
        $('#video')[0].pause();
    })
    //切换语言
    var isClose = true, isCloseEn = true;
    $('.menu_big_xia').click(function () {
        if (isClose) {
            isClose = false
            $('.menu_small').animate({
                'height': '3.10rem'
            }, 500)
        } else {
            isClose = true
            $('.menu_small').animate({
                'height': '0rem'
            }, 500)
        }

    })

    $('.menu_big_xia_en').click(function () {
        if (isCloseEn) {
            isCloseEn = false
            $('.menu_small').animate({
                'height': '3.10rem'
            }, 500)
        } else {
            isCloseEn = true
            $('.menu_small').animate({
                'height': '0rem'
            }, 500)
        }

    })
    //目录
    $('.menu').click(function () {
        $('#menu_box').animate({
            'width': '5.20rem'
        }, 500)
    })
    $('.close').click(function () {
        $('#menu_box').animate({
            'width': '0rem'
        }, 500)
    })

    //星球
    var curId = 4, canClick = true, curName, nameArr = ['小小外交官', '小小领袖家', '天生创意官', '科技小达人'],
        nameArrEn = ['English Communication', 'Entrepreneur', 'Creative Design', 'Technology'];
    $('.ball').mouseover(function () {
        for (var m = 1; m < 5; m++) {
            $('.man' + m).animate({
                'opacity': 0
            })
        }
        curId = $(this).data('num');
        curName = nameArrEn
        $('.ball').removeClass('scaleBall')
        $('#planet' + curId).addClass('scaleBall')
        $('.ball_desc_title').html(curName[curId - 1])
        var colorArr = ["#FFC5CD", "#67CFE3", "#FF5959", "#F7ED37"]
        $('.ball_desc_title').css({
            'opacity': 0,
            'color': colorArr[curId - 1]
        })
        $('.ball_desc_title').animate({
            'opacity': 1
        }, 1000)
        $('.man' + curId).animate({
            'opacity': 1
        })
        switch (curId) {
            case 1:
                $('.ball_list_left').addClass('disNone')
                $('.ball_list_right').addClass('disNone')
                $('.ball_desc_desc').html('Globally recognized English language training program focused on developing communication skills and confidence')

                $('.ball_all').html("<li>Real world situations</li>" +
                    "<li>Active learning experiences</li>" +
                    "<li>Global Assessments – Cambridge Certification</li>" +
                    "<li>Communication skills focus:</li>" +
                    "<div>- speaking   - listening - reading - writing</div>")
                break
            case 2:
                $('.ball_list_left').addClass('disNone')
                $('.ball_list_right').addClass('disNone')
                $('.ball_desc_desc').html('Develop a deep understanding of the design thinking process to take an idea from development all the way to creation')
                $('.ball_all').html("<li>Concept Development</li>" +
                    "<li>Problem Solving</li>" +
                    "<li>Creativity and Idea Creation Skills Development</li>" +
                    "<li>Prototype Development</li>" +
                    "<li>Pitching and Public Speaking</li>" +
                    "<li>Basic Finance and Business Terminology</li>")
                break
            case 3:
                $('.ball_all').html('')
                $('.ball_list_left').removeClass('disNone')
                $('.ball_list_right').removeClass('disNone')
                $('.ball_desc_desc').html('Innovative course that combines art fundamentals of 2D and 3D art with digital technology and creative thinking processes')
                $('.ball_list_left').html("<li>Art experiences; drawing, painting, textiles, printing</li>" +
                    "<li>Digital Animation</li>" +
                    "<li>Electronic Music </li>")
                $('.ball_list_right').html("<li>Photography</li>" +
                    "<li>Multi-media</li>" +
                    "<li>3D Modelling</li>" +
                    "<li>Wearable Tech</li>")
                break
            case 4:
                $('.ball_all').html('')
                $('.ball_list_left').removeClass('disNone')
                $('.ball_list_right').removeClass('disNone')
                $('.ball_desc_desc').html('From mobile app development to website design, our topics prepare students for the growing technology industry')
                $('.ball_list_left').html(" <li>Technology Exploration</li>\n" +
                    "                <li>Coding with HTML, CSS and JavaScript  </li>\n" +
                    "                <li>Computational Thinking</li>\n" +
                    "                <li>Web Design & Development </li>")
                $('.ball_list_right').html(" <li>Data Analysis</li>\n" +
                    "                <li>Artificial Intelligences</li>\n" +
                    "                <li>Data Analysis</li>\n" +
                    "                <li>Game Development</li>")
                break
        }
    })

    $('.ball_more').click(function () {
        switch (parseInt(curId)) {
            case 1:
                window.location.href = 'coreEn.html?curId=' + curId
                break;
            case 2:
                window.location.href = 'coreEn.html?curId=' + curId
                break;
            case 3:
                window.location.href = 'coreEn.html?curId=4'
                break;
            case 4:
                window.location.href = 'coreEn.html?curId=3'
                break;

        }

    });

    function move(ele1, ele2, fn) {
        var fly = document.getElementById(ele1),//移动的元素
            cart = document.getElementById(ele2);//目标元素
        var parabola = funParabola(fly, cart, {
            speed: 500,// 每帧移动的像素大小
            curvature: 0.002,// 实际指焦点到准线的距离
            complete: function () {
                fn()
            },
            otherTransform: ''
        }).init();
    }

    var errorTxt1 = '',indexUid;

    $('#submit').click(function () {
        if ($('#name').val() == '') {
            errorTxt1 = 'Please entry your name'
        }
        if ($('#birth').val() == '') {
            errorTxt1 = errorTxt1 + '\n Please entry your Child Date of Birth'
        }
        if ($('#c_country').val() == 'Country') {
            errorTxt1 = errorTxt1 + '\n Please choose  your Country'
        }
        if ($('#c_province ').val() == 'City') {
            errorTxt1 = errorTxt1 + '\n Please choose your City '
        }
        if ($('#mobile ').val() == '') {
            errorTxt1 = errorTxt1 + '\n Please choose your Contact Number '
        }
        if ($('#email ').val() == '') {
            errorTxt1 = errorTxt1 + '\n Please choose your Contact Email'
        }
        if(!testCode){
            errorTxt1 = errorTxt1 + '\n Please perform human-machine authentication'
        }
        if (errorTxt1 == '') {
            $.ajax({
                url: 'https://www.curioo.com.cn/backend/WebApi/guestFormEn',
                type: 'post',
                data: {
                    uid: UID,
                    parent_name: $('#name').val(),
                    child_birth: $('#birth').val(),
                    user_country: $('#form_box #c_country').val(),
                    user_city: $('#form_box #c_province').val(),
                    user_mobile: $('#mobile').val(),
                    user_email: $('#email').val(),
                    channel: channel ? channel : '47dbfef43a111dd0'
                },
                success: function (res) {
                    $('.form_one').addClass('disNone');
                    $('.form_one_success').removeClass('disNone');
                    console.log(res)
                    indexUid = res.uid
                },
                error: function () {

                }
            });
        } else {
            alert(errorTxt1)
            errorTxt1 = ''
            return;
        }
    })
    $.ajax({
        url: 'https://www.curioo.com.cn/backend/NewsWeb/newsList',
        type: 'post',
        data: {
            uid: UID,
            lang: 'en'
        },
        success: function (res) {
            for (var i = 0; i < res.data.length; i++) {
                if (res.data[i].type == 1) {
                    var cover;
                    if (res.data[i].cover) {
                        cover = res.data[i].cover
                    } else {
                        cover = './inc/images/news_img.jpg'
                    }
                    $('.news_s_list1').append("  <div class=\"news_img_box\">\n" +
                        "                    <div class=\"news_city\">" + res.data[i].title + "</div>\n" +
                        "                    <img src=\"" + cover + "\" class=\"news_img\"/>\n" +
                        "                    <div class=\"news_img_desc\">" + res.data[i].desc + "</div>\n" +
                        "                </div>")
                } else if (res.data[i].type == 2) {
                    $('.news_s_list2').append("<div data-news='" + res.data[i].id + "' class=\"news_s_desc\">" + res.data[i].title + "</div>")

                } else if (res.data[i].type == 3) {
                    $('.news_s_list3').append("<div data-news='" + res.data[i].id + "' class=\"news_s_desc\">" + res.data[i].title + "</div>")
                }
            }
            $('.news_s_desc').click(function () {
                window.location.href = "newsDetailEn.html?newsId=" + $(this).data('news')
            })

        },
        error: function () {

        }
    });
    $.ajax({
        url: 'https://www.curioo.com.cn/backend/BannerWeb/bannerList',
        type: 'post',
        data: {
            type:'home',
            lang:'en'
        },
        success: function (res) {
            for(var i= 0;i<res.data.length;i++){
                $('.swiper-banner .swiper-wrapper').append(" <div class=\"swiper-slide\">\n" +
                    "            <a href='"+res.data[i].jump_url+"'><img class='web_cover' src=\""+res.data[i].web_cover+"\"/></a>\n" +
                    "        </div>")
            }
            var autoplay = false
            var loop = false
            if (res.data.length > 1) {
                autoplay = true
                loop = true
            }
            var mySwiper1 = new Swiper('.swiper-banner', {
                pagination: {
                    el: '.swiper-pagination',
                    clickable:true,
                },
                autoplay:autoplay,
                loop:loop
            })

        },
        error: function () {

        }
    });
    $.ajax({
        url: 'https://www.curioo.com.cn/backend/StudioWeb/studioCover',
        type: 'post',
        data:{
            lang:'en'
        },
        success:function (res) {
            var loop = true;
            if(res.code===200&&res.data.length){
                $('#studioCover').html('')
                for(var i=0;i<res.data.length;i++){
                    $('#studioCover').append(
                        '<div class="swiper-slide"><img class="studio_img" src="'+res.data[i]+'"/></div>'
                    )
                }
                if(res.data.length===1) {
                    loop = false;
                }
            }
            var mySwiper = new Swiper('.studio_box', {
                loop: loop, // 循环模式选项
                autoplay:true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable:true,
                }
                // 如果需要分页器
            })
        }
    })
    //8大理由
    var reasonArr = ['', 'CURIOO trains your child in the most important multi-disciplinary subjects.\n' +
    '                They learn the skills that are at the very forefront of innovation globally.', 'Our curriculum is based on developing the 21st century career skills that\n' +
    '                clearly align with these careers.', 'We have carefully integrated each of the subjects your child will study into\n' +
    '                highly engaging themes that support rapid learning and progression.', 'At CURIOO, we teach English for a reason. Combine children\'s interest with\n' +
    '                learning, learning will be greatly accelerated!', 'CURIOO has developed a world class learning behavior and aptitude assessment\n' +
    '                software: CBAS, The system provides parents and teachers with important real-time updates on the\n' +
    '                motivation, engagement and well-being of your child.', 'Our method uses international education structures that develop the\n' +
    '                leadership, English speaking and social skills to enable your child to interact with confidence.', 'The CURIOO Teachers, our Studios and digital learning environments have been\n' +
    '                specially designed to make learning the new skills fun and entertaining.', 'At CURIOO, we help parents with this decision through our Counselling\n' +
    '                services. Using the extensive data , we recommend the right schools – in your city or overseas.']
    var resColor = ['', '#FF5959', '#FF697F', '#FFA75A', '#FFC656', '#BAD254', '#40CBA6', '#40C1D2', '#66A6DC']
    $('.rea_box').mouseover(function () {
        var num = $(this).data('num');
        $('.res_content').attr('src',ROOT_URL+'/images/index/rea_en'+num+'.png')
        $('.res_tri').attr('src',ROOT_URL+'/images/index/tri'+num+'.png')

        var n = num - 1;
        $('.res_conten_bg').css({
            'transform': "rotate(" + 45 * n + "deg)"
        })


    })
    //预订
    $('.one_success_book').click(function () {
        $('.form_book').removeClass('disNone')
        $('.form_one_success').addClass('disNone')
    })
    //提交预订
    $('.one_success_submit').click(function(){
        errorTxt1 = ''
        if($('#book_date').val()==''){
            errorTxt1 = errorTxt1 + '\n Please choose date'
        }
        if($('#book_time').val()==''){
            errorTxt1 = errorTxt1 + '\n Please choose time'
        }
        if(errorTxt1 ==''){
            $.ajax({
                url: 'https://www.curioo.com.cn/backend/WebApi/makeAppointmentEn',
                type: 'post',
                data: {
                    uid: indexUid,
                    city:$('#c_city').val(),
                    subscribe_date: $('#book_date').val(),
                    subscribe_time: $('#book_time').val(),
                    channel: channel ? channel : '47dbfef43a111dd0'
                },
                success: function (res) {
                    $('.form_one_success').removeClass('disNone');
                    $('.one_success_book').addClass('disNone');
                    $('.one_success_title').addClass('disNone')
                    $('.form_book').addClass('disNone')

                },
                error: function () {

                }
            })
        }else{
            alert(errorTxt1)
        }
    })
});


/*var show_num = [];
draw(show_num);
function dj(){
    draw(show_num);
}
function draw(show_num) {
    var canvas_width=document.getElementById('canvas').clientWidth;
    var canvas_height=document.getElementById('canvas').clientHeight;
    var canvas = document.getElementById("canvas");//获取到canvas的对象，演员
    var context = canvas.getContext("2d");//获取到canvas画图的环境，演员表演的舞台
    canvas.width = canvas_width;
    canvas.height = canvas_height;
    var sCode = "1,2,3,4,5,6,7,8,9,0";
    var aCode = sCode.split(",");
    var aLength = aCode.length;//获取到数组的长度

    for (var i = 0; i <= 3; i++) {
        var j = Math.floor(Math.random() * aLength);//获取到随机的索引值
        var deg = Math.random() * 30 * Math.PI / 180;//产生0~30之间的随机弧度
        var txt = aCode[j];//得到随机的一个内容
        show_num[i] = txt;
        var ssx = $(window).width()/1920
        var x = 10 + i * 30*ssx;//文字在canvas上的x坐标
        var y = 25*ssx + Math.random() * 8;//文字在canvas上的y坐标
        var fontS = 28*ssx
        context.font = "bold "+fontS+"px 微软雅黑";
        context.translate(x, y);
        context.rotate(deg);

        context.fillStyle = randomColor();
        context.fillText(txt, 0, 0);

        context.rotate(-deg);
        context.translate(-x, -y);
    }
    for (var i = 0; i <= 5; i++) { //验证码上显示线条
        context.strokeStyle = randomColor();
        context.beginPath();
        context.moveTo(Math.random() * canvas_width, Math.random() * canvas_height);
        context.lineTo(Math.random() * canvas_width, Math.random() * canvas_height);
        context.stroke();
    }
    for (var i = 0; i <= 30; i++) { //验证码上显示小点
        context.strokeStyle = randomColor();
        context.beginPath();
        var x = Math.random() * canvas_width;
        var y = Math.random() * canvas_height;
        context.moveTo(x, y);
        context.lineTo(x + 1, y + 1);
        context.stroke();
    }
}
function randomColor() {//得到随机的颜色值
    var r = Math.floor(Math.random() * 256);
    var g = Math.floor(Math.random() * 256);
    var b = Math.floor(Math.random() * 256);
    return "rgb(" + r + "," + g + "," + b + ")";
}*/


