
$('.toForm').click(function(){

    $('#pop_form').removeClass('disNone')
})
$('.close_pop').click(function(){
    $('#pop_form').addClass('disNone')
})
// 菜单
var isCloseEn = true,isClose = true;
$('.menu_big_xia_en').click(function () {
    if(isCloseEn){
        isCloseEn = false
        $('.menu_small').animate({
            'height':'283px'
        },500)
    }else{
        isCloseEn = true
        $('.menu_small').animate({
            'height':'0px'
        },500)
    }

})
$('.menu_big_xia').click(function () {
    if(isClose){
        isClose = false
        $('.menu_small').animate({
            'height':'283px'
        },500)
    }else{
        isClose = true
        $('.menu_small').animate({
            'height':'0px'
        },500)
    }

})
$('.menu').click(function(){
    $('.cover').removeClass('disNone')
    $('#menu_box').animate({
        'height':'830px'
    },500,function () {
        $('.closeMenu').removeClass('disNone')
    })
})
$('.closeMenu').click(function(){
    $('.closeMenu').addClass('disNone')
    $('#menu_box').animate({
        'height':'0px'
    },500,function(){
        $('.cover').addClass('disNone')
    })
})

//选择年级
var lastId,arr=[
    {
        x:23,
        y:100,
        name:'KD'
    },{
        x:88,
        y:150,
        name:'1'
    },{
        x:157,
        y:108,
        name:'2'
    },{
        x:231,
        y:151,
        name:'3'
    },{
        x:298,
        y:193,
        name:'4'
    },{
        x:374,
        y:150,
        name:'5'
    },{
        x:443,
        y:103,
        name:'6'
    },{
        x:517,
        y:153,
        name:'7+'
    }];
$('.n1').click(function(){
    $('.grade_num').removeClass('disNone')
    var a = $(this).data('num');
    $('.grade_num').html(arr[a-1].name)
    $('.grade_num').css({
        'left':arr[a-1].x+'px',
        'top':arr[a-1].y+'px'
    })
    if(lastId){
        $('.n1').eq(lastId-1).find('.a1').html(arr[lastId-1].name)
    }
    $('.n1').eq(lastId-1).removeClass('up').addClass('down')
    $('.n1').eq(lastId-1).find('.a1').removeClass('a1Ac')
    $('.n1').eq(lastId-1).find('.a2').removeClass('a2Ac')
    $('.n1').eq(lastId-1).find('.a3').removeClass('a3Ac')
    $(this).removeClass('down').addClass('up')
    lastId =$(this).data('num');
    $(this).find('.a1').addClass('a1Ac')
    $(this).find('.a1').html('')
    $(this).find('.a2').addClass('a2Ac')
    $(this).find('.a3').addClass('a3Ac')
})