var en = true;
var UID= _getCookie('uid');
if (!UID) {
    UID = new Date().getTime() + Math.floor((1000 + Math.random() * 9000));
    _setCookie('uid', UID, Math.pow(999, 2))
}
/**
 * 设置cookieId
 */
 function _setCookie(c_name, value, expiredays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString()) + ";path=/;"
 };
 //返回顶部
$(window).scroll(function() {
    if ($(window).scrollTop() > 600) {
        $(".back_top").fadeIn(200);
    } else {
        $(".back_top").fadeOut(200);
    }
});

/**
 * 获取cookieId
 */
function _getCookie(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) {
                c_end = document.cookie.length;
            }
            return unescape(document.cookie.substring(c_start, c_end));
        }
    }
    return "";
};

var EventUtil = {
    // 娣诲姞浜嬩欢鐩戝惉
    add: function (element, type, callback) {

        if (element.addEventListener) {
            element.addEventListener(type, callback, false);
        } else if (element.attachEvent) {
            element.attachEvent('on' + type, callback);
        } else {
            element['on' + type] = callback;
        }
    }
};
EventUtil.add(window,'resize',function(e){
    setHtmlFontSize();
});
function getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg); //匹配目标参数
    if (r != null) return (r[2]);
    return null; //返回参数值
};
var channel;
channel = getUrlParam('channel')
if(!channel){
    channel = _getCookie('channel')
}
_setCookie('channel', channel, Math.pow(999, 2))
function setHtmlFontSize() {
    deviceWidth = document.documentElement.clientWidth > 1920 ? 1920 : document.documentElement.clientWidth;
    deviceWidth = document.documentElement.clientWidth < 1000 ? 1000 : document.documentElement.clientWidth;
    document.getElementsByTagName('html')[0].style.cssText = 'font-size:' + deviceWidth / 19.2 + 'px !important';
    ratio=deviceWidth / 19.2;
    $('.section-1').css('height',document.documentElement.clientHeight)
};
setHtmlFontSize();

function regphone(str) {//电话号码
    var reg = /^1\d{10}$/;
    if (reg.test(str)) {
        return true;
    } else {
        return false;
    }
}
//选择年级
var lastId,arr=[
    {
        x:-5.87,
        y:1.4,
        name:'KD1'
    },{
        x:-4.59,
        y:1.97,
        name:'KD2'
    },{
        x:-3.12,
        y:1.4,
        name:'1'
    },{
        x:-1.63,
        y:1.98,
        name:'2'
    },{
        x:-0.39,
        y:2.5,
        name:'3'
    },{
        x:1.14,
        y:1.99,
        name:'4'
    },{
        x:2.44,
        y:1.38,
        name:'5'
    },{
        x:4.14,
        y:2.04,
        name:'6'
    }];
var chooseId;
$('.grade_num').removeClass('disNone')
var a = 1;
chooseId = 1;
$('.grade_num').css({
    'top':arr[a-1].y+'rem',
    'marginLeft':arr[a-1].x+'rem'
})
if(lastId){
    $('.n1').eq(lastId-1).find('.a1').html(arr[lastId-1].name)
    $('.n1').eq(lastId-1).removeClass('up').addClass('down')
    $('.n1').eq(lastId-1).find('.a1').removeClass('a1Ac')
    $('.n1').eq(lastId-1).find('.a2').removeClass('a2Ac')
    $('.n1').eq(lastId-1).find('.a3').removeClass('a3Ac')
}
lastId =1;
$('.n1').eq(0).removeClass('down').addClass('up')
$('.n1').eq(0).find('.a1').addClass('a1Ac')
$('.n1').eq(0).find('.a1').html('')
$('.n1').eq(0).find('.a2').addClass('a2Ac')
$('.n1').eq(0).find('.a3').addClass('a3Ac')
$('.n1').mouseover(function(){
    $('.grade_num').removeClass('disNone')
    var a = $(this).data('num');
    chooseId = $(this).data('num');
    $('.grade_num').css({
        'top':arr[a-1].y+'rem',
        'marginLeft':arr[a-1].x+'rem'
    })
    if(lastId){
        $('.n1').eq(lastId-1).find('.a1').html(arr[lastId-1].name)
    }
    $('.n1').removeClass('up').addClass('down')
    $('.n1').find('.a1').removeClass('a1Ac')
    $('.n1').find('.a2').removeClass('a2Ac')
    $('.n1').find('.a3').removeClass('a3Ac')
    $(this).removeClass('down').addClass('up')
    lastId =$(this).data('num');
    $(this).find('.a1').addClass('a1Ac')
    $(this).find('.a1').html('')
    $(this).find('.a2').addClass('a2Ac')
    $(this).find('.a3').addClass('a3Ac')
})

$('.ie_box').mouseover(function(){
    $('.ie_box').removeClass('ie_up')
    $('.ie_box').find('img').attr('src','./inc/images/index/ie.png')
    $('.ie_box').find('.t_txt').removeClass('disNone')
    $(this).addClass('ie_up')
    $(this).find('.t_txt').addClass('disNone')
    $(this).find('img').attr('src','./inc/images/index/ie_red.png')
    var a = $(this).data('num');
    chooseId = $(this).data('num');
    $('.grade_num').css({
        'top':arr[a-1].y+'rem',
        'marginLeft':arr[a-1].x+'rem'
    })
})

$('.close_pop').click(function(){
    $('#pop_form').addClass('disNone')
})
 var show_num1 = [];
draw1(show_num1);
function dj1(){
    draw1(show_num1);
}
function draw1(show_num) {
    var canvas_width=document.getElementById('canvas1').clientWidth;
    var canvas_height=document.getElementById('canvas1').clientHeight;
    var canvas = document.getElementById("canvas1");//获取到canvas的对象，演员
    var context = canvas.getContext("2d");//获取到canvas画图的环境，演员表演的舞台
    canvas.width = canvas_width;
    canvas.height = canvas_height;
    var sCode = "1,2,3,4,5,6,7,8,9,0";
    var aCode = sCode.split(",");
    var aLength = aCode.length;//获取到数组的长度
    for (var i = 0; i <= 3; i++) {
        var j = Math.floor(Math.random() * aLength);//获取到随机的索引值
        var deg = Math.random() * 30 * Math.PI / 180;//产生0~30之间的随机弧度
        var txt = aCode[j];//得到随机的一个内容
        show_num[i] = txt;
        var ssx = $(window).width()/1920
        var x = 10 + i * 30*ssx;//文字在canvas上的x坐标
        var y = 25*ssx + Math.random() * 8;//文字在canvas上的y坐标
        var fontS = 28*ssx
        context.font = "bold "+fontS+"px 微软雅黑";


        context.translate(x, y);
        context.rotate(deg);

        context.fillStyle = randomColor();
        context.fillText(txt, 0, 0);

        context.rotate(-deg);
        context.translate(-x, -y);
    }
    for (var i = 0; i <= 5; i++) { //验证码上显示线条
        context.strokeStyle = randomColor();
        context.beginPath();
        context.moveTo(Math.random() * canvas_width, Math.random() * canvas_height);
        context.lineTo(Math.random() * canvas_width, Math.random() * canvas_height);
        context.stroke();
    }
    for (var i = 0; i <= 30; i++) { //验证码上显示小点
        context.strokeStyle = randomColor();
        context.beginPath();
        var x = Math.random() * canvas_width;
        var y = Math.random() * canvas_height;
        context.moveTo(x, y);
        context.lineTo(x + 1, y + 1);
        context.stroke();
    }
}
function randomColor() {//得到随机的颜色值
    var r = Math.floor(Math.random() * 256);
    var g = Math.floor(Math.random() * 256);
    var b = Math.floor(Math.random() * 256);
    return "rgb(" + r + "," + g + "," + b + ")";
}

var errorTxt = '';
$('#submit_en').click(function(){
    var num = show_num1.join("");
    if($('#name1').val() ==''){
        errorTxt = 'Please entry your name'

    }
    if($('#mobile1').val()==''){
        errorTxt = errorTxt+"\n Please enter your phone number"
    }
    if($('#city1').val() =='please choose'){
        errorTxt = errorTxt+"\n Please choose  your city"

    }
    if($('#age1').val() =='please choose'){
         errorTxt = errorTxt+"\n Please choose  your child's age"

    }
    if(num!=$('#code1').val()){
         errorTxt = errorTxt+"\n Verification code error"

    }
    if(errorTxt ==''){
        var cityTxt;
        if($('#city1').val() =='ShenZhen'){
            cityTxt = '深圳'
        }else if($('#city1').val() =='HangZhou'){
            cityTxt = '杭州'
        }else{
            cityTxt = '其他'
        }
        $.ajax({
            url: 'https://www.curioo.com.cn/backend/WebApi/guestForm',
            type: 'post',
            data: {
                uid:UID,
                user_name:$('#name1').val(),
                user_mobile:$('#mobile1').val(),
                user_city:cityTxt,
                user_age:$('#age1').val(),
                channel:channel
            },
            success: function (res) {
               $('#pop_form .form_box').addClass('disNone');
               $('#pop_form .form_box1').addClass('disNone');
               $('#submit_en').addClass('disNone');
               $('.success_pop').removeClass('disNone')
            },
            error: function () {

            }
        });
    }else{
        alert(errorTxt)
        errorTxt = ''
        return
    }
})
var isSub = false;
$('.sub_email').click(function(){
    if(!isSub){
        if($('.input_email').val()==''){
            alert('please enter email')
            return
        }else{
            isSub = true
            $.ajax({
                url: 'https://www.curioo.com.cn/backend/WebApi/email',
                type: 'post',
                data: {
                    uid:UID,
                    email:$('.input_email').val(),
                    channel:channel

                },
                success: function (res) {
                    isSub = false;
                   $('#success_pop').removeClass('disNone')
                },
                error: function () {

                }
            });

        }
    }
})

$('.grade_num').click(function(){
    window.location.href='./gradeEn.html?chooseId='+chooseId
})
$('.n1').click(function () {
    window.location.href='./gradeEn.html?chooseId='+chooseId
})


function isIE() { //ie?
    if (!!window.ActiveXObject || "ActiveXObject" in window)
        return true;
    else
        return false;
}
$('#connectBox').load('./inc/layout/sidebar.html',function () {
  /*  $('.connect_click').click(function(){
        $('#pop_form').removeClass('disNone')
        draw1(show_num1);
    })*/
    laydate.render({
        elem: '#connect_date', //指定元素
        lang: 'en'
    });
    var isActive = false;
    $('.sidebar-text').on('mouseover',function (e) {
        isActive = true;
        $('.connectStart').animate({
            'right':'100%',
            'opacity':1
        })
        $('.connectContent').css({
            'width':'2.93rem',
            'z-index':'1000'
        })
        $('#connect').animate({
            'left': 0,
            'opacity':1,
        },function(){

        })

        e.stopPropagation();
    });
    $('.sidebar-text').on('click',function (e) {
        if(isActive){
            $('.connectStart').animate({
                'right':'0',
                'opacity':1,
            })
            $('#connect').animate({
                'left': '100%',
                'opacity':0,
            },function(){
                $('.connectContent').css({
                    'width':'0',
                    'z-index':'100'
                })
            })

        }

        isActive = false;
        e.stopPropagation();
    });
    //提交
    var indexUid,errorTxt1='',cityData={
        CHINA:['Hong Kong '],
        MALAYSIA:['Kuala Lumpur'],
        OTHER:['OTHER']
    };
    $('#d_country').change(function(){
        $('#d_province').html('')
        $('#d_province').append("<option>City</option>")
        if($('#d_country').val()=='CHINA'){
            for(var i=0;i<cityData['CHINA'].length;i++){
                $('#d_province').append("<option>"+cityData['CHINA'][i]+"</option>")
            }
        }else if($('#d_country').val()=='MALAYSIA'){
            for(var i=0;i<cityData['MALAYSIA'].length;i++){
                $('#d_province').append("<option>"+cityData['MALAYSIA'][i]+"</option>")
            }
        }else if($('#d_country').val()=='OTHER'){
            for(var i=0;i<cityData['MALAYSIA'].length;i++){
                $('#d_province').append("<option>"+cityData['OTHER'][i]+"</option>")
            }
        }
    })
    $('.connect_submit').click(function(){
        if ($('#connect_name').val() == '') {
            errorTxt1 = 'Please entry your name'
        }
        if ($('#connect_birth').val() == '') {
            errorTxt1 = errorTxt1 + '\n Please entry your Child Date of Birth'
        }
        if ($('#d_country').val() == 'Country') {
            errorTxt1 = errorTxt1 + '\n Please choose  your Country'
        }
        if ($('#d_province ').val() == 'City') {
            errorTxt1 = errorTxt1 + '\n Please choose your City '
        }
        if ($('#connect_mobile ').val() == '') {
            errorTxt1 = errorTxt1 + '\n Please choose your Contact Number '
        }
        if ($('#connect_email ').val() == '') {
            errorTxt1 = errorTxt1 + '\n Please choose your Contact Email'
        }
        if (errorTxt1 == '') {
            $.ajax({
                url: 'https://www.curioo.com.cn/backend/WebApi/guestFormEn',
                type: 'post',
                data: {
                    uid: UID,
                    parent_name: $('#connect_name').val(),
                    child_birth: $('#connect_birth').val(),
                    user_country: $('#d_country').val(),
                    user_city: $('#d_province').val(),
                    user_mobile: $('#connect_mobile').val(),
                    user_email: $('#connect_email').val(),
                    channel: channel ? channel : '47dbfef43a111dd0'
                },
                success: function (res) {
                    $('#right_form').addClass('disNone')
                    $('#right_form_success').removeClass('disNone')
                    indexUid = res.uid
                },
                error: function () {

                }
            });
        } else {
            alert(errorTxt1)
            errorTxt1 = ''
            return;
        }


    })
    //预订
    $('.right_form_book').click(function(){
        $('#right_form_success').addClass('disNone')
        $('#right_book').removeClass('disNone')
    })
    $('.right_book_submit').click(function(){
        errorTxt1=''
        if( $('#connect_date').val()==''){
            errorTxt1 = errorTxt1 + '\n Please choose  date'
        }
        if( $('#connect_time').val()==''){
            errorTxt1 = errorTxt1 + '\n Please choose  time'
        }

        if(errorTxt1==''){
            $.ajax({
                url: 'https://www.curioo.com.cn/backend/WebApi/makeAppointmentEn',
                type: 'post',
                data: {
                    uid: indexUid,
                    city:$('#d_city').val(),
                    subscribe_date: $('#connect_date').val(),
                    subscribe_time: $('#connect_time').val(),
                    channel: channel ? channel : '47dbfef43a111dd0'
                },
                success: function (res) {
                    $('.right_book_input').addClass('disNone')
                    $('.book_success').removeClass('disNone')

                },
                error: function () {

                }
            })
        }else{
            alert(errorTxt1)
            return;
        }

    })
    $('.back_top').click(function(){
        $('body,html').animate({
                scrollTop: 0
            }, 500);
    })
})
$('#submitSuccess').load('./inc/layout/success.html',function(){
    $('.success_close').click(function(){
        $('#success_pop').addClass('disNone')
    })
})
$('.bottomBox').load('./inc/layout/bottom.html')
$('.header_box').load('./inc/layout/header.html',function () {
    var mapping = {
        'parentEn.html':'parentEn',
        'newsEn.html':'newsEn',
        'aboutEn.html':'aboutEn',
        'studioEn.html':'studioEn',
        'jobEn.html':'jobEn',
        'franchiseEn.html':'franchiseEn'
    }

    var u = window.location.href;
    var select = null;
    for(var k in mapping){
        if(u.indexOf(k)!==-1){
            select = mapping[k]
            break;
        }
    }
    if(select!==null){
        $('.'+select).addClass('selected')
    }
    $('#course_hover').mouseover(function(){
        $('#subNav').css({
            'display':'block'
        })
        $('.secondary').css({
            'display':'block'
        })
    })
    $('#subNav').mouseleave(function(){
        $('#subNav').css({
            'display':'none'
        })
        $('.secondary').css({
            'display':'none'
        })
    })


});


