<?php

namespace Curiookids\Controller;


/**新后台角色管理
 * Class RoleListController
 * @package Curiookids\Controller
 */
class RoleListController extends BaseController {
    private $db;
    private $field;
    public function _initialize() {
        parent::_initialize();
        $this->db = M('role_list');
        $this->field = ['role_name','role_group','default_role_id'];
    }
    public function createAction() {
        if($_POST){
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();
            $data['update_time'] = time();
            $this->db->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            $this->db->where($map)->setField('del_flg', 1);

            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['update_time'] = time();
            $this->db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $default_role_model = M('default_role');

        $map['del_flg'] = 0;
        $data = $this->db
            ->where($map)
            ->order('update_time desc')
            ->select();

        foreach ($data as $k=>$value){
            if ($value['role_group']) {
                $role_group = explode('|', $value['role_group']);
                $data[$k]['role_group'] = [];
                foreach ($role_group as $kk => $vv) {
                    $dd = explode(':', $vv);
                    $data[$k]['role_group'][$dd[0]] = explode(',', $dd[1]);
                }
            }
        }

        //角色权限
        $role_auth_map = ['del_flg'=>0];
        $role_auth_data = $default_role_model->where($role_auth_map)->select();
        $default_role_list = [];
        foreach($role_auth_data as $key=>$datum){
            $default_role_list[$key]['label'] = $datum['default_role_name'];
            $default_role_list[$key]['value'] = $datum['id'];
        }

        $rst['code'] = 200;
        $rst['data'] = $data;
        $rst['default_role_list'] = $default_role_list;
        $this->ajaxReturn($rst);
    }

}