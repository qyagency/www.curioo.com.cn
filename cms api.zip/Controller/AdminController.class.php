<?php

namespace Curiookids\Controller;


/** 新后台
 * Class AdminController
 * @package Curiookids\Controller
 */
class AdminController extends BaseController {
    private $ck = 'hbKaz6NtmrRxQdKS';

    public function getAdminAccountListAction() {
        $adminInfo = session('adminInfo');
        $map['del_flg'] = 0;
        //只显示该账号创建的数据 超管可查看全部数据
        if($adminInfo['admin_name'] != 'admin' && $adminInfo['admin_name'] != 'super_admin'){
            $map['created_by'] = $adminInfo['id'];
        }

        $db = M('admin');

        $list = $db->where($map)->select();
        $id_name_map = ['del_flg'=>0];
        $id_name = $db->where($id_name_map)->getField('id,show_name',true);
        $storeDb = M('store_info');
        $roleDb = M('role_list');
        foreach ($list as $k => $value) {
            $list[$k]['last_login_time'] = empty($value['last_login_time'])?'':date('Y-m-d H:i:s', $value['last_login_time']);
            if($value['store_id']){
                $list[$k]['store_name'] = $storeDb->where(array('id'=>$value['store_id']))->getField('store_name');
            }
            if($value['role_id']){
                $list[$k]['role_name'] = $roleDb->where(array('id'=>$value['role_id']))->getField('role_name');
            }
            if(isset($id_name[$value['created_by']])){
                $list[$k]['created_by_name'] = $id_name[$value['created_by']];
            }else{
                $list[$k]['created_by_name'] = '';
            }
        }

        $rst['code'] = 200;
        $rst['list'] = $list;

        $this->ajaxReturn($rst);
    }


    /*
     *  创建admin账号 TODO
     * */
    public function createAdminAccountAction() {
        if ($_POST) {
            $db = M('admin');
            $addList['admin_name'] = I('post.admin_name');
            if ($addList['admin_name']) {
                // 判断账号是否重复了
                $check = $db->where(array(
                    'admin_name' => $addList['admin_name'],
                    'del_flg' => 0
                ))->find();
                if (empty($check)) {
                    $addList['admin_password'] = $this->sha256(I('post.admin_pwd'));
                    $addList['create_time'] = time();
                    $addList['show_name'] = I('post.show_name');
                    $addList['role_id'] = I('post.role_id');
                    $addList['store_id'] = I('post.store_id');
                    $addList['can_download'] = I('post.can_download');
                    $addList['can_read_all'] = I('post.can_read_all');
                    $addList['del_flg'] = 0;
                    $addList['can_see_data'] = I('post.can_see_data');

                    $adminInfo = session('adminInfo');
                    $addList['created_by'] = $adminInfo['id'];
                    $addrst = $db->add($addList);

                    if ($addrst) {
                        //成功code
                        $rst["code"] = 200;
                    } else {
                        //成功code
                        $rst["code"] = 201;
                        $rst['msg'] = '创建失败,联系技术';
                    }
                } else {
                    $rst['code'] = 202;
                    $rst['msg'] = '账号已存在';
                }
                $this->ajaxReturn($rst);
            }
        }

    }

    /**
     * 更新账号
     */
    public function updateAdminAccountAction() {
        if ($_POST) {
            $db = M('admin');
            $map['id'] = I('post.id');
            $saveData['admin_password'] = $this->sha256(I('post.admin_pwd'));
            $saveData['update_time'] = time();
            $db->where($map)->save($saveData);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    /**
     * 修改密码
     */
    public function changePasswordAction() {

        if ($_POST) {
            $map['id'] = I('post.id');

            $save['admin_password'] = $this->sha256(I('post.admin_pwd'));
            $save['update_time'] = time();


            M('admin')->where($map)->save($save);

            //修改成功code
            $rst["code"] = 200;

            $this->ajaxReturn($rst);
        }

    }

    /**
     * 删除账号
     */
    public function deleteAdminAccountAction() {
        if ($_POST) {
            $db = M('admin');
            $map['id'] = I('post.id');
            $db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function updateRoleListAction() {
        if ($_POST) {
            $db = M('role');
            $data = I('post.data');
            $data = str_replace('&quot;', '"', $data);
            $data = json_decode($data, true);
//            dump($data);
//            die();
            $db->where('1')->delete();

            $db->addAll($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    /**
     * 获取权限列表
     */
    public function getRoleListAction() {
        $db = M('role');
        $data = $db->select();
        $output = array();
        $parent = array();
        $children = array();
        foreach ($data as $k => $value) {
            if ($value['parent_name'] == 'root_default') {
                $parent[] = $value;
            } else {
                $children[$value['parent_name']][] = array(
                    'name' => $value['role_name'],
                    'value' => $value['role_value']
                );
            }
        }
        foreach ($parent as $k => $value) {
            $parent_name = $value['role_name'];
            $output[] = array(
                'list' => $children[$parent_name],
                'default' => $value['role_value'],
                'name' => $parent_name,
                'check' => []
            );
        }

        $rst['code'] = 200;
        $rst['data'] = $output;

        $this->ajaxReturn($rst);
    }


    /**
     * 更新权限
     */
    public function updateRolesAction() {
        if ($_POST) {
            $db = M('admin');
            $map['admin_name'] = I('post.admin_name');
            $map['del_flg'] = 0;

            $data['role_group'] = I('post.role_group');

            $data['update_time'] = time();
            $updateRst = $db->where($map)->save($data);

            if ($updateRst) {
                $rst['code'] = 200;
            } else {
                $rst['code'] = 201;
                $rst['msg'] = '没保存上，联系技术';
            }

            $this->ajaxReturn($rst);
        }
    }
    /**
     * 更新用户角色
     */
    public function updateUserRoleAction() {
        if($_POST){
            $db = M('admin');
            $map['admin_name'] = I('post.admin_name');
            $map['del_flg'] = 0;

            $save['role_id'] = I('post.role_id');
            $save['show_name'] = I('post.show_name');
            $save['can_download'] = I('post.can_download');
            $save['can_read_all'] = I('post.can_read_all');
            $save['store_id'] = I('post.store_id');
            $save['update_time'] = time();
            $save['can_see_data'] = I('post.can_see_data');

            $db->where($map)->save($save);

            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    /**
     * 获取角色列表
     */
    public function getRoleForSelectAction() {
        $default_role_model = M('default_role');
        $role_list_model = M('role_list');


        /*$map['del_flg'] = 0;
        $data = M('role_list')->where($map)->field('id,role_name')->select();
        $out = [];
        foreach ($data as $k=>$value){
            $out[] = array(
                'label'=>$value['role_name'],
                'value'=>$value['id']
            );
        }*/

    /****查询可创建权限列表*****/

        //根据管理员role_id查询可创建的ids
        $admin_info = session('adminInfo');
        if($admin_info['show_name'] == 'admin' || $admin_info['show_name'] == 'super_admin'){
            $default_role_id = 1;
        }else{
            $role_id = $admin_info['role_id'];
            $default_role_id = $role_list_model->where(['id'=>$role_id])->getField('default_role_id');
        }

        $create_role_map = ['id'=>$default_role_id];
        $default_role_data = $default_role_model->where($create_role_map)->find();
        $create_role_ids = $default_role_data['create_role_list'];

        //查询可创建列表
        $create_role_list = [];
        if(!empty($create_role_ids)){
            $create_role_ids = explode(',',$create_role_ids);

            $create_role_map = [
                'default_role_id'=>array('in',$create_role_ids),
                'del_flg' => 0
            ];
            $create_role_data = $role_list_model->where($create_role_map)->select();

            foreach($create_role_data as $key=>$datum){
                $create_role_list[$key]['label'] = $datum['role_name'];
                $create_role_list[$key]['value'] = $datum['id'];
            }
        }

    /****查询数据可见权限列表*****/
        $edit_data_field = $default_role_data['edit_data_field'];
        $edit_data_field = explode(',',$edit_data_field);

        //如果该角色的数据权限在 self::EDIT_DATA_FIELD里 插入到edit_data
        $edit_data = [];
        foreach($edit_data_field as $item){
            if(isset(self::EDIT_DATA_FIELD[$item])){
                $edit_data[$item] = self::EDIT_DATA_FIELD[$item];
            }
        }

        $edit_data_rst = [];
        foreach($edit_data as $key=>$datum){
            $edit_data_rst[] = [
                'label' => $datum,
                'value' => (string)$key,
            ];
        }

        $rst['code'] = 200;
        $rst['data'] = $create_role_list;
        $rst['edit_data_field'] = $edit_data_rst;
        $this->ajaxReturn($rst);

    }





}