<?php

namespace Curiookids\Controller;


/**新后台门店管理
 * Class StudioController
 * @package Curiookids\Controller
 */
class StoreInfoController extends BaseController {
    private $db;
    private $field;
    public function _initialize() {
        parent::_initialize();
        $this->db = M('store_info');
        $this->field = ['area_id','store_name'];
    }
    public function createAction() {
        if($_POST){
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();
            $data['update_time'] = time();

            $map['store_name'] = $data['store_name'];
            $map['del_flg'] = 0;
            $find = $this->db->where($map)->find();
            if(empty($find)){
                $this->db->add($data);
                $rst['code'] = 200;
            }else{
                $rst['code'] = 201;
            }
//            $this->db->add($data);
//            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            $this->db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['update_time'] = time();
            $this->db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $data = $this->db->where($map)->order('update_time desc')->select();
        $areaDb = M('store_area');
        foreach ($data as $k=>$value){
            $data[$k]['area_name'] = $areaDb->where(array('id'=>$value['area_id']))->getField('area_name');
        }
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

    public function getOptionsAction() {
        $map['del_flg'] = 0;
        $data = M('store_area')->where($map)->select();
        $out = array();
        foreach ($data as $k=>$value){
            $out[] = array(
                'label'=>$value['area_name'],
                'value'=>$value['id']
            );
        }
        $rst['data'] = $out;
        $rst['code'] = 200;
        $this->ajaxReturn($rst);
    }

    public function getStoreOptionsAction() {
        $map['del_flg'] = 0;
        $data = M('store_info')->where($map)->select();
        $out = array();
        foreach ($data as $k=>$value){
            $out[] = array(
                'label'=>$value['store_name'],
                'value'=>$value['id']
            );
        }
        $rst['data'] = $out;
        $rst['code'] = 200;
        $this->ajaxReturn($rst);
    }

}