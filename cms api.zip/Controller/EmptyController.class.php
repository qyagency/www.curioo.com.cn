<?php
namespace Curiookids\Controller;

/**新后台用
 * Class EmptyController
 * @package Curiookids\Controller
 */
class EmptyController extends BaseController {

    public function _empty() {
        redirect(U('/'));
    }

}