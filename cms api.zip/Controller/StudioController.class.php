<?php

namespace Curiookids\Controller;


/**新后台studio用
 * Class StudioController
 * @package Curiookids\Controller
 */
class StudioController extends BaseController {
    public function createAction() {
        if($_POST){
            $db = M('studio');
            $data['cover'] = I('post.cover');
            $data['sort'] = I('post.sort');
            $data['lang'] = $_SERVER['HTTP_LANG'];
            $data['create_time'] = time();
            $data['update_time'] = time();
            $db->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $db = M('studio');
            $map['id'] = I('post.id');
            $db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $db = M('studio');
            $map['id'] = I('post.id');
            $save['cover'] = I('post.cover');
            $save['sort'] = I('post.sort');
            $save['update_time'] = time();
            $db->where($map)->save($save);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $map['lang'] = $_SERVER['HTTP_LANG'];
        $data = M('studio')->where($map)->order('sort desc')->select();
        foreach ($data as $k=>$value){
            $data[$k]['cover'] = empty($value['cover']) ? [] : [$value['cover']];
        }
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}