<?php

namespace Curiookids\Controller;


/**新后台用
 * Class StudioController
 * @package Curiookids\Controller
 */
class StudioLocationController extends BaseController {
    public function createAction() {
        if ($_POST) {
            $db = M('studio_location');
            $data['filter_city'] = I('post.filter_city');
            $data['filter_country'] = I('post.filter_country');
            $data['city'] = I('post.city');
            $data['address'] = I('post.address');
            $data['phone'] = I('post.phone');
            $data['cover'] = I('post.cover');
            $data['abroad'] = I('post.abroad');
            $data['sort'] = I('post.sort');
            $data['lang'] = $_SERVER['HTTP_LANG'];

            $lng = I('post.lng');
            $lat = I('post.lat');
            //存在经纬度就使用
            if(!empty($lng) && !empty($lat)){

                $data['lng'] = $lng;
                $data['lat'] = $lat;


            }else{
                if ($_SERVER['HTTP_LANG'] == 'en') {

                    $data['link'] = I('post.link');
                    //学习馆存在查询数据库的经纬度
                    if (!empty($data['link'])) {
                        $geo = M('studio_location')->where(array('id' => $data['link']))->find();
                        if (!empty($geo)) {
                            $data['lng'] = $geo['lng'];
                            $data['lat'] = $geo['lat'];
                        }
                    }
                } else {

                    $geo = $this->getLngLat($data['address']);
                    if (!empty($geo)) {
                        $data['lng'] = $geo['lng'];
                        $data['lat'] = $geo['lat'];
                    }

                }
            }


            $data['create_time'] = time();
            $data['update_time'] = time();
            $db->add($data);
            $rst['code'] = 200;
            $rst['geo'] = $geo;
            $this->ajaxReturn($rst);
        }
    }

    private function getLngLat($address) {
        $baseUrl = 'https://restapi.amap.com/v3/geocode/geo?address=' . $address . '&key=3a8d8db035b623c68ecf6c1f9ef20fd2';
        $data = json_decode($this->getCurl($baseUrl),true);
        if ($data['status'] == 1) {
            list($lng, $lat) = explode(',',$data['geocodes'][0]['location']);
            return array(
                'lng' => $lng,
                'lat' => $lat,
            );
        } else {
            return [];
        }
    }

    /**
     * @Notes:根据经纬度获取地址
     * @Author: 杭
     * @Date: 2020/7/15 13:47
     */
    private function getLocation($lng,$lat)
    {
        $baseUrl = 'https://restapi.amap.com/v3/geocode/regeo?location='.$lng.','.$lat.'&key=3a8d8db035b623c68ecf6c1f9ef20fd2';
        $data = json_decode($this->getCurl($baseUrl),true);
        if ($data['status'] == 1) {

            return array(
                'address' => $data['regeocode']['formatted_address'],
            );
        } else {
            return [];
        }

    }

    public function getLngLatAction() {
        $baseUrl = 'http://open.mapquestapi.com/geocoding/v1/address?key=dIYf55BdTyT4ohGhAcBv3g3oI4Ac20pZ&location=Shop 1 (Active Learning), 1/F Alto Residences,29 Tong Yin Street, Tseung Kwan O';
        $data = json_decode($this->getCurl($baseUrl),true);
        dump($data);
    }

    private function getCurl($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }


    public function deleteAction() {
        if ($_POST) {
            $db = M('studio_location');
            $map['id'] = I('post.id');
            $db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $db = M('studio_location');
            $map['id'] = I('post.id');
            $data['filter_country'] = trim(I('post.filter_country'));
            $data['filter_city'] = trim(I('post.filter_city'));
            $data['city'] = I('post.city');
            $data['address'] = I('post.address');
            $data['phone'] = I('post.phone');
            $data['cover'] = I('post.cover');
            $data['abroad'] = I('post.abroad');
            $data['sort'] = I('post.sort');

            $lng = I('post.lng');
            $lat = I('post.lat');

            //存在经纬度就使用
            if(!empty($lng) && !empty($lat)){

                $data['lng'] = $lng;
                $data['lat'] = $lat;

            }else{
                if ($_SERVER['HTTP_LANG'] == 'en') {
                    $data['link'] = I('post.link');
                    if (!empty($data['link'])) {
                        $geo = M('studio_location')->where(array('id' => $data['link']))->find();

                        $data['lng'] = $geo['lng'];
                        $data['lat'] = $geo['lat'];

                    }
                } else {

                    $geo = $this->getLngLat($data['address']);

                    $data['lng'] = $geo['lng'];
                    $data['lat'] = $geo['lat'];


                }
            }

            $data['update_time'] = time();
            $db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $map['lang'] = $_SERVER['HTTP_LANG'];

        $data = M('studio_location')->where($map)->order('sort desc')->select();
        foreach ($data as $k=>$value){
            $data[$k]['cover'] = [$value['cover']];
        }
        $map['lang'] = 'cn';
        $cnData = M('studio_location')->where($map)->field('id,city')->select();
        $option = [];
        foreach ($cnData as $k => $value) {
            $option[] = array(
                'label' => $value['city'],
                'value' => $value['id'],
            );
        }

        $rst['code'] = 200;
        $rst['data'] = $data;
        $rst['option'] = $option;
        $this->ajaxReturn($rst);
    }

}