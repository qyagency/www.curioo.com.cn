<?php

namespace Curiookids\Controller;

/** 新后台登录用
 * Class LoginController
 * @package Curiookids\Controller
 */

class LoginController extends BaseController {

    public function loginAction() {
        if ($_POST) {
            $map['admin_name'] = I('post.admin_name');
            $map['admin_password'] = $this->sha256(I('post.admin_pwd'));
            $map['del_flg'] = 0;

            $list = M('admin')->where($map)->find();
            if (!empty($list)) {
                $token = $this->sha256(time() . get_client_ip() . I('post.admin_name'));
                $save['last_login_ip'] = get_client_ip();
                $save['last_login_time'] = time();
                $save['token'] = $token;
                M('admin')->where($map)->save($save);
                //登录成功code
                $rst["code"] = 200;
                $rst['token'] = $token;
                $rst['id'] = $list['id'];
                // 一天缓存

                S($token, I('post.admin_name'), 60 * 60 * 24);
                session($token,I('post.admin_name'));
                $this->ajaxReturn($rst);
            } else {
                //登录失败code
                $rst["code"] = 201; //账号名或密码错误
                $rst['msg'] = '账号或者密码错误';
                $this->ajaxReturn($rst);
            }
        }else{
            die('error');
        }
    }
    public function getUserInfoAction() {
        $isLogin = session($_SERVER['HTTP_TOKEN']);
        if(!empty(session($_SERVER['HTTP_TOKEN']))){
            $isLogin = session($_SERVER['HTTP_TOKEN']);
        }else{
            $isLogin = S($_SERVER['HTTP_TOKEN']);
        }
        if ($isLogin) {
            // 通过账号获取权限 权限组
            // mock
            if ($isLogin !== 'admin') {
                $map['del_flg'] = 0;
                $map['admin_name'] = $isLogin;
                $adminData = M('admin')->where($map)->find();
                $roleData = M('role_list')->where(array('id'=>$adminData['role_id']))->find();
                $admin_group = $roleData['role_group'];
                if (!empty($admin_group)) {
                    $role_group = explode('|', $admin_group);
                    $role_group_return = [];
                    foreach ($role_group as $kk => $vv) {
                        $dd = explode(':', $vv);
                        $arr = array_merge([$dd[0]], explode(',', $dd[1]));
                        $role_group_return = array_merge($role_group_return, $arr);
                    }
                    $data = array(
                        'roles' => [$isLogin],
                        'avatar' => 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif',
                        'name' => $roleData['role_name'],
                        'show_name'=>$adminData['show_name'],
                        'roleGroup' => $role_group_return,
                    );
                }
            } else {
                $data = array(
                    'roles' => ['admin'],
                    'avatar' => 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif',
                    'name' => 'Admin',
                    'show_name' => 'Admin',
                    'roleGroup' => []
                );
            }
            $rst['code'] = 200;
            $rst['data'] = $data;
            $this->ajaxReturn($rst);

        }

    }


}