<?php

namespace Curiookids\Controller;


/**新后台banner
 * Class StudioController
 * @package Curiookids\Controller
 */
class BannerController extends BaseController {
    private $db;
    private $field;
    public function _initialize() {
        parent::_initialize();
        $this->db = M('banner');
        $this->field = ['type','web_cover','mobile_cover','jump_url','sort'];
    }
    public function createAction() {
        if($_POST){
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['lang'] = $_SERVER['HTTP_LANG'];
            $data['create_time'] = time();
            $data['update_time'] = time();
            $this->db->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            $this->db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['update_time'] = time();
            $this->db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $map['lang'] = $_SERVER['HTTP_LANG'];
        $data = $this->db->where($map)->order('sort desc')->select();
        foreach ($data as $k=>$value){
            $data[$k]['web_cover'] = empty($value['web_cover']) ? [] : [$value['web_cover']];
            $data[$k]['mobile_cover'] = empty($value['mobile_cover']) ? [] : [$value['mobile_cover']];
        }
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}