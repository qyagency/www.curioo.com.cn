<?php

namespace Curiookids\Controller;


/**新后台基础连接
 * Class StudioController
 * @package Curiookids\Controller
 */
class BaseUrlController extends BaseController {
    private $db;
    private $field;
    public function _initialize() {
        parent::_initialize();
        $this->db = M('channel_mgt_baseurl');
        $this->field = ['url','url_name'];
    }
    public function createAction() {
        if($_POST){
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();
            $data['update_time'] = time();
            $map['url'] = $data['url'];
            $map['del_flg'] = 0;
            $find = $this->db->where($map)->find();
            if(empty($find)){
                $this->db->add($data);
                $rst['code'] = 200;
            }else{
                $rst['code'] = 201;
            }

            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            $this->db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['update_time'] = time();
            $this->db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $data = $this->db->where($map)->order('update_time desc')->select();
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}