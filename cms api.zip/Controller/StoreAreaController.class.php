<?php

namespace Curiookids\Controller;


/**新后台门店管理
 * Class StudioController
 * @package Curiookids\Controller
 */
class StoreAreaController extends BaseController {
    private $db;
    private $field;
    public function _initialize() {
        parent::_initialize();
        $this->db = M('store_area');
        $this->field = ['area_name'];
    }
    public function createAction() {
        if($_POST){
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();
            $data['update_time'] = time();
            $map['area_name'] = $data['area_name'];
            $map['del_flg'] = 0;
            $find = $this->db->where($map)->find();
            if(empty($find)){
                $this->db->add($data);
                $rst['code'] = 200;
            }else{
                $rst['code'] = 201;
            }

            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            $this->db->where($map)->setField('del_flg', 1);
            // 新增把门店和地区关联的也删除
            $storeInfoRst = M('store_info')->where(array('area_id'=>$map['id']))->setField('del_flg',1);

            // 清空员工绑定的门店值 TODO

            $rst['code'] = 200;
            $rst['data'] = $storeInfoRst;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['update_time'] = time();
            $this->db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $data = $this->db->where($map)->order('update_time desc')->select();

        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}