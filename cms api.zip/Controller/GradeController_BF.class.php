<?php

namespace Curiookids\Controller;


/**新后台grade
 * Class StudioController
 * @package Curiookids\Controller
 */
class GradeController extends BaseController {
    private $db;
    private $field;
    public function _initialize() {
        parent::_initialize();
        $this->db = M('grade');
        $this->field = ['type','title','sub_title','grade','age','course_objectives','english_communication','entrepreneur','technology','creative_design','certification'];
    }

    public function getOptionsAction() {
        $typeGroup = ['kd1','kd2','1','2','3','4','5','6'];
        $map['del_flg']=0;
        $map['lang'] = $_SERVER['HTTP_LANG'];
        $data = $this->db->where($map)->getField('type',true);

        $diff = array_diff($typeGroup,empty($data)?[]:$data);

        $out = [];
        foreach ($diff as $k=>$value){
            $out[] = array(
                'label'=>$value,
                'value'=>$value
            );
        }

        $rst['code'] = 200;
        $rst['data'] = $out;

        $this->ajaxReturn($rst);

    }
    public function createAction() {
        if($_POST){
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['lang'] = $_SERVER['HTTP_LANG'];

            $data['create_time'] = time();
            $data['update_time'] = time();
            $this->db->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            $this->db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['update_time'] = time();
            $this->db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['lang'] = $_SERVER['HTTP_LANG'];
        $map['del_flg'] = 0;
        $data = $this->db->where($map)->select();
        foreach ($data as $k=>$value){
            $data[$k]['certification'] = explode(',',$value['certification']);
        }

        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}