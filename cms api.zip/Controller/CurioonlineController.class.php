<?php

namespace Curiookids\Controller;


/**新后台用
 * Class StudioController
 * @package Curiookids\Controller
 */
class CurioonlineController extends BaseController {
    public function createAction() {
        if($_POST){
            $db = M('curioonline');
            $data['type_1'] = I('post.type_1')=='false'?0:1;
            $data['type_2'] = I('post.type_2')=='false'?0:1;
            $data['type_3'] = I('post.type_3')=='false'?0:1;
            $data['cover'] = I('post.cover');

            $data['desc'] = htmlspecialchars_decode(I('post.desc'));
            $data['price'] = I('post.price');
            $data['link'] = I('post.link');
            $data['desc_short'] = I('post.desc_short');
            $data['desc_last'] = I('post.desc_last');
            $data['sort'] = I('post.sort');
            $data['create_time'] = I('post.create_time');
            $data['update_time'] = I('post.update_time');
            $data['lang'] = $_SERVER['HTTP_LANG'];

            $db->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $db = M('curioonline');
            $map['id'] = I('post.id');
            $db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $db = M('curioonline');
            $map['id'] = I('post.id');
            $data['type_1'] = I('post.type_1')=='false'?0:1;
            $data['type_2'] = I('post.type_2')=='false'?0:1;
            $data['type_3'] = I('post.type_3')=='false'?0:1;
            $data['cover'] = I('post.cover');
            $data['desc'] = htmlspecialchars_decode(I('post.desc'));
            $data['price'] = I('post.price');
            $data['link'] = I('post.link');
            $data['desc_short'] = I('post.desc_short');
            $data['desc_last'] = I('post.desc_last');
            $data['sort'] = I('post.sort');
            $data['update_time'] = I('post.update_time');
            $db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $map['lang'] = $_SERVER['HTTP_LANG'];

        $data = M('curioonline')->where($map)->order('sort desc')->select();
        foreach ($data as $k=>$value){
            $data[$k]['cover'] = empty($value['cover']) ? [] : [$value['cover']];
            $data[$k]['type_1'] = $value['type_1']==1?true:false;
            $data[$k]['type_2'] = $value['type_2']==1?true:false;
            $data[$k]['type_3'] = $value['type_3']==1?true:false;

        }
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}