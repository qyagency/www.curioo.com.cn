<?php

namespace Curiookids\Controller;


/**新后台活动管理
 * Class StudioController
 * @package Curiookids\Controller
 */
class ActivityController extends BaseController {
    private $db;
    private $field;

    public function _initialize() {
        parent::_initialize();
        $this->db = M('channel_mgt_activity');
        $this->field = ['activity_name', 'baseurl', 'channel', 'city', 'point_position', 'ad', 'activity', 'offer'];
    }

    public function createAction() {
        if ($_POST) {
            $str = '';
            foreach ($this->field as $k => $value) {
                $data[$value] = I('post.' . $value);
                $str .= I('post.' . $value);
            }
            $data['create_time'] = time();
            $data['update_time'] = time();
            $str .= time();
            // 获取参数
            $data['channel_code'] = substr(md5($str), 8, 16);

            // 拼接类型
            $type = ((strpos($data['baseurl'], '?') !== false) ? '&' : '?');
            $data['general_url'] = $data['baseurl'] . $type . 'channel=' . $data['channel_code'];

            $this->db->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            $this->db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        die();
        // 没有修改
        if ($_POST) {
            $map['id'] = I('post.id');
            foreach ($this->field as $k => $value) {
                $data[$value] = I('post.' . $value);
            }
            $data['update_time'] = time();
            $this->db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $data = $this->db->where($map)->order('update_time desc')->select();
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

    /**
     * 可供选择的基础渠道
     */
    public function channel_optionAction() {
        $mapping = C('CHANNEL_MAPPING');
        $db = M('channel_mgt_mapping');
        $map['del_flg'] = 0;
        $data = $db->where($map)->field('id,channel_type,channel_name')->select();
        $out = array();
        foreach ($data as $k => $value) {
            $out[$mapping[$value['channel_type']]][] = array(
                'label' => $value['channel_name'],
                'value' => $value['channel_name']
            );
        }

        $urlData = M('channel_mgt_baseurl')->where($map)->select();
        foreach ($urlData as $k => $value) {
            $out['baseurl'][] = array(
                'label' => $value['url_name'],
                'value' => $value['url'],
            );
        }
//        dump($out);
//        die();

        $rst['code'] = 200;
        $rst['data'] = $out;

        $this->ajaxReturn($rst);
    }

    public function getOptionsAction() {
        $map['del_flg'] = 0;


        $data = M('channel_mgt_general')->where($map)->select();
        $mapping = [];
        foreach ($data as $k => $value) {
            $out['channel_mgt_id'][] = array(
                'label' => $value['general_name'],
                'value' => $value['id'],
            );
            $mappingMap['id'] = array('in', $value['channel_mapping']);
            $mappingData = M('channel_mgt_mapping')->where($mappingMap)->select();
            foreach ($mappingData as $kk => $vv) {
                $mapping[$vv['channel_type']][$value['id']] = $vv['channel_name'];
            }
        }

        $rst['code'] = 200;
        $rst['data'] = $out;
        $rst['mapping'] = $mapping;
        $this->ajaxReturn($rst);
    }

}