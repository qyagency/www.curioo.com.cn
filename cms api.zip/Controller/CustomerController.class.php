<?php

namespace Curiookids\Controller;


/**新后台客户管理
 * Class StaffController
 * @package Curiookids\Controller
 */
class CustomerController extends BaseController {

    public function modifyAction() {

    }

    public function changeRateAction() {
        if($_POST){
            $map['id'] = I('post.id');
            M('user_info')->where($map)->setField('user_rate',I('post.user_rate'));

            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }
    public function changeRemarkAction() {
        if($_POST){
            $map['id'] = I('post.id');
            M('user_info')->where($map)->setField('remark',I('post.remark'));

            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        // 查询该账户权限
        $roleMap['token'] = $_SERVER['HTTP_TOKEN'];
        $can = M('admin')->where($roleMap)->field('id,admin_name,can_download,can_read_all,can_see_data,store_id,city')->find();

//        $needField = ['id','user_name','user_gender','user_mobile','user_relation','user_school','user_grade','create_time','user_rate','remark'];
        $needField = ['id','user_name','user_gender','user_mobile','create_time','user_rate','remark','user_city','user_age'];
        $map['del_flg'] = 0;
        /*逻辑更改
         * if($can['can_read_all']!=1){
            // 不能查看全部
            $map['channel'] = array('like','%'.'"sales_id":"'.$can['id'].'"'.'%');
        }*/

        $map_auth['del_flg'] = 0;
        if($can['admin_name'] != 'admin'){
            switch ($can['can_see_data']){
                //个人数据
                case 6:
                    $map_auth['channel'] = array('like','%'.'"sales_id":"'.$can['id'].'"'.'%');
                    break;
                //门店线下数据
                case 5:
                    $map_auth['channel'] = array('like','%'.'"store_id":"'.$can['store_id'].'"'.'%');
                    break;
                //城市线下数据
                case 4:
                    $store = $this->queryStore($can['store_id']);
                    if($store['area_name'] == '杭州'){
                        $area_name = 'HZ';
                    }elseif ($store['area_name'] == '广州') {
                        $area_name = 'GZ';
                    }elseif ($store['area_name'] == '天津') {
                        $area_name = 'TJ';
                    }else{
                        $area_name = $store['area_name'];
                    }

                    $city = str_replace('\\','\\\\',trim(json_encode($area_name),'"'));
                    $map_auth['channel'] = array('like',"%{$city}%");
                    break;
                //所有线下数据
                case 3:
                    $where['channel'] = array('neq','');
                    $where['user_mini_open_id'] = array('neq','');
                    $map_auth['_complex'] = $where;
                    $map_auth['channel'] = array('EXP','IS NOT NULL');
                    $map_auth['user_mini_open_id'] = array('EXP','IS NOT NULL');
                    $map_auth['_logic'] = 'and';
                    break;
                //所有线上数据
                case 2:
                    $where1['channel'] = array('eq','');
                    $where1['user_mini_open_id'] = array('eq','');
                    $where1['_logic'] = 'or';

                    $where2['_complex'] = $where1;
                    $where2['channel'] = array('EXP','IS NULL');
                    $where2['user_mini_open_id'] = array('EXP','IS NULL');
                    $where2['_logic'] = 'or';

                    $map_auth['_complex'] = $where2;
                    $map_auth['_logic'] = 'and';
                    break;
                //全部数据
                case 1:

                    break;
                default:
                    $map_auth['channel'] = array('like','%'.'"sales_id":"'.$can['id'].'"'.'%');
                    break;
            }
        }


        $data = M('user_info')->where($map_auth)->order('create_time desc')->select();
//echo M()->_sql();die;
        // 小程序渠道两种格式
        $formatData = [];

        $activityList = [];
        $gradeList = [];
        $schoolList = [];
        $genderList = [];
        $relationList = [];
        $cityList = [];
        $ageList = [];
        $appointment = M('make_appointment')->getField('uid,city,subscribe_date,subscribe_time');
//        dump($data);
//        die();
        foreach ($data as $k=>$value){
            $personData = [];
            // 基础数据
            foreach ($needField as $kk=>$vv){
                $personData[$vv] = $value[$vv];
            }

            if(!empty($appointment[$value['id']])){
                $personData['appointment'] = $appointment[$value['id']];
                $personData['appointment_city'] = $appointment[$value['id']]['city'];
                $personData['appointment_subscribe_date'] = $appointment[$value['id']]['subscribe_date'];
                $personData['appointment_subscribe_time'] = $appointment[$value['id']]['subscribe_time'];
            }
            for($i=1;$i<=6;$i++){
                $personData['channel_'.$i] = '';
            }
            $personData['create_time'] = date('Y-m-d H:i:s',$personData['create_time']);

            $gradeList[] = $value['user_grade'];
            $schoolList[] = $value['user_school'];
            $ageList[] = $value['user_age'];
            $relationList[] = $value['user_relation'];
            $cityList[] = $value['user_city'];
            $ageList[] = $value['user_age'];

            // 渠道分类
            if(!empty($value['user_mini_open_id'])){
                // 小程序
                $channel = $value['channel'];
                if(!empty($channel)){
                    // 正常流程
                    $channel = json_decode($channel,true);
//                    $personData['activity_id'] = $channel['activity_id'];

                    // 添加活动id
//                    $activityList[] = $channel['activity_id'];

                    // 门店地区
                    $queryStore = $this->queryStore($channel['store_id']);
                    $personData['store_name'] = $queryStore['store_name'];
                    $personData['area_name'] = $queryStore['area_name'];

                    // 销售
                    $personData['sales_name'] = $this->querySales($channel['sales_id']);

                    // 渠道
                    $field = ['channel','city','point_position','activity','offer'];
                    foreach ($field as $kk=>$vv){
                        $personData[$vv] = $channel[$vv];
                    }
//                    $queryChannel = $this->queryChannel($channel['activity_id']);
//                    foreach ($queryChannel as $channel_type=>$channel_name){
//                        $personData['channel_'.$channel_type] = $channel_name;
//                    }

                }else{
                    // 暂时没有相关信息 TODO 后续可能需要添加相关逻辑
                    unset($data[$k]);
                }

                // 预约时间
//                $orderMap['user_mini_open_id'] = $value['user_mini_open_id'];
//                $orderData = M('evaluation_booking')->where($orderMap)->find();
//
//                $personData['order_date'] = $orderData['booking_date'];
//                $personData['order_time'] = $orderData['booking_time'];


            }else{
                // 网站 目前只有一个渠道website 后续会变成渠道参数 反查 TODO
                $map['channel_code'] = $value['channel'];
                $channelData = M('channel_mgt_activity')->where($map)->find();
                $personData['channel'] = $channelData['channel'];
                $personData['city'] = $channelData['city'];
                $personData['point_position'] = $channelData['point_position'];
                $personData['ad'] = $channelData['ad'];
                $personData['activity'] = $channelData['activity'];
                $personData['offer'] = $channelData['offer'];

            }
            $formatData[] = $personData;
        }

        $activityOption = $this->getActivityOption($activityList);
        $gradeOption = $this->getOption($gradeList);
        $schoolOption = $this->getOption($schoolList);
        $genderOption = $this->getOption($genderList);
        $relationOption = $this->getOption($relationList);
        $cityOption = $this->getOption($cityList);
        $ageOption = $this->getOption($ageList);

        $rst['code'] = 200;
        $rst['data'] = $formatData;
        $rst['activityOption'] = $activityOption;
        $rst['ageOption'] = $ageOption;
        $rst['gradeOption'] = $gradeOption;
        $rst['schoolOption'] = $schoolOption;
        $rst['genderOption'] = $genderOption;
        $rst['cityOption'] = $cityOption;
        $rst['relationOption'] = $relationOption;
        $rst['allChannel'] = $this->queryAllChannel();
        $rst['can_download'] = $can['can_download'];
        $this->ajaxReturn($rst);
    }

    // 通过活动反查渠道
    private function queryChannel($activity_id) {
        $generalMap['id'] = M('channel_mgt_activity')->where(array('id'=>$activity_id))->getField('channel_mgt_id');

        $getList = M('channel_mgt_general')->where($generalMap)->getField('channel_mapping');
        $channelData = [];
        if(!empty($getList)){
            $channelMap['id'] = array('in',$getList);

            $channelData = M('channel_mgt_mapping')->where($channelMap)->getField('channel_type,channel_name');
        }

        return $channelData;
    }

    private function queryAllChannel() {
        $data = M('channel_mgt_mapping')->select();
        $channelData = [
            'channel_1'=>[],
            'channel_2'=>[],
            'channel_3'=>[],
            'channel_4'=>[],
            'channel_5'=>[],
            'channel_6'=>[],
        ];
        foreach ($data as $k=>$value){
            $channelData['channel_'.$value['channel_type']][] = array(
                'label'=>$value['channel_name'],
                'value'=>$value['channel_name'],
            );
        }

        return $channelData;
    }

    // 通过门店id反查地区门店
    private function queryStore($store_id) {
        $store = M('store_info')->where(array('id'=>$store_id))->find();
        $areaName = M('store_area')->where(array('id'=>$store['area_id']))->getField('area_name');

        return array(
            'store_name'=>$store['store_name'],
            'area_name'=>$areaName,
        );
    }

    // 通过销售id反查名字
    private function querySales($sales_id) {
        return M('admin')->where(array('id'=>$sales_id))->getField('show_name');
    }

    // 获取活动的option
    private function getActivityOption($activityList) {
        $out = [];
        if(!empty($activityList)){
            $map['id'] = array('in',$activityList);
            $data = M('channel_mgt_activity')->where($map)->select();
            foreach ($data as $k=>$value){
                $out[] = array(
                    'label'=>$value['activity_name'],
                    'value'=>$value['id']
                );
            }
        }

        return $out;
    }
    // 获取option
    public function getOption($list) {
        $arr = array_unique($list);
        $out = [
            array(
                'label'=>'全部',
                'value'=>''
            )
        ];
        foreach ($arr as $k=> $value){
            if(!empty($value)){
                $out[] = array(
                    'label'=>$value,
                    'value'=>$value,
                );
            }
        }
        return $out;
    }


}