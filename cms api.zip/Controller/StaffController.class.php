<?php

namespace Curiookids\Controller;


/**新后台销售数据
 * Class StaffController
 * @package Curiookids\Controller
 */
class StaffController extends BaseController {

    public function modifyAction() {
        if ($_POST) {
//            $map['id'] = I('post.id');
//            foreach ($this->field as $k=>$value){
//                $data[$value] = I('post.'.$value);
//            }
//            $data['update_time'] = time();
//            $this->db->where($map)->save($data);
//            $rst['code'] = 200;
//            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        if ($_POST) {
            $map['del_flg'] = 0;
            $map['token'] = $_SERVER['HTTP_TOKEN'];
            $data = M('admin')->where($map)->field('id,show_name,admin_name,channel,city,point_position,activity,offer,store_id,qrcode')->find();

            if (empty($data['qrcode'])) {
                // 获取带参二维码
                $url = 'https://www.curioo.com.cn/backend/Open/getSalesQrcode?salesId=' . $data['id'];
                $data['qrcode'] = json_decode($this->request_get($url),true)['url'];
            }


            $rst['code'] = 200;
            $rst['data'] = $data;
            $this->ajaxReturn($rst);
        }
    }

    public function changeStoreIdAction() {
        if ($_POST && I('post.store_id')&&$_SERVER['HTTP_TOKEN']) {
            $map['token'] = $_SERVER['HTTP_TOKEN'];
            M('admin')->where($map)->setField('store_id', I('post.store_id'));

            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function channelChangeAction() {
        $rst['code'] = 201;
        if($_SERVER['HTTP_TOKEN']){
            $field = ['channel','city','point_position','activity','offer'];
            foreach ($field as $k=>$value){
                if(I('post.'.$value)){
                    $save[$value] = I('post.'.$value);
                }
            }
            if(!empty($save)){
                $map['token'] = $_SERVER['HTTP_TOKEN'];
                M('admin')->where($map)->save($save);
                $rst['code'] = 200;
            }else{
                $rst['code'] = 202;
            }

        }
        $this->ajaxReturn($rst);

    }

    public function changeActivityIdAction() {
        if ($_POST && I('post.activity_id')&&$_SERVER['HTTP_TOKEN']) {
            $map['token'] = $_SERVER['HTTP_TOKEN'];
            M('admin')->where($map)->setField('activity_id', I('post.activity_id'));

            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function getOptionsAction() {
        $map['del_flg'] = 0;
        $storeData = M('store_info')->where($map)->field('id,area_id,store_name')->select();
        $storeOption = array(
            'option' => [],
            'mapping' => []
        );
        foreach ($storeData as $k => $value) {


            $areaMap['del_flg'] = 0;
            $areaMap['id'] = $value['area_id'];

            $storeOption['option'][] = array(
                'label' => $value['store_name'],
                'value' => $value['id']
            );
            $storeOption['mapping'][$value['id']] = M('store_area')->where($areaMap)->getField('area_name');
        }


//        $map['is_show'] = 1;
//        $activityData = M('channel_mgt_activity')->where($map)->field('id,activity_name,channel_mgt_id')->select();
//        $activityOption = [];
//        $activityOption = array(
//            'option' => [],
//            'mapping' => []
//        );
//        if (!empty($activityData)) {
//            $channelDb = M('channel_mgt_general');
//            $channelMappingDb = M('channel_mgt_mapping');
//            foreach ($activityData as $k => $value) {
//                $channelMap['id'] = $value['channel_mgt_id'];
//                $channelMappingList = $channelDb->where($channelMap)->getField('channel_mapping');
//                $activityOption['option'][] = array(
//                    'label' => $value['activity_name'],
//                    'value' => $value['id']
//                );
//                if (!empty($channelMappingList)) {
//                    $channelMappingMap['id'] = array('in', $channelMappingList);
//                    $activityOption['mapping'][$value['id']] = $channelMappingDb->where($channelMappingMap)->getField('channel_type,channel_name');
//                }
//            }
//        }




        $rst['code'] = 200;
        $rst['storeOption'] = $storeOption;
//        $rst['activityOption'] = $activityOption;

        $this->ajaxReturn($rst);


    }

}