<?php

namespace Curiookids\Controller;


/**新后台用
 * Class StudioController
 * @package Curiookids\Controller
 */
class CareerController extends BaseController {
    public function createAction() {
        if($_POST){
            $db = M('career');
            $data['title'] = I('post.title');
            $data['sub_title'] = I('post.sub_title');
            $data['desc'] = I('post.desc');
            $data['sort'] = I('post.sort');
            $data['lang'] = $_SERVER['HTTP_LANG'];
            $data['create_time'] = time();
            $data['update_time'] = time();
            $db->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $db = M('career');
            $map['id'] = I('post.id');
            $db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $db = M('career');
            $map['id'] = I('post.id');
            $data['title'] = I('post.title');
            $data['sub_title'] = I('post.sub_title');
            $data['desc'] = I('post.desc');
            $data['sort'] = I('post.sort');
            $data['update_time'] = time();
            $db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $map['lang'] = $_SERVER['HTTP_LANG'];

        $data = M('career')->where($map)->order('sort desc')->select();

        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}