<?php

namespace Curiookids\Controller;


/**
 * Class StaffController
 * @package Curiookids\Controller
 */
class OverseasCustomerController extends BaseController {

    /**
     * @Notes:查询海外的填表信息
     * @Author: 杭
     * @Date: 2020/7/30 14:16
     */
    public function queryAction() {
        // 查询该账户权限
        $roleMap['token'] = $_SERVER['HTTP_TOKEN'];
        $can = M('admin')->where($roleMap)->field('id,admin_name,can_download,can_read_all,can_see_data,store_id,city')->find();
        //查询列表
        $enuser_model = M('en_user_info');
        $map = [
            'del_flg' => 0
        ];
        $data = $enuser_model
            ->alias('eui')
            ->join('left join en_make_appointment ema on eui.id = ema.uid')
            ->where($map)
            ->field('eui.*,ema.uid,ema.subscribe_date,ema.subscribe_time')
            ->order('create_time desc')
            ->select();

        //国家搜索
        $country_sql = 'select DISTINCT user_country from en_user_info';
        $country = M()->query($country_sql);
        $country = $this->getOptions($country,'user_country');

        //city 搜索
        $city_sql = 'select DISTINCT user_city from en_user_info';
        $city = M()->query($city_sql);
        $city = $this->getOptions($city,'user_city');

        $rst = [
            'data' => $data,
            'can_download' => $can['can_download'],
            'country' => $country,
            'city' => $city,
            'code' => 200
        ];

        $this->ajaxReturn($rst);
    }

    /**
     * @Notes:输入 二维数组 字段名 返回 [{label:'',value:''}]
     * @Author: 杭
     * @Date: 2020/7/31 13:16
     * @param $list
     * @return array
     */
    public function getOptions($list,$field) {
        $out = [
            array(
                'label'=>'全部',
                'value'=>''
            )
        ];
        foreach ($list as $k=> $value){
            if(!empty($value[$field])) {
                $out[] = array(
                    'label' => $value[$field],
                    'value' => $value[$field],
                );
            }

        }
        return $out;
    }

    // 获取option
    public function getOption($list) {
        $arr = array_unique($list);
        $out = [
            array(
                'label'=>'全部',
                'value'=>''
            )
        ];
        foreach ($arr as $k=> $value){
            if(!empty($value)){
                $out[] = array(
                    'label'=>$value,
                    'value'=>$value,
                );
            }
        }
        return $out;
    }


}