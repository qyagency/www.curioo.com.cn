<?php

namespace Curiookids\Controller;


/**新后台Shinningstar用
 * Class ShinningstarController
 * @package Curiookids\Controller
 */
class ShinningstarController extends BaseController {
    public function createAction() {
        if($_POST){
            $db = M('shinningstar');
            $data['cover'] = I('post.cover');
            $data['title'] = htmlspecialchars_decode(I('post.title'));
            $data['child_name'] = I('post.child_name');
            $data['desc'] = I('post.desc');
            $data['headimg'] = I('post.headimg');
            $data['sort'] = I('post.sort');
            $data['lang'] = $_SERVER['HTTP_LANG'];
            $data['create_time'] = time();
            $data['update_time'] = time();
            $db->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $db = M('shinningstar');
            $map['id'] = I('post.id');
            $db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        if ($_POST) {
            $db = M('shinningstar');
            $map['id'] = I('post.id');
            $data['cover'] = I('post.cover');
            $data['title'] = htmlspecialchars_decode(I('post.title'));
            $data['child_name'] = I('post.child_name');
            $data['desc'] = I('post.desc');
            $data['headimg'] = I('post.headimg');
            $data['update_time'] = time();
            $db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $map['lang'] = $_SERVER['HTTP_LANG'];
        $data = M('shinningstar')->where($map)->order('sort desc')->select();
        foreach ($data as $k=>$value){
            $data[$k]['cover'] = empty($value['cover']) ? [] : explode(',',$value['cover']);
            $data[$k]['headimg'] = empty($value['headimg']) ? [] : [$value['headimg']];
        }
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}