<?php

namespace Curiookids\Controller;


/**新后台其他表单
 * Class OtherFormController
 * @package Curiookids\Controller
 */
class OtherFormController extends BaseController {

    public function careerFormAction() {
        $data = M('career_form')->order('create_time desc')->select();

        foreach($data as $key => $val){
            if(empty($val['file_path'])){
                $data[$key]['file_len'] = 0;
                $data[$key]['file_arr'] = array();
            }else{
                $file_path = explode(',',$val['file_path']);
                $data[$key]['file_len'] = count($file_path);
                $data[$key]['file_arr'] = $file_path;
            }

            $data[$key]['create_date'] = date('Y-m-d H:i:s',$val['create_time']);
            if($val['is_cn'] == 1){
                $data[$key]['is_cn_text'] = '中文';
            }else if($val['is_cn'] == 0){
                $data[$key]['is_cn_text'] = '英文';
            }else{
                $data[$key]['is_cn_text'] = '';
            }
        }

        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

    public function emailAction() {
        $this->outPut('email');
    }

    public function franchiseAction() {
        $this->outPut('user_franchise','operate');
    }

    private function outPut($db,$f='') {
        $data = M($db)->order('create_time desc')->select();

        foreach ($data as $k=>$value){
            $data[$k]['create_time'] = date('Y-m-d H:i:s', $value['create_time']);
            if($f){
                $data[$k][$f] = $value[$f]==0?'否':'是';
            }
        }
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}