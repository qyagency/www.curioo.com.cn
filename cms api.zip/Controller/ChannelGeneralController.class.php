<?php

namespace Curiookids\Controller;


/**新后台渠道汇总
 * Class StudioController
 * @package Curiookids\Controller
 */
class ChannelGeneralController extends BaseController {
    private $db;
    private $field;
    public function _initialize() {
        parent::_initialize();
        $this->db = M('channel_mgt_general');
        $this->field = ['general_name'];
    }


    public function createAction() {
        if($_POST){
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $channel = ['channel','city','pointPosition','ad','activity','offer'];
            $channelData = [];
            foreach ($channel as $k=>$value){
                if(!empty(I('post.'.$value))){
                    $channelData[] = I('post.'.$value);
                }
            }
            $data['channel_mapping'] = implode(',',$channelData);
            $data['channel_code'] = substr(md5($data['channel_mapping']), 8, 16);
            $data['create_time'] = time();
            $data['update_time'] = time();
            $this->db->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function deleteAction() {
        if ($_POST) {
            $map['id'] = I('post.id');
            $this->db->where($map)->setField('del_flg', 1);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function modifyAction() {
        die();
        if ($_POST) {
            // 没有修改

            $map['id'] = I('post.id');
            foreach ($this->field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['update_time'] = time();
            $this->db->where($map)->save($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function queryAction() {
        $map['del_flg'] = 0;
        $data = $this->db->where($map)->order('update_time desc')->select();
        $mapDb = M('channel_mgt_mapping');
        foreach ($data as $k=>$value){
            if(!empty($value['channel_mapping'])){
                $channelMap['id'] = array('in',$value['channel_mapping']);
                $data[$k]['channel_mapping'] = $mapDb->where($channelMap)->getField('channel_type,channel_name');
            }
        }
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}