<?php

namespace Curiookids\Controller;

use Think\Controller;

class BaseController extends Controller {

    //管理员可以分配的数据权限
    const EDIT_DATA_FIELD = [
        '1'=>'全部数据',
        '2'=>'所有线上数据',
        '3'=>'所有线下数据',
        '4'=>'城市线下数据',
        '5'=>'门店线下数据',
        '6'=>'个人数据',
    ];

    public function _initialize() {
        header('Access-Control-Allow-Headers:Token,Lang');
        header("Access-Control-Allow-Methods: * ");
        header("Access-Control-Allow-Origin: * ");

        if(strtolower(CONTROLLER_NAME)!='login'&&strtolower(CONTROLLER_NAME)!='uploadimg'&&$_GET['debug']!='w.y'){
            $map['token'] = $_SERVER['HTTP_TOKEN'];
            $find = M('admin')->where($map)->find();

            session('adminInfo',$find);

            if(empty($find)){
                $rst['code'] = 504;
                $rst['msg'] = 'error';
                // 被迫登出
                $this->ajaxReturn($rst);
            }
        }

    }

    /* PHP sha256() */
    protected function sha256($data, $rawOutput = false) {
        if (!is_scalar($data)) {
            return false;
        }
        $data = (string)$data;
        $rawOutput = !!$rawOutput;
        return hash('sha256', $data, $rawOutput);
    }

    /**
     * 发送post请求
     * @param string $url
     * @param string $param
     * @return bool|mixed
     */
    protected function ReqPost($url = '', $param = '') {
        if (empty($url) || empty($param)) {
            return false;
        }
        $postUrl = $url;
        $curlPost = $param;
        $ch = curl_init(); //初始化curl
        curl_setopt($ch, CURLOPT_URL, $postUrl); //抓取指定网页
        curl_setopt($ch, CURLOPT_HEADER, 0); //设置header
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_POST, 1); //post提交方式
        curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);
        $data = curl_exec($ch); //运行curl
        curl_close($ch);
        return $data;
    }

    /**
     * 发送get请求
     * @param string $url
     * @return bool|mixed
     */
    protected function request_get($url = '') {
        if (empty($url)) {
            return false;
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($ch);
        curl_close($ch);
        return $data;
    }
}