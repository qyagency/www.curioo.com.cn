<?php

namespace Curiookids\Controller;
use Think\Controller;

/**新后台上传图片用
 * Class UploadImgController
 * @package Curiookids\Controller
 */

class UploadImgController extends BaseController {

    public function uploadImgAction() {
        if ($_SERVER['REQUEST_METHOD'] != 'OPTIONS') {

            $project = 'Curiookids';
            $config = array(
                'maxSize' => 52428800,
                'rootPath' => './Public/Uploads/' . $project . '/',
                'saveName' => array('uniqid', ''),
                'exts' => array('jpg', 'gif', 'png', 'jpeg', 'mp4'),
                'autoSub' => false,
                'subName' => array('date', 'Ymd'),
            );

            $Upload = new \Think\Upload($config);
            $info = $Upload->upload();
            if ($info) {
                foreach ($info as $file) {
                    if ($_SERVER['SERVER_NAME'] == 'www.curioo.com.cn') {
                        $data = 'https://' . $_SERVER['SERVER_NAME'] . '/backend/Public/Uploads/' . $project . '/' . $file['savename'];
                    } else {
                        $data = 'http://' . $_SERVER['SERVER_NAME'].':8180' . '/Public/Uploads/' . $project . '/' . $file['savename'];
                    }
                }
                $rst['code'] = 200;
                $rst['file'] = $data;
                $this->ajaxReturn($rst);
            } else {
                $rst['code'] = 201;
                $rst['msg'] = '上传失败' . $Upload->getError();
                $this->ajaxReturn($rst);
            }
        }
    }
}