<?php
namespace Curiookids\Controller;

class WebApiController extends BaseController {

    // 用户表单
    public function guestFormAction() {
        if($_POST){
            $field = ['uid','user_email','user_name','user_mobile','user_city','channel','user_age'];
            foreach ($field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();


            M('user_info')->add($data);

            $rst['code'] = 200;
            $rst['uid'] = M('user_info')->where($data)->getField('id');
            $this->ajaxReturn($rst);

        }
    }

    // 用户表单海外客户
    public function guestFormEnAction() {
        if($_POST){
            $field = ['parent_name','child_birth','user_country','user_city','user_mobile','user_email'];
            foreach ($field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();
            $data['submit_time'] = date('Y-m-d H:i:s');
            M('en_user_info')->add($data);

            $rst['code'] = 200;
            $rst['uid'] = M('en_user_info')->where($data)->getField('id');
            $this->ajaxReturn($rst);

        }
    }

    // 预约信息
    public function makeAppointmentAction() {
        if($_POST){
            $field = ['uid','city','subscribe_date','subscribe_time'];
            foreach ($field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();
            M('make_appointment')->add($data);

            $rst['code'] = 200;
            $this->ajaxReturn($rst);

        }
    }

    // 预约信息海外客户
    public function makeAppointmentEnAction() {
        if($_POST){
            $field = ['uid','subscribe_date','subscribe_time'];
            foreach ($field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();
            M('en_make_appointment')->add($data);

            $rst['code'] = 200;
            $this->ajaxReturn($rst);

        }
    }

    // FRANCHISE
    public function franchiseFormAction() {
        if($_POST){
            $field = ['uid','user_name','user_mobile','user_email','location','operate','where','channel'];
            foreach ($field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();

            M('user_franchise')->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

// career

    /**
     * @Notes:中文
     * @Author: 杭
     * @Date: 2020/8/3 11:50
     */
    public function careerFormAction() {
        if($_POST){
            $field = ['form_id','uid','user_name','gender','age','country','address','education','profession','apply_for_job','user_mobile','channel','file_path','is_cn'];
            foreach ($field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();

            M('career_form')->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }
// career

    /**
     * @Notes:英文
     * @Author: 杭
     * @Date: 2020/8/3 11:50
     */
    public function enCareerFormAction() {
        if($_POST){
            $field = ['form_id','uid','user_name','gender','age','country','address','education','profession','apply_for_job','user_email','channel','is_cn'];
            foreach ($field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();
            $data['file_path'] = implode(',',I('post.file_path'));

            M('career_form')->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    /**
     * @Notes:上传文件
     * @Author: 杭
     * @Date: 2020/8/3 10:15
     */
    public function careerUploadFileAction()
    {
        $imgname = time().$_FILES['file']['name'];
        $tmp = str_replace('\\\\','\\',$_FILES['file']['tmp_name']);
        $file_type = $_FILES['file']['type'];
        $filepath = '/data/wwwroot/www.curioo.com.cn/backend/Public/Uploads/CareerFrom/';

        move_uploaded_file($tmp,$filepath.$imgname);
        $msg = "上传成功";
        $code = 200;

        $rst = [
            'code' => $code,
            'msg' => $msg,
            'file_path' => 'www.curioo.com.cn/backend/Public/Uploads/CareerFrom/'.$imgname
        ];

        $this->ajaxReturn($rst);
    }
    // email
    public function emailAction() {
        if($_POST){

            $field = ['uid','email','channel'];
            foreach ($field as $k=>$value){
                $data[$value] = I('post.'.$value);
            }
            $data['create_time'] = time();

            M('email')->add($data);
            $rst['code'] = 200;
            $this->ajaxReturn($rst);
        }
    }

    public function mailTestAction() {
        vendor('mailChimp.MailChimp');
        $listId = 'ceec110e58';
        $MailChimp = new \MailChimp('1f99acaf992048e8e4dea9fc8673a4a4-us10');
//        $result = $MailChimp->get('lists');
        $result = $MailChimp->post("lists/".$listId."/members", [
            'email_address' => 'tracy.zhan@incker.com',
            'status'        => 'subscribed',
        ]);


        dump($result);

    }


    public function siteverifyAction()
    {
        $url = 'https://www.recaptcha.net/recaptcha/api/siteverify';
        $data = [
            'secret' => I('post.secret'),
            'response' => I('post.response')
        ];

        $rst = $this->ReqPost($url,$data);
        $rst = json_decode($rst,true);

        $this->ajaxReturn($rst);
    }

}