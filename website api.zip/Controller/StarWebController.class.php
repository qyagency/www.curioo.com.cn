<?php
namespace Curiookids\Controller;


class StarWebController extends BaseController {

    public function starListAction() {
        $map['del_flg'] = 0;
        $map['lang'] = I('post.lang');

        $data = M('shinningstar')->where($map)->field('title,cover,desc,headimg,child_name')->order('sort desc')->select();
        foreach ($data as $k=>$value){
            $data[$k]['cover'] = empty($value['cover']) ? [] : explode(',',$value['cover']);
            $data[$k]['title'] = str_replace(array("\n","\r\n","\r"),'<br/>',$value['title']);
            $data[$k]['desc'] = str_replace(array("\n","\r\n","\r"),'<br/>',$value['desc']);
        }
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}