<?php
namespace Curiookids\Controller;


class NewsWebController extends BaseController {

    public function newsListAction() {
        $map['del_flg'] = 0;
        $map['lang'] = I('post.lang');

        $data = M('news')->where($map)->field('id,type,news_date,title,cover,desc,content')->order('sort desc')->select();
        foreach ($data as $k=>$value){
            $data[$k]['desc'] = str_replace(array("\n","\r\n","\r"),'<br/>',$value['desc']);
        }
        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}