<?php

namespace Curiookids\Controller;


class StudioWebController extends BaseController {

    /**
     * studio location
     */
    public function studioLocationAction() {
        $map['lang'] = I('post.lang');
        $map['del_flg'] = 0;

        $rst['dp_country'] = M('studio_location')->distinct('filter_country')->where($map)->select();

        if(!empty(I('post.filter_country'))){
            $map['filter_country'] = I('post.filter_country');
        }

        $rst['dp_city'] = M('studio_location')->distinct('filter_city')->where($map)->select();

        if(!empty(I('post.filter_city'))){
            $map['filter_city'] = I('post.filter_city');
        }

        $db = M('studio_location');
        $data = $db->where($map)->order('sort desc')->select();

        foreach ($data as $k =>$value){
            $data[$k]['phone'] = $value['phone']?$value['phone']:'';
        }
        $rst['code'] = 200;
        $rst['data'] = $data;

        $this->ajaxReturn($rst);
    }

    /**
     * studio cover
     */
    public function studioCoverAction() {
        $map['del_flg'] = 0;
        $data = M('studio')->where($map)->order('sort desc')->select();
        $out = [];
        foreach ($data as $k=>$value){
            $out[] = $value['cover'];
        }
        $rst['code'] = 200;
        $rst['data'] = $out;
        $this->ajaxReturn($rst);
    }

}