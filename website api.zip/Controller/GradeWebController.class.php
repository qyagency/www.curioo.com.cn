<?php
namespace Curiookids\Controller;


class GradeWebController extends BaseController {

    public function gradeInfoAction() {
        $map['lang'] = I('post.lang');
        if(I('post.grade_type')){
            $map['grade_type'] = I('post.grade_type');
        }
        $map['del_flg'] = 0;

        $data = M('grade')->where($map)->select();
        foreach ($data as $k=>$value){
            $data[$k]['line1_1'] =$this->toArr($value['line1_1']);
            $data[$k]['line2_1'] =$this->toArr($value['line2_1']);
            $data[$k]['line3_1'] =$this->toArr($value['line3_1']);
            $data[$k]['line4_1'] =$this->toArr($value['line4_1']);

            $data[$k]['certification'] = empty($value['certification'])?[]:explode(',',$value['certification']);
            $data[$k]['icon'] = empty($value['icon'])?[]:explode(',',$value['icon']);
        }

        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }
    private function toArr($str){
        $a=str_replace(array("\n","\r\n","\r"),'<br/>',$str);
        $arr=explode('<br/>',$a);
        return $arr;
    }

}