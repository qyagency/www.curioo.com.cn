<?php

namespace Curiookids\Controller;


class StudioWebController extends BaseController {

    /**
     * studio location
     */
    public function studioLocationAction() {
        $map['lang'] = I('post.lang');
        $map['del_flg'] = 0;


        $rst['dp_country'] = $this->orderBy( M('studio_location')->distinct('filter_country')->where($map)->select(), $map['lang'] );

        if(!empty(I('post.filter_country'))){
            $map['filter_country'] = I('post.filter_country');
        }

        $rst['dp_city'] =$this->orderBy( M('studio_location')->distinct('filter_city')->where($map)->select(), $map['lang'] );

        if(!empty(I('post.filter_city'))){
            $map['filter_city'] = I('post.filter_city');
        }

        $db = M('studio_location');
        $data = $db->where($map)->order('sort desc')->select();
//        foreach ($data as $k =>$value){
//            $data[$k]['phone'] = $value['phone']?$value['phone']:'';
//        }
//        $data=$this->orderBy($data, $map['lang'] );

        $rst['code'] = 200;
        $rst['data'] = $this->orderBy($data, $map['lang'] );

        $this->ajaxReturn($rst);
    }

    private function orderBy($arr,$lang){
        $list=[];
        $column=array_column($arr,'filter_country');
        array_multisort($column,SORT_ASC,SORT_NATURAL | SORT_FLAG_CASE,$arr);
        foreach ($arr as $k=>$v){
            $arr[$k]['phone']=$v['phone']?$v['phone']:'';
            $list[$v['filter_country']][]=$arr[$k];
        }
        return $list;

    }

    /**
     * studio cover
     */
    public function studioCoverAction() {
        $map['lang'] = I('post.lang');
        $map['del_flg'] = 0;
        $data = M('studio')->where($map)->order('sort desc')->select();
        $out = [];
        foreach ($data as $k=>$value){
            $out[] = $value['cover'];
        }
        $rst['code'] = 200;
        $rst['data'] = $out;
        $this->ajaxReturn($rst);
    }

}