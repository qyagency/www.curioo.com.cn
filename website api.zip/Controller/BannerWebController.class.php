<?php
namespace Curiookids\Controller;


class BannerWebController extends BaseController {

    public function bannerListAction() {
        $map['lang'] = I('post.lang');
        $map['del_flg'] = 0;
        $map['type'] = I('post.type');
        $data = M('banner')->where($map)->order('sort desc')->field('web_cover,mobile_cover,jump_url')->select();

        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}