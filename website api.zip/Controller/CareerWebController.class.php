<?php
namespace Curiookids\Controller;


class CareerWebController extends BaseController {

    public function careerListAction() {
        $map['lang'] = I('post.lang');
        $map['del_flg'] = 0;

        $data = M('career')->where($map)->order('sort desc')->field('id,title,sub_title,desc')->select();

        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}