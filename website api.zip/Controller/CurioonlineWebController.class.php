<?php
namespace Curiookids\Controller;


class CurioonlineWebController extends BaseController {

    public function onlineAction() {
        if(I('post.type')){
            $map['lang'] = I('post.lang');
            $map['del_flg'] = 0;
            $map['type_'.I('post.type')] = 1;
            $field = 'cover,desc,price,link,desc_short,desc_last';
            $data = M('curioonline')->where($map)->order('sort asc')->field($field)->select();
            foreach ($data as $k=>$value){
                $data[$k]['desc'] = str_replace(array("\n","\r\n","\r"),'<br/>',$value['desc']);
            }
            $rst['code'] = 200;
            $rst['data'] = $data;

            $this->ajaxReturn($rst);
        }else{
            die('?');
        }

    }

}