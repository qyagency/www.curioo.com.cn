<?php
namespace Curiookids\Controller;
use Think\Controller;

class IndexController extends Controller {

    public function indexAction() {
        echo 'Coming soon';
        die();
        $this->display();
    }


}