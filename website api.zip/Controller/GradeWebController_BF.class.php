<?php
namespace Curiookids\Controller;


class GradeWebController extends BaseController {

    public function gradeInfoAction() {
        $map['lang'] = I('post.lang');
        $map['type'] = I('post.type');
        $map['del_flg'] = 0;

        $data = M('grade')->where($map)->select();
        foreach ($data as $k=>$value){
            $data[$k]['english_communication'] = str_replace(array("\n","\r\n","\r"),'<br/>',$value['english_communication']);
            $value['entrepreneur'] = str_replace(array("\n","\r\n","\r"),'<br/>',$value['english_communication']);
            $value['technology'] = str_replace(array("\n","\r\n","\r"),'<br/>',$value['english_communication']);
            $value['creative_design'] = str_replace(array("\n","\r\n","\r"),'<br/>',$value['english_communication']);


            $data[$k]['entrepreneur'] = explode('<br/>',$value['entrepreneur']);
            $data[$k]['technology'] = explode('<br/>',$value['technology']);
            $data[$k]['creative_design'] = explode('<br/>',$value['creative_design']);

            $data[$k]['certification'] = empty($value['certification'])?[]:explode(',',$value['certification']);
        }

        $rst['code'] = 200;
        $rst['data'] = $data;
        $this->ajaxReturn($rst);
    }

}