<template>
  <el-button size="mini" icon="el-icon-download" @click.native.prevent="exportExcel">{{buttonName}}</el-button>
</template>

<script>
  import XLSX from 'xlsx';
  import '@/vendor/xlsx.full.min.js'
  import saveAs from 'file-saver/dist/FileSaver.min'
  export default {
    name: "export-data",
    props: ['exportData', 'exportName', 'buttonName'],
    methods: {
      exportExcel() {
        let wopts = {bookType: 'xlsx', bookSST: false, type: 'binary'};

        let wb = {SheetNames: ['Sheet1'], Sheets: {}, Props: {}};
        wb.Sheets['Sheet1'] = XLSX.utils.json_to_sheet(this.exportData);

        let str = XLSX.write(wb, wopts);
        let buffer = new ArrayBuffer(str.length);
        let view = new Uint8Array(buffer);
        for (let i = 0; i != str.length; ++i) view[i] = str.charCodeAt(i) & 0xFF;

        let e = document.createElement('a');
        e.download = this.exportName + '.xlsx';
        e.style.display = 'none';

        let blob = new Blob([buffer], {type: "application/octet-stream"});
        e.href = URL.createObjectURL(blob);

        document.body.appendChild(e);
        e.click();
        document.body.removeChild(e);
      },
    }
  }
</script>

<style scoped>

</style>
