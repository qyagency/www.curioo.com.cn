<template>
  <span>
    <el-button @click.native.prevent="openEdit" type="text" size="mini">{{btn_name}}</el-button>
    <el-dialog
      append-to-body
      class="editComponent"
      :title="title"
      :visible="visible"
      :before-close="handClose">
      <el-form :model="data" :rules="rules" ref="editForm" label-width="170px">
        <template v-for="item in field">
          <el-form-item :label="item.label" :prop="item.field">
            <template v-if="item.type==='image'">
              <Upload :file-list.sync="data[item.field]" :limit="item.limit"
                      :tip="item.tip" :toOss="item.toOss"></Upload>
            </template>
            <template v-else-if="item.type==='video'">
              <UploadVideo :file-list.sync="data[item.field]" :limit="item.limit"
                           :tip="item.tip" :toOss="item.toOss"></UploadVideo>
            </template>
            <template v-else-if="item.type==='number'">
              <el-input-number size="mini" v-model="data[item.field]" :min="1" :max="99"></el-input-number>
            </template>
            <template v-else-if="item.type==='select_one'">
              <el-select v-model="data[item.field]" placeholder="请选择">
                <el-option
                  v-for="ie in item.option"
                  :key="ie.value"
                  :label="ie.label"
                  :value="ie.value">
                </el-option>
              </el-select>
            </template>
            <template v-else-if="item.type==='input'">
              <el-input size="mini" type="text" v-model="data[item.field]"></el-input>
            </template>
            <template v-else-if="item.type==='date'">
              <el-date-picker
                v-model="data[item.field]"
                type="date"
                format="yyyy/MM/dd"
                value-format="yyyy/MM/dd"
                placeholder="选择日期">
              </el-date-picker>
            </template>
            <template v-else-if="item.type==='textarea'">
              <el-input size="mini" type="textarea" v-model="data[item.field]"></el-input>
            </template>
            <template v-else-if="item.type==='sort'">
              <el-input-number v-model="data[item.field]" :min="1" :max="999" label="描述文字"></el-input-number>
            </template>
            <template v-else-if="item.type==='specs'">
              <Specs :specs-data.sync="data[item.field]" :option.sync="item.option"></Specs>
            </template>
            <template v-else-if="item.type==='editor'">
                <quill-editor ref="text" v-model="data[item.field]" class="myQuillEditor" :options="editorOption"/>
            </template>
            <template v-else-if="item.type==='checkbox'">
              <el-checkbox v-model="data[item.field]"></el-checkbox>
            </template>
            <template v-else-if="item.type==='select_one_search'">
              <el-select v-model="data[item.field]" filterable placeholder="请选择">
                <el-option
                  v-for="ie in item.option"
                  :key="ie.value"
                  :label="ie.label"
                  :value="ie.value">
                </el-option>
              </el-select>
            </template>
            <template v-else-if="item.type==='showMsg'">
                <el-row>
                  <template v-for="ie in item.labelGroups">
                      <el-col :span="ie.col" v-if="data[ie.field]">
                        <span style="font-weight: bold">{{ie.label}}</span>
                        <template v-if="ie.mapping">
                          <span>{{ie.mapping[data[ie.field]]}}</span>
                        </template>
                        <template v-else>
                            <span>{{data[ie.field]}}</span>
                        </template>
                      </el-col>
                    </template>
                </el-row>
            </template>
          </el-form-item>
        </template>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button size="mini" @click.native.prevent="handClose(true)">{{$t('page.Cancel')}}</el-button>
        <el-button size="mini" type="primary" @click.native.prevent="update">{{$t('page.OK')}}</el-button>
      </span>
    </el-dialog>
  </span>
</template>

<script>
  import Global from '@/api/global_variable'

  import Upload from '@/components/upload'
  import UploadVideo from '@/components/upload_for_news'
  import Specs from '@/components/EditBox/specs'
  import {quillEditor} from 'vue-quill-editor'
  import {quillRedefine} from 'vue-quill-editor-upload'
  // 引入富文本的css
  import 'quill/dist/quill.core.css'
  import 'quill/dist/quill.snow.css'
  import 'quill/dist/quill.bubble.css'
  import {getToken} from '@/utils/auth'

  export default {
    name: "index",
    props: ['title', 'data', 'field', 'btn_name'],
    components: {Upload, Specs, quillEditor, quillRedefine, UploadVideo},
    data() {
      return {
        visible: false,
        editorOption: {},
        data_iso: {}
      }
    },
    computed: {
      rules() {
        let dd = {}
        for (let i in this.field) {
          let dom = this.field[i];
          if (dom.required) {
            dd[dom.field] = {required: true, message: '该项为必填项', trigger: 'blur'};
          }
        }
        return dd;
      }
    },
    methods: {
      handClose(flag) {
        if (flag == true) {
          this.visible = false;
        }
      },
      openEdit() {
        // console.log('打开', this.data)
        if (this.data && this.data.content) {
          this.editorOption = quillRedefine(
            {
              uploadConfig: {
                action: Global.ROOT_URL + '/uploadImg/uploadImg',
                token: getToken(),
                res: (respnse) => {
                  return respnse.file
                },
                name: 'upload_file',
              }
            }
          )
        }
        this.visible = true;
        this.data_iso = JSON.parse(JSON.stringify(this.data));
        // console.log('打开',this.data_iso)

      },
      update() {
        this.$refs['editForm'].validate((valid) => {
          if (valid) {
            this.$confirm('确认操作？').then(() => {

              this.$emit('update', this.data, () => {
                this.visible = false;
                // this.data = this.data_iso;
                this.$emit('update:data',this.data_iso)
                // console.log('关闭',this.data_iso)
              })
            }).catch(() => {
            })
          }
        });
      },
    },
    mounted() {
      this.editorOption = quillRedefine(
        {
          uploadConfig: {
            action: Global.ROOT_URL + '/uploadImg/uploadImg',
            token: getToken(),
            res: (respnse) => {
              return respnse.file
            },
            name: 'upload_file',
          }
        }
      )
    }
  }
</script>

<style>
  .editComponent .el-dialog__headerbtn {
    display: none;
  }

  .el-tag {
    margin: 0 5px;
  }
</style>
