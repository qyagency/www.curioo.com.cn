<template>
  <div style="height:500px;overflow-y: auto">
    <el-checkbox-group v-model="specsDefaultList">
      <el-checkbox v-for="(item,key) in specsNameList" :key="key" :label="item.value">{{item.label}}</el-checkbox>
    </el-checkbox-group>
    <template v-for="items in specsValueList" v-if="specsDefaultList.includes(items.type)">
      <div>{{items.name}}</div>
      <template>
        <el-checkbox-group v-model="items.checked">
          <el-checkbox v-for="(item,key) in items['value']" :key="key" :label="item.id">
            {{item.value}}
          </el-checkbox>
        </el-checkbox-group>
      </template>
    </template>
    <el-table border :data="specsValueTable" :span-method="SpanMethod">
      <el-table-column label="类型" prop="name"></el-table-column>
      <el-table-column label="值" prop="specs_name"></el-table-column>
      <el-table-column label="价格" prop="price">
        <template slot-scope="scope">
          <el-input type="number" v-model="scope.row.price"></el-input>
        </template>
      </el-table-column>
      <el-table-column label="默认值" prop="is_default">
        <template slot-scope="scope">
          <el-button type="warning" size="mini" @click.native.prevent="toDefault(scope.row)"
                     v-if="scope.row.is_default==0">设置成默认
          </el-button>
          <el-button type="text" @click.native.prevent="toDefault(scope.row)" v-else>默认</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
  export default {
    name: "specs",
    props: ['specsData', 'option'],
    data() {
      return {
        specsDefaultList: [],
        valueDefaultList: {},
        specsValueList: [],
        specsNameList: [],
        specsValueTable: [],
      }
    },
    methods: {
      toDefault(data) {
        // console.log()
        // console.log(data.type,data.id)
        this.specsValueList.forEach(items => {
          if (items.type == data.type) {
            items.default = data.id
          }
        })
        // console.log('arr',this.specsValueList)
        // let type = data.type;
        // this.specsValueTable.forEach(items => {
        //   if (items.type == data.type) {
        //     items.is_default = 0
        //     if (items.id == data.id) {
        //       items.is_default = data.id
        //     }
        //   }
        // })
        //
        // for (let i in this.specsData) {
        //   let lock = false;
        //   for (let j in this.specsData[i]) {
        //     if (this.specsData[i][j]['type'] == type) {
        //       lock = true
        //       this.specsData[i][j]['is_default'] = 0;
        //       if (this.specsData[i][j]['specs_id'] == data.id) {
        //         this.specsData[i][j]['is_default'] = 1;
        //       }
        //     }
        //   }
        //   if (lock) {
        //     break;
        //   }
        // }

        // console.log()
      },
      SpanMethod({row, column, rowIndex, columnIndex}) {
        let data = [];
        let end = {};
        this.specsValueTable.forEach((items, index) => {

          if (!data[items.type]) {
            data[items.type] = [index];
          } else {
            data[items.type].push(index)
          }
        });
        data.forEach(items => {
          let row = items.length;
          items.forEach(item => {
            end[item] = row;
            row = 0;
          })
        })
        if (columnIndex === 0) {
          return {
            rowspan: end[rowIndex],
            colspan: 1
          };
        }
      },
      getValueList(typeInput) {
        let data = [];
        for (let i in this.specsData) {
          let type = '';
          for (let j in this.specsData[i]) {
            type = this.specsData[i][j]['type'];
            if (typeInput == type) {
              data.push(this.specsData[i][j]['specs_id']);
            }
          }
        }
        return data;
      },
      getDefaultId(typeInput) {
        let data = '';
        for (let i in this.specsData) {
          let type = '';
          for (let j in this.specsData[i]) {
            type = this.specsData[i][j]['type'];
            if (typeInput == type && this.specsData[i][j]['is_default'] == 1) {
              data = this.specsData[i][j]['specs_id'];
            }
          }
        }
        return data;
      },
      formatData() {


        /**
         *
         * id: "1"
         is_default: 1
         name: "规格"
         price: "0.01"
         specs_name: "小"
         type: "1"
         *
         * **/
          // console.log('data', this.specsData)
          // let data = {}
        let data = {};
        this.specsValueTable.forEach(specsItem => {
          let id = specsItem.id;
          let is_default = specsItem.is_default;
          let specs_name = specsItem.name;
          let price = specsItem.price;
          let specs_value = specsItem.specs_name;
          let type = specsItem.type;
          let dist = {
            is_default: is_default == 1 ? 1 : 0,
            price: price,
            specs_id: id,
            specs_name: specs_name,
            sepcs_value: specs_value,
            type: type
          };
          if (data[type]) {
            data[type].push(dist);
          } else {
            data[type] = [dist]
          }
        });
        let arr = [];
        for (let i in data) {
          arr.push(data[i])
        }
        this.$emit('update:specsData', arr);
        console.log('this.specsValueTable',this.specsValueTable)
        console.log('data', this.specsData,arr)
      }
    },
    watch: {
      specsValueList: {
        handler() {
          this.specsValueTable = [];
          let priceMapping = {};
          // console.log('dddd', this.specsData)
          this.specsData.forEach(items => {
            items.forEach(item => {
              priceMapping[item.specs_id] = item.price
            })
          });
          this.specsValueList.forEach((items) => {

            let mapping = {};
            items.value.forEach((item) => {
              mapping[item.id] = item.value
            });
            items.checked.forEach((item) => {
              let dd = {}
              dd['name'] = items.name;
              dd['type'] = items.type;
              dd['id'] = item;
              dd['specs_name'] = mapping[item];
              dd['price'] = priceMapping[item];
              dd['is_default'] = items.default == item ? 1 : 0;
              this.specsValueTable.push(dd);
            })
          });
          // console.log('specsValueTable',this.specsValueTable)

        },
        deep: true
      },
      specsValueTable: {
        handler() {
          this.formatData()
        },
        deep: true
      }
    },
    mounted() {

      this.specsNameList = [];
      for (let i in this.option) {
        let dd = {};
        dd['value'] = this.option[i]['type'];
        dd['label'] = this.option[i]['specs_name'];

        this.specsNameList.push(dd)
      }
      this.specsDefaultList = [];
      for (let i in this.specsData) {
        let type = this.specsData[i][0]['type'];
        if (!this.specsDefaultList.includes(type)) {
          this.specsDefaultList.push(type)
        }
      }
      this.specsValueList = [];
      for (let i in this.option) {
        let ddd = [];
        let type = this.option[i]['type'];
        let name = this.option[i]['specs_name'];
        for (let j in this.option[i]['value']) {
          let dd = {};
          dd['value'] = this.option[i]['value'][j]['value'];
          dd['id'] = this.option[i]['value'][j]['id'];
          // dd['price']
          ddd.push(dd)
        }
        this.specsValueList.push({
          type: type,
          name: name,
          checked: this.getValueList(type),
          value: ddd,
          default: this.getDefaultId(type)
        });
      }
    }
  }
</script>

<style scoped>

</style>
