<template>
  <div class="langStyle">
    <el-switch
      @change="btnChange"
      v-model="value"
      active-text="中文"
      inactive-text="EN">
    </el-switch>
  </div>

</template>

<script>
  import {setCookie,getCookie} from '@/utils/auth'
  const pageLang = getCookie('getLang')=='en'?false:true
  export default {
    name: "lang",
    data() {
      return {
        value: pageLang
      }
    },
    methods:{
      btnChange(){
        // console.log(this.value);
        let lang = this.value==true?'cn':'en';
        setCookie('getLang',lang);
        localStorage.setItem('lang',lang)
        window.location.reload();
      }
    }
  }
</script>

<style scoped>
  .langStyle {
    padding: 15px 100px;
    float: left;
    height: 100%;
  }
</style>
