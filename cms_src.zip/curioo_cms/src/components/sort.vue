<template>
  <el-button size="mini" type="text" @click.native.prevent="sortFun">{{btn_text}}<i
    class="el-icon-refresh el-icon--right"></i></el-button>
</template>

<script>
  export default {
    name: "sort",
    props: ['input_data', 'field', 'btn_text', 'isChinese'],
    data() {
      return {
        sortStatus: true
      }
    },
    methods: {
      sortFun() {
        let field = this.field;
        let compareAsc = null;
        let compareDesc = null;
        if (this.isChinese == 'true') {
          compareAsc = function () {
            return function (a, b) {
              return a[field].localeCompare(b[field], 'zh-CN')
            }
          };
          compareDesc = function () {
            return function (a, b) {
              return b[field].localeCompare(a[field], 'zh-CN')
            }
          };
        } else {
          compareAsc = function () {
            return function (a, b) {
              return a[field] - b[field];
            }
          };
          compareDesc = function () {
            return function (a, b) {
              return b[field] - a[field];
            }
          };
        }
        if (!this.sortStatus) {
          // 倒序
          this.input_data.sort(compareDesc());
        } else {
          // 正序
          this.input_data.sort(compareAsc());
        }
        this.sortStatus = !this.sortStatus;
      },
    }
  }
</script>

<style scoped>

</style>
