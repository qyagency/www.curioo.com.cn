<template>
  <el-pagination
    background
    layout="prev, pager, next"
    :page-size="pageSize"
    :current-page="currentPage"
    @current-change="handleCurrentChange"
    :total="totalPage">
  </el-pagination>
</template>

<script>
  export default {
    name: "pagination",
    props: ['input_data', 'output_data'],
    data() {
      return {
        pageSize: 50,
        currentPage: 1,
        totalPage: 1,
        data: []
      }
    },
    watch: {
      input_data: {
        handler(newVal) {
          this.data = newVal;
          this.currentPage = 1;
          this.changePage(this.data);
        }
      }
    },
    methods: {
      handleCurrentChange(currentPage) {
        this.currentPage = currentPage;
        this.changePage(this.data);
      },
      changePage(data) {
        let start = (this.currentPage - 1) * this.pageSize;
        let end = this.currentPage * this.pageSize;
        this.$emit('update:output_data', data.slice(start, end));
        this.totalPage = data.length;
      }
    }
  }
</script>

<style scoped>

</style>
