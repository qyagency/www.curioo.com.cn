<template>
  <div style="display: inline-block">
    <el-button type="primary" size="mini" @click.native.prevent="openDetail()">预览</el-button>
    <el-dialog
      :visible.sync="openDetailVisible"
      width="30%"
      :before-close="opedDetailHandleClose"
    >
      <el-image :src="openDetailUrl" style="display:block;margin: 0 auto">
        <div slot="placeholder" class="image-slot">
          loading<span class="dot">...</span>
        </div>
      </el-image>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: "preview-btn",
    props:['openDetailUrl'],
    data() {
      return {
        openDetailVisible: false,
      }
    },
    methods: {
      opedDetailHandleClose() {
        this.openDetailVisible = false;
      },
      openDetail() {
        this.openDetailVisible = true;
      },
    }
  }
</script>

<style scoped>

</style>
