<template>
  <el-input :type="filterType" v-model="input" :placeholder="placeholder"></el-input>
</template>

<script>
  export default {
    name: "filter_input",
    props: ['filterType', 'inputData', 'outputData', 'field' ,'placeholder'],
    data() {
      return {
        input: ''
      }
    },
    watch: {
      input() {
        let allData = this.inputData;
        let data = [];
        for (let i in allData) {
          let item = allData[i];
          for (let j in this.field) {
            let field = this.field[j];
            let lower = item[field].toLowerCase();
            if (lower.includes(this.input.toLowerCase())) {
              data.push(item);
              break;
            }
          }
        }
        // this.outputData = data;
        this.$emit('update:outputData', data)
      }
    }
  }
</script>

<style scoped>

</style>
