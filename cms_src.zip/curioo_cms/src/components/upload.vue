<template>
  <div>
    <div style="overflow: hidden">
      <div class="img-Group img-Group-img-box" v-if="fileList.length>0" v-for="(item,index) in fileList"
           @mouseenter="mouseEnter(index)"
           @mouseleave="mouseLeave">
        <el-image class="img-Group-img" fit="contain" :src="item"></el-image>
        <div v-if="mouseNumber===index" class="img-Group-img deleteMask" @click="fileRemove(index)">
          <i class="el-icon-delete deleteBtn"></i></div>
      </div>
      <div class="input-button img-Group" v-if="fileList.length<limit">
        <input accept="image/*" ref="imgSelect" id="upfile" class="input-button-main" type="file"
               @change="fileChange"/>
        <el-button @click="fileTake"
                   icon="el-icon-plus"></el-button>
      </div>

    </div>
    <div v-if="tip">{{tip}}</div>
  </div>
</template>

<script>
  import {uploadImg} from '@/api/common'
  import Global from '@/api/global_variable'

  const OSS = require('ali-oss')

  export default {
    name: "upload",
    props: ['fileList', 'limit', 'tip', 'toOss'],
    data() {
      return {
        mouseNumber: null
      }
    },
    methods: {
      fileTake() {
        this.$refs['imgSelect'].click()
      },
      mouseEnter(index) {
        this.mouseNumber = index;
      },
      mouseLeave() {
        this.mouseNumber = null;
      },
      fileChange() {
        const loading = this.$loading({
          lock: true,
          text: '拼命上传中,请耐心等待',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        });
        console.log('是否上传oss', this.toOss)
        if (!this.toOss) {
          let fileObj = this.$refs['imgSelect'].files[0];
          let formData = new window.FormData();
          formData.append('file', fileObj);
          uploadImg(formData).then((response) => {
            loading.close();
            if (response.code === 200) {
              this.fileList.push(response.file);
            } else {
              this.$message.error(response.msg)
            }
          })
        } else {
          let client = OSS({
            region: 'oss-cn-shanghai',
            accessKeyId: 'LTAIZMqsT2L0wcsX',
            accessKeySecret: '0jY9JSC7VUR9nyIYVSaJN4eAvOp6yV',
            bucket: 'incker'
          })
          // console.log(this.$refs['imgSelect'].files)
          const Name = this.$refs['imgSelect'].files[0].name
          const suffix = Name.substr(Name.indexOf('.'))              // 文件后缀
          const filename = 'aq-cafe/' + Date.parse(new Date()) + suffix           // 组成新文件名

          client.multipartUpload(filename, this.$refs['imgSelect'].files[0]).then(res => {   // 上传
            // console.log('上传成功：', res)
            loading.close();
            let file = Global.OSS_URL + '/' + res.name;
            console.log('文件',file)
            this.fileList.push(file);
            // ... 你的操作，可以拼接图片url，用于显示等...
          }).catch(err => {
            console.log('上传失败：', err);
            this.$message.error('上传失败')
          })
        }

      },
      fileRemove(index) {
        this.fileList.splice(index, 1);
      }
    },
    mounted() {
      console.log('init-child')
    }
  }
</script>

<style scoped>
  .img-Group {
    float: left;
    margin: 0 5px;
    border: 1px #bbbbbb dotted;
    width: 100px;
    height: 100px;
    position: relative;
  }

  .img-Group-img {
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
  }

  .deleteMask {
    background: rgba(0, 0, 0, 0.5);
    cursor: pointer;
  }

  .deleteBtn {
    color: #fff;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }

  .input-button * {
    display: block;
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    border: 0;
  }

  .input-button-main {
    display: none;
    cursor: pointer;
  }
</style>
