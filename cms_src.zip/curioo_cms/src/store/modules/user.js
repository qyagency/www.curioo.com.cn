import {logout} from '@/api/user'
import {login, getUserInfo} from '@/api/login'
import {getToken, setToken, removeToken, setCookie} from '@/utils/auth'
import {resetRouter} from '@/router'

const state = {
  token: getToken(),
  name: '',
  avatar: ''
}

const mutations = {
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  }
}

const actions = {
  // user login
  login({commit}, userInfo) {
    const {admin_name, admin_pwd} = userInfo
    return new Promise((resolve, reject) => {
      login({admin_name: admin_name.trim(), admin_pwd: admin_pwd}).then(response => {
        if (response.code === 200) {
          const data = response
          // TODO 返回token
          // data['token'] = 'admin-token';
          commit('SET_TOKEN', data.token);
          setToken(data.token);
          setCookie('admin_id', data.id);

        }
        resolve(response)
      }).catch(error => {
        reject(error)
      })
    })
  },
  // get user info
  getInfo({commit, state}) {
    return new Promise((resolve, reject) => {
      getUserInfo(state.token).then(response => {
        console.log(response,response);
        // TODO 返回权限表
        const {data} = response;

        if (!data) {
          reject('Verification failed, please Login again.')
        }

        const {name, avatar} = data;

        commit('SET_NAME', name);
        setCookie('admin_name', name);
        commit('SET_AVATAR', avatar);
        resolve(data)
      }).catch(error => {
        console.log(error)
        reject(error)
      })
    })
  },

  // user logout
  logout({commit, state}) {
    return new Promise((resolve, reject) => {
      logout(state.token).then(() => {
        commit('SET_TOKEN', '')
        removeToken()
        resetRouter()
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // remove token
  resetToken({commit}) {
    return new Promise(resolve => {
      commit('SET_TOKEN', '')
      removeToken()
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

