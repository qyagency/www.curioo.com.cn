import {asyncRoutes, constantRoutes} from '@/router'

/**
 * 判断
 * @param roleGroup
 * @param route
 */
function hasPermission(roleGroup, route) {
  if (route.meta && route.meta.roles) {
    //判断是否存在
    return roleGroup.some(role=>role===route.meta.roles);
    // return true
  } else {
    // 没有定义直接直接添加
    return true
  }
}

/**
 * 过滤
 * @param routes asyncRoutes
 * @param roleGroup
 */
export function filterAsyncRoutes(routes, roleGroup) {
  const res = []
  routes.forEach(route => {
    const tmp = {...route}
    if (hasPermission(roleGroup, tmp)) {
      if (tmp.children) {
        tmp.children = filterAsyncRoutes(tmp.children, roleGroup)
      }
      res.push(tmp)
    }
  })
  // console.log('返回',res)
  return res
}

const state = {
  routes: [],
  addRoutes: []
}

const mutations = {
  SET_ROUTES: (state, routes) => {
    state.addRoutes = routes
    state.routes = constantRoutes.concat(routes)
  }
}

const actions = {
  generateRoutes({commit}, {roles, roleGroup}) {
    // console.log('获取',roles,roleGroup)
    return new Promise(resolve => {
      let accessedRoutes
      // admin的所有栏目都能访问
      if (roles.includes('admin')) {
        accessedRoutes = asyncRoutes || []
      } else {
        accessedRoutes = filterAsyncRoutes(asyncRoutes, roleGroup )
      }
      // console.log(asyncRoutes,roleGroup,'asy');
      // console.log('权限', roles)
      commit('SET_ROUTES', accessedRoutes)
      resolve(accessedRoutes)
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}
