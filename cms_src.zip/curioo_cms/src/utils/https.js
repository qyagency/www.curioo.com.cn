import axios from 'axios'
import qs from 'qs'
import {getToken,getCookie} from '@/utils/auth'
import {showLoading,hideLoading} from "@/api/loading";
import store from '@/store'
import router from '@/router'
import { Message } from 'element-ui'

let lang = getCookie('getLang')?getCookie('getLang'):'cn';
axios.defaults.timeout = 300000;                        //响应时间
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';        //配置请求头
axios.defaults.baseURL = '';   //配置接口地址

axios.interceptors.request.use((config) => {


  if (config.method === 'post' && config.url.indexOf("upload") === -1) {
    config.data = qs.stringify(config.data)
  }
  if(config.url.indexOf("newOrderJoin") === -1){
    showLoading()
  }
  return config;
}, (error) => {
  console.log('错误的传参');
  return Promise.reject(error)
})

// 返回状态判断(添加响应拦截器)
axios.interceptors.response.use((res) => {
  hideLoading();
  //对响应数据做些事
  if(res.data.code===504){
    // 被迫登出
    // console.log(store)
    // store.dispatch('user/logout').then(response=>{
    //   console.log()
    //   // router.push(`/login`);
    //   // window.location.reload();
    // });
    logout();


  }else{
    return res.data;
  }
  // console.log('返回',res)

}, (error) => {
  console.log('网络异常')
  return Promise.reject(error);
});

async function logout() {
  await store.dispatch('user/logout')
  router.push(`/login`);
  Message.error('您的账号在异地被登录，请确认为本人操作。')
  // window.location.reload();
}

/*//返回一个Promise(发送post请求)
export function post(url, params) {
  axios.defaults.headers.post['Token'] = getToken();        //配置请求头
  axios.defaults.headers.post['lang'] = lang;
  return axios.post(url, params);
}*/

export function post(url, params) {
  return new Promise((resolve, reject) => {
    axios.defaults.headers.post['Token'] = getToken();        //配置请求头
    axios.defaults.headers.post['lang'] = lang;
    axios.post(url, params).then(response => {
      if((typeof response) == 'string'){
        var rst = JSON.parse(response.trim());
      }else{
        var rst = response;
      }
      resolve(rst);
    }, err => {
      reject(err);
    })
      .catch((error) => {
        reject(error)
      })
  })
}

//返回一个Promise(发送file请求)
export function file(url, params) {
  axios.defaults.headers.post['Token'] = getToken();        //配置请求头
  return axios.post(url, params, {
    headers: {
      'Content-Type': 'multipart/form-data',
    }
  })
}
/*
////返回一个Promise(发送get请求)
export function get(url, param) {
  axios.defaults.headers.get['Token'] = getToken();        //配置请求头
  axios.defaults.headers.get['lang'] = lang;
  return axios.get(url, {params: param});
}*/
////返回一个Promise(发送get请求)
export function get(url, param) {
  // console.log('get请求',url,param)
  return new Promise((resolve, reject) => {
    axios.defaults.headers.get['Token'] = getToken();        //配置请求头
    axios.defaults.headers.get['lang'] = lang;
    axios.get(url, {params: param}).then(response => {
      if((typeof response) == 'string'){
        var rst = JSON.parse(response.trim());
      }else{
        var rst = response;
      }
      resolve(rst)
    }, err => {
      reject(err)
    }).catch((error) => {
      reject(error)
    })
  })
}
export default {
  post,
  get,
  file
}
