<template>
  <div class="app-container">
    <el-form :model="humanData" label-width="100px">
      <el-form-item :label="$t('page.AccountNumber')">
        <div>{{humanData.admin_name}}</div>
      </el-form-item>
      <el-form-item :label="$t('page.Username')">
        <div>{{humanData.show_name}}</div>
      </el-form-item>
      <el-form-item :label="$t('page.Area')">
        <div>{{storeMapping[humanData.store_id]}}</div>
      </el-form-item>
      <el-form-item :label="$t('page.Store')">
        <el-row>
          <el-col :span="4">
            <el-select v-model="humanData.store_id" @change="changeStore(humanData.store_id)" filterable :placeholder="$t('page.PleaseSelect')">
              <el-option
                v-for="ie in storeOption"
                :key="ie.value"
                :label="ie.label"
                :value="ie.value">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
      </el-form-item>
    </el-form>
    <el-form label-width="100px" :inline="true">
      <el-form-item :label="$t('page.Channel')">
        <el-select v-model="humanData.channel" @change="channelChange('channel')" filterable :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in channelOption"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('page.Point/Media')">
        <el-select v-model="humanData.point_position" @change="channelChange('point_position')" filterable :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in point_positionOption"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('page.City')">
        <el-select v-model="humanData.city"  @change="channelChange('city')" filterable :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in cityOption"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <el-form label-width="100px" :inline="true">
      <el-form-item :label="$t('page.Activity')">
        <el-select v-model="humanData.activity"  @change="channelChange('activity')" filterable :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in activityOption"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('page.Offer')">
        <el-select v-model="humanData.offer"  @change="channelChange('offer')" filterable :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in offerOption"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <el-form label-width="100px" :model="humanData">
      <el-form-item :label="$t('page.PersonalQRCode')">
        <el-image :src="humanData.qrcode"></el-image>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  import {getOptions,query,changeStoreId,channelChange} from "@/api/staff";
  import {channel_option} from '@/api/activity'

  import {getCookie} from "../../utils/auth";

  export default {
    name: "index",
    data() {
      return {
        humanData: {},
        storeOption:[],
        storeMapping:{},
        channelOption:[],
        point_positionOption:[],
        cityOption:[],
        activityOption:[],
        offerOption:[],
        activityMapping:{}
      }
    },
    methods:{
      getStaffInfo(){
        let updateData= {
          admin_name:getCookie('admin_name')
        }
        query(updateData).then(response=>{
          if(response.code===200){
            this.humanData = response.data;
          }
        })
      },
      getOptions(){
        getOptions().then(response=>{
          if(response.code===200){
            let storeData = response.storeOption;
            // let activityData = response.activityOption;
            this.storeOption = storeData.option;
            this.storeMapping = storeData.mapping;
            // this.activityOption = activityData.option;
            // this.activityMapping = activityData.mapping;
            this.getStaffInfo()
          }
        })
      },
      changeStore(store_id){
        if(store_id){
          let updateData = {
            store_id:store_id
          }
          changeStoreId(updateData).then(response=>{
            if(response.code===200){
              this.$message.success(this.$t('page.SuccessfullyModifiedTheStore'))
            }
          }).catch(error=>{
            this.$message.error(this.$t('page.FailedToModifyStore'))
          })
        }
      },
      channelChange(flg){
        // console.log(flg)
        // console.log(this.humanData[flg])
        let updateData = {};
        if(flg){
          updateData[flg] = this.humanData[flg];
          channelChange(updateData).then(response=>{
            if(response.code===200){
              this.$message.success(this.$t('page.ModificationSucceeded'));
              this.getStaffInfo();
            }else{
              this.$message.error(this.$t('page.ModificationFailed'));
            }
          })
        }

      },
      changeActivity(activity_id){
        if(activity_id){
          let updateData = {
            activity_id:activity_id
          }
          changeActivityId(updateData).then(response=>{
            if(response.code===200){
              this.$message.success('修改活动成功')
            }
          }).catch(error=>{
            this.$message.error('修改活动失败')
          })
        }
      },
      channel_option(){
        channel_option().then(response=>{
          console.log(response)
          if(response.code===200){
            this.channelOption = response.data.channel;
            this.point_positionOption = response.data.point_position;
            this.cityOption = response.data.city;
            this.activityOption = response.data.activity;
            this.offerOption = response.data.offer;
          }
        })
      }
    },
    mounted() {
      this.getOptions();
      this.channel_option();
    }
  }
</script>

<style scoped>

</style>
