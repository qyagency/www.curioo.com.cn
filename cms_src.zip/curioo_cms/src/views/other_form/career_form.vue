<template>
  <div class="app-container">
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column :label="$t('page.Name')" prop="user_name"></el-table-column>
      <el-table-column :label="$t('page.Phone')" prop="user_mobile"></el-table-column>
      <el-table-column :label="$t('page.Email')" prop="user_email"></el-table-column>
      <el-table-column :label="$t('page.Gender')" prop="gender"></el-table-column>
      <el-table-column :label="$t('page.Age')" prop="age"></el-table-column>
      <el-table-column :label="$t('page.Nationality')" prop="country"></el-table-column>
      <el-table-column :label="$t('page.Address')" prop="address"></el-table-column>
      <el-table-column :label="$t('page.Education')" prop="education"></el-table-column>
      <el-table-column :label="$t('page.Major')" prop="profession"></el-table-column>
      <el-table-column :label="$t('page.ApplyForJob')" prop="apply_for_job"></el-table-column>
      <el-table-column :label="$t('page.SubmissionTime')" prop="create_date"></el-table-column>
      <el-table-column :label="$t('page.Language')" prop="is_cn_text"></el-table-column>
      <el-table-column :label="$t('page.FileDown')" prop="file_path">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click="fileDown(index)" v-for="(index,num) in scope.row.file_arr">
            <span>文件{{num+1}}</span>
          </el-button>
        </template>
      </el-table-column>

    </el-table>
  </div>
</template>

<script>
  import {career_form} from "@/api/other_form";

  export default {
    name: "career_form",
    data(){
      return{
        filter_data:[],
        all_data:[],
      }
    },
    methods:{
      fileDown(row){
        let link = 'https://'+row;
        console.log(link);
        window.open(link);
      },
      query(){
        career_form().then(response=>{
          if(response.code===200){
            this.filter_data = response.data;
            this.all_data = response.data;
          }
        })
      }
    },
    mounted() {
      this.query();
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
  }
</script>

<style scoped>

</style>
