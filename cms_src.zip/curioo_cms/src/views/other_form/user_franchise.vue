<template>
  <div class="app-container">
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column :label="$t('page.Name')" prop="user_name"></el-table-column>
      <el-table-column :label="$t('page.Gender')" prop="user_mobile"></el-table-column>
      <el-table-column :label="$t('page.Email')" prop="user_email"></el-table-column>
      <el-table-column :label="$t('page.WhetherToOpenAStore')" prop="operate"></el-table-column>
      <el-table-column :label="$t('page.SubmissionTime')" prop="create_time"></el-table-column>
    </el-table>
  </div>
</template>

<script>
  import {franchise} from "@/api/other_form";

  export default {
    name: "user_franchise",
    data(){
      return{
        filter_data:[],
        all_data:[],
      }
    },
    methods:{
      query(){
        franchise().then(response=>{
          if(response.code===200){
            this.filter_data = response.data;
            this.all_data = response.data;
          }
        })
      }
    },
    mounted() {
      this.query();
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
  }
</script>

<style scoped>

</style>
