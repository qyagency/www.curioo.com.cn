<template>
  <div class="app-container">
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column :label="$t('page.Email')" prop="email"></el-table-column>
      <el-table-column :label="$t('page.SubmissionTime')" prop="create_time"></el-table-column>
    </el-table>
  </div>
</template>

<script>
  import {email} from "@/api/other_form";

  export default {
    name: "email",
    data(){
      return{
        filter_data:[],
        all_data:[],
      }
    },
    methods:{
      query(){
        email().then(response=>{
          if(response.code===200){
            this.filter_data = response.data;
            this.all_data = response.data;
          }
        })
      }
    },
    mounted() {
      this.query();
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
  }
</script>

<style scoped>

</style>
