<template>
  <div class="app-container">
    <el-row>
      <el-col :span="6">
        <el-button type="text" size="mini" @click.native.prevent="updateRow()">新增角色</el-button>
      </el-col>
      <el-col :span="6">
        <el-button size="mini" @click.native.prevent="updateRoleList">更新权限列表</el-button>
      </el-col>
    </el-row>
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column label="角色名称" prop="role_name"></el-table-column>

      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="text" size="mini" @click.native.prevent="updateRow(scope.row)">编辑</el-button>
          <el-button type="text" size="mini" @click.native.prevent="deleteRow(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <Roles
      :roles-visible.sync="rolesVisible"
      :roles-data.sync="rolesData"
      :default-role-list.sync="defaultRoleList"
      :field.sync="editField"
      v-on:createUpdateRoles="createUpdateRoles">

    </Roles>
  </div>
</template>

<script>
  import Roles from './roles'
  import {updateRoleList,updateRoles,getRoleList} from '@/api/admin'
  import {create,deleteRow,modify,query} from '@/api/role_list'
  import {asyncRoutes} from '@/router'

  export default {
    name: "role_list",
    components:{Roles},
    data() {
      return {
        all_data: [],
        filter_data: [],
        updateData: [],
        rolesVisible: false,
        defaultRoleList:[], //角色权限列表
        rolesData: [],
        baseRolesData:[],
        editField:{
          role_name:'',
          default_role_id:'',
        }
      }
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
    methods:{
      updateRow(data){
        if(data){
          this.editField = data;
          let user_role = data.role_group;
          this.rolesData = JSON.parse(JSON.stringify(this.baseRolesData))
          for (let i in this.rolesData) {
            let dom = this.rolesData[i];
            let role_name = dom.default;
            if (user_role && user_role[role_name]) {
              this.rolesData[i]['check'] = user_role[role_name];
            }
          }

        }else{
          this.editField.role_name = '';
          this.editField.default_role_id = '';
        }
        this.rolesVisible = true;
      },
      deleteRow(data){
        this.$confirm('确认删除？').then(() => {
          let updateData = {
            id: data.id
          }

          deleteRow(updateData).then(response => {
            if (response.code === 200) {
              window.location.reload()
            }
          })
        }).catch(() => {
        })
      },
      createUpdateRoles(data,editField){
        console.log('提交',data,editField);
        let role_group = [];
        for (let i in data) {
          let dd = data[i];
          if (dd.check.length) {
            role_group.push(dd.default + ':' + dd.check.join(','))
          }
        }
        let updateData = {
          role_name:editField.role_name,
          role_group:role_group.join('|'),
          default_role_id:editField.default_role_id
        }

        // console.log(updateData);return false;

        if(editField.id){
          updateData.id = editField.id
          modify(updateData).then(response=>{
            if(response.code===200){
              this.rolesVisible = false;
              window.location.reload()
            }
          })
        }else{
          create(updateData).then(response=>{
            if(response.code===200){
              this.rolesVisible = false;
              window.location.reload()
            }
          })
        }
      },
      updateRoleList() {
        let data = asyncRoutes;
        for (let i in data) {
          let item = data[i];

          if (item.meta && item.meta.roles) {

            let dd = {
              parent_name: 'root_default',
              role_name: item.meta.title,
              role_value: item.meta.roles
            };

            this.updateData.push(dd);
            let children_group = item.children;
            for (let j in children_group) {
              let child_item = children_group[j];
              let child_dd = {
                parent_name: item.meta.title,
                role_name: child_item.meta.title,
                role_value: child_item.meta.roles
              };
              this.updateData.push(child_dd)
            }
          }
        }
        updateRoleList({data: JSON.stringify(this.updateData)}).then(response => {
          if (response.code === 200) {
            this.$message.success('更新成功');
            window.location.reload()
          }
        })
      },
      updateRole(data) {
        let role_group = [];
        for (let i in data) {
          let dd = data[i];
          if (dd.check.length) {
            role_group.push(dd.default + ':' + dd.check.join(','))
          }
        }
        let updateData = {
          admin_name: this.select_user,
          role_group: role_group.join('|')
        };
        updateRoles(updateData).then(response => {
          if (response.code === 200) {
            this.select_user = '';
            this.rolesVisible = false;
            window.location.reload()
          }
        })
      },
      getRoleList() {
        getRoleList().then(response => {
          if (response.code === 200) {
            this.rolesData = response.data;
            this.baseRolesData = JSON.parse(JSON.stringify(response.data))
          }
        })
      },
      query(){
        query().then(response=>{
          if(response.code===200){
            this.editField.role_name = '';
            this.filter_data = response.data;
            this.all_data = response.data;
            this.defaultRoleList = response.default_role_list;
            this.getRoleList();
          }
        })
      },
    },
    mounted() {
      this.query();

    }
  }
</script>

<style scoped>

</style>
