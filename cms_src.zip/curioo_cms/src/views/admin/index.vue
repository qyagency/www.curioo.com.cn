<template>
  <div class="app-container">
    <el-row>
      <el-col :span="6">
        <el-button size="mini" @click.native.prevent="addRow">{{$t('page.Add')}}</el-button>
      </el-col>
    </el-row>
    <el-table :data="show_data" :height="tableHeight">
      <el-table-column :label="$t('page.AccountNumber')" prop="admin_name"></el-table-column>
      <el-table-column :label="$t('page.Username')" prop="show_name"></el-table-column>
      <el-table-column :label="$t('page.Store')" prop="store_name"></el-table-column>
      <el-table-column :label="$t('page.RoleName')" prop="role_name"></el-table-column>
      <el-table-column :label="$t('page.CreatedBy')" prop="created_by_name"></el-table-column>
      <el-table-column prop="last_login_ip" :label="$t('page.LastLoginIP')"></el-table-column>
      <el-table-column prop="last_login_time" :label="$t('page.LastLoginTime')"></el-table-column>
      <el-table-column
        align="right"
        :label="$t('page.Operate')">
        <template slot-scope="scope">
          <el-button @click.native.prevent="editRow(scope.row)" type="text" size="mini">{{$t('page.Edit')}}</el-button>
          <el-button @click.native.prevent="deleteRow(scope.row)" type="text" size="mini">{{$t('page.Delete')}}</el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="all_data" :output_data.sync="show_data"></Pagination>

    <adminAdd
      :admin-add-visible.sync="adminAddVisible"
      :admin-add-data.sync="adminAddData"
      :admin-add-option.sync="roleSelectOption"
      :admin-add-storeoption.sync="humanStoreSelectOption"
      :edit-data-field.sync="editDataField"
      v-on:createAdminAccount="createAdminAccount">
    </adminAdd>
    <adminEdit
      :admin-edit-visible.sync="adminEditVisible"
      :admin-edit-data.sync="adminEditData"
      :admin-edit-option.sync="roleSelectOption"
      :admin-edit-storeoption.sync="humanStoreSelectOption"
      :edit-data-field.sync="editDataField"
      v-on:changePassword="changePassword"
      v-on:updateRole="updateRole"
    >
    </adminEdit>
  </div>
</template>

<script>
  import {
    getAdminAccountList,
    createAdminAccount,
    changePassword,
    deleteAdminAccount,
    getRoleForSelect,
    updateUserRole
  } from '@/api/admin'

  import {getStoreOptions} from '@/api/store_info'
  import Pagination from '@/components/pagination'
  import adminAdd from './component/admin_add'
  import adminEdit from './component/admin_edit'
  import {getCookie} from "../../utils/auth";
  export default {
    name: "index",
    components: {Pagination, adminAdd, adminEdit},
    data() {
      return {
        all_data: [],
        show_data: [],
        updateData: [],
        roleProps: {multiple: true},
        roleGroup: [],
        adminEditVisible: false,
        adminAddVisible: false,
        adminEditData: {},
        adminAddData: {},
        rolesVisible: false,
        rolesData: [],
        select_user: '',
        roleSelectOption:[],
        humanStoreSelectOption:[],
        editDataField:[], //可选择的数据权限
      }
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      }
    },
    methods: {
      addRow() {
        this.adminAddVisible = true;
      },
      editRow(data) {
        if (data.admin_name === 'admin' && getCookie('admin_name') !== 'admin') {
          this.$message.error(this.$t('page.TheHighestPermissionCannotBeEdited'))
        } else {
          this.adminEditData = data;
          this.adminEditVisible = true;
        }
      },
      updateRole(data){
        let updateData = {
          admin_name:data.admin_name,
          show_name:data.show_name,
          store_id:data.store_id,
          role_id:data.role_id,
          can_download:data.can_download,
          can_read_all:data.can_read_all,
          can_see_data:data.can_see_data
        }
        updateUserRole(updateData).then(response=>{
          if(response.code===200){
            this.adminEditVisible = false;
            this.getAdminAccountList();
          }
        })
      },
      deleteRow(data) {
        if (data.admin_name === 'admin') {
          this.$message.error(this.$t('page.TheHighestPermissionCannotBeDeleted'))
        } else {
          this.$confirm(this.$t('page.ConfirmDeletion')).then(() => {
            let deleteData = {
              id: data.id
            };
            deleteAdminAccount(deleteData).then((response) => {
              if (response.code === 200) {
                this.$message.success(this.$t('page.DeleteSucceeded'));
                this.data.splice(index, 1);
                this.getAdminAccountList();
              }
            })
          }).catch(() => {
            console.log('取消')
          })
        }
      },
      getAdminAccountList() {
        getAdminAccountList().then((response) => {
          if (response.code === 200) {
            this.all_data = response.list;
            this.getRoleForSelect();
            this.getStoreOptions();
          }
        })
      },
      changePassword(data, fn) {
        let changeData = {
          id: data.id,
          admin_pwd: data.admin_password
        };
        changePassword(changeData).then((response) => {
          if (response.code === 200) {
            fn();
          }
        })
      },
      createAdminAccount(data) {
        let createAdminData = {
          admin_name: data.admin_name,
          admin_pwd: data.admin_password,
          show_name:data.show_name,
          store_id:data.store_id,
          role_id:data.role_id,
          can_download:data.can_download,
          can_read_all:data.can_read_all,
          can_see_data:data.can_see_data
        };
        createAdminAccount(createAdminData).then((response) => {
          if (response.code === 200) {
            this.getAdminAccountList();
            this.adminAddVisible = false;
          } else {
            this.$message.error(response.msg)
          }
        })
      },
      getRoleForSelect(){
        getRoleForSelect().then(response=>{
          if(response.code===200){
            this.roleSelectOption = response.data;
            this.editDataField = response.edit_data_field;
          }
        })
      },
      getStoreOptions(){
        getStoreOptions().then(response=>{
          if(response.code===200){
            this.humanStoreSelectOption = response.data;
          }
        })
      }
    },
    mounted() {
      this.getAdminAccountList();
    }
  }
</script>

<style scoped>

</style>
