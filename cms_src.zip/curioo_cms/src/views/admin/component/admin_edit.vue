<template>
  <el-dialog class="admin_edit" :visible="adminEditVisible" :title="$t('page.Edit')" :before-close="handClose">
    <el-form :model="adminEditData" label-width="170px" ref="admin_edit" :rules="rules">
      <el-form-item :label="$t('page.AccountNumber')" prop="admin_name">
        <el-input size="mini" type="text" v-model="adminEditData.admin_name" readonly></el-input>
      </el-form-item>
      <el-form-item :label="$t('page.Username')" prop="show_name">
        <el-input size="mini" type="text" v-model="adminEditData.show_name"></el-input>
      </el-form-item>
      <el-form-item :label="$t('page.RoleName')" prop="role_id">
        <el-select v-model="adminEditData.role_id" filterable :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in adminEditOption"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('page.Store')" prop="store_id">
        <el-select v-model="adminEditData.store_id" filterable :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in adminEditStoreoption"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('page.DataAuth')" prop="can_see_data">
        <el-select v-model="adminEditData.can_see_data" :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in editDataField"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('page.CanDownload')">
        <el-switch
          v-model="adminEditData.can_download"
          active-value="1"
          inactive-value="0"
          :active-text="$t('page.yes')"
          :inactive-text="$t('page.no')">
        </el-switch>
      </el-form-item>
      <!--<el-form-item :label="$t('page.ViewAllInformation')">
        <el-switch
          v-model="adminEditData.can_read_all"
          active-value="1"
          inactive-value="0"
          :active-text="$t('page.yes')"
          :inactive-text="$t('page.no')">
        </el-switch>
      </el-form-item>-->
    </el-form>
    <el-form label-width="170px" :model="adminEditData" ref="admin_pwd_edit" :rules="rules_pwd">
      <el-form-item :label="$t('page.Password')" prop="admin_password">
        <el-row>
          <el-col :span="4">
            <el-button size="mini" @click.native.prevent="changePassword">修改</el-button>
          </el-col>
          <el-col :span="20" v-if="isChange">
            <el-col :span="14">
              <el-input size="mini" type="password" v-model="pwd" placeholder="6-32位字符,包括数字、大小写字母、特殊字符"></el-input>
            </el-col>
            <el-col :span="3">
              <el-button size="mini" type="primary" @click.native.prevent="sureChange">确定</el-button>
            </el-col>
            <el-col :span="3">
              <el-button size="mini" @click.native.prevent="cancelChange">取消</el-button>
            </el-col>
          </el-col>
        </el-row>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
        <el-button size="mini" @click.native.prevent="handClose(true)">取 消</el-button>
        <el-button size="mini" type="primary" @click.native.prevent="updateEdit()">确 定</el-button>
      </span>
  </el-dialog>
</template>

<script>
  export default {
    name: "admin_edit",
    props: ['adminEditVisible', 'adminEditData','adminEditOption','adminEditStoreoption','editDataField'],
    data() {
      let pwdValid = (rule, value, callback) => {
        let regex = new RegExp('(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[^a-zA-Z0-9]).{6,32}');
        if (!regex.test(value)) {
          callback(new Error(rule.message));
        } else {
          callback();
        }
      };
      return {
        isChange: false,
        pwd: '',
        rules: {
          admin_name: {required: true, message: '请输入管理员账号', trigger: 'blur'},
          role_id: {required: true, message: '请选择角色', trigger: 'blur'},
          show_name: {required: true, message: '请输入用户名', trigger: 'blur'},
          store_id: {required: true, message: '请选择用户门店', trigger: 'blur'},
          can_see_data: {required: true, message: '请选择', trigger: 'blur'},
        },
        rules_pwd: {
          admin_password: {validator: pwdValid, required: true, message: '密码格式错误，请根据要求设置（6-32位字符,包括数字、大小写字母、特殊字符）', trigger: 'change'},
        }
      }
    },
    watch: {
      pwd(newVal) {
        this.adminEditData['admin_password'] = newVal;
      }
    },
    methods: {
      handClose(flag) {
        if (flag == true) {
          this.$emit('update:adminEditVisible', false)
        }
      },
      updateEdit() {
        this.$emit('updateRole', this.adminEditData)
      },
      changePassword() {
        this.isChange = true;
      },
      cancelChange() {
        this.isChange = false;
      },
      sureChange() {

        this.$refs['admin_pwd_edit'].validate((valid) => {
          if (valid) {
            this.$emit('changePassword',this.adminEditData,()=>{
              this.isChange = false;
            });
          }
        });

      }
    }
  }
</script>

<style>
  .admin_edit .el-dialog__headerbtn {
    display: none;
  }
</style>
