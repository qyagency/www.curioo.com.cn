<template>
  <el-dialog class="admin_edit" :visible="adminAddVisible" title="账号新增" :before-close="handClose">
    <el-form :model="adminAddData" label-width="170px" ref="admin_edit" :rules="rules">
      <el-form-item :label="$t('page.AccountNumber')" prop="admin_name">
        <el-input size="mini" type="text" v-model="adminAddData.admin_name"></el-input>
      </el-form-item>
      <el-form-item :label="$t('page.Username')" prop="show_name">
        <el-input size="mini" type="text" v-model="adminAddData.show_name"></el-input>
      </el-form-item>
      <el-form-item :label="$t('page.RoleName')" prop="role_id">
        <el-select v-model="adminAddData.role_id" filterable :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in adminAddOption"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('page.Store')" prop="store_id">
        <el-select v-model="adminAddData.store_id" filterable :placeholder="$t('page.PleaseSelect')">
          <el-option
                  v-for="ie in adminAddStoreoption"
                  :key="ie.value"
                  :label="ie.label"
                  :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('page.DataAuth')" prop="can_see_data">
        <el-select v-model="adminAddData.can_see_data" :placeholder="$t('page.PleaseSelect')">
          <el-option
            v-for="ie in editDataField"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item :label="$t('page.CanDownload')">
        <el-switch
          v-model="adminAddData.can_download"
          active-value="1"
          inactive-value="0"
          :active-text="$t('page.yes')"
          :inactive-text="$t('page.no')">
        </el-switch>
      </el-form-item>
      <!--<el-form-item :label="$t('page.ViewAllInformation')">
        <el-switch
          v-model="adminAddData.can_read_all"
          active-value="1"
          inactive-value="0"
          :active-text="$t('page.yes')"
          :inactive-text="$t('page.no')">
        </el-switch>
      </el-form-item>-->
      <el-form-item :label="$t('page.Password')" prop="admin_password">
        <el-input size="mini" type="password" v-model="adminAddData.admin_password"></el-input>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
        <el-button size="mini" @click.native.prevent="handClose(true)">{{$t('page.Cancel')}}</el-button>
        <el-button size="mini" type="primary" @click.native.prevent="updateEdit()">{{$t('page.OK')}}</el-button>
      </span>
  </el-dialog>
</template>

<script>
  export default {
    name: "admin_edit",
    props: ['adminAddVisible', 'adminAddData','adminAddOption','adminAddStoreoption','editDataField'],
    data() {
      let pwdValid = (rule, value, callback) => {
        let regex = new RegExp('(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[^a-zA-Z0-9]).{6,32}');
        if (!regex.test(value)) {
          callback(new Error(rule.message));
        } else {
          callback();
        }
      };
      return {
        rules: {
          admin_name: {required: true, message: '请输入管理员账号', trigger: 'blur'},
          role_id: {required: true, message: '请选择角色', trigger: 'blur'},
          show_name: {required: true, message: '请输入用户名', trigger: 'blur'},
          store_id: {required: true, message: '请选择用户门店', trigger: 'blur'},
          can_see_data: {required: true, message: '请选择', trigger: 'blur'},
          admin_password: {validator: pwdValid, required: true, message: '密码格式错误，请根据要求设置（6-32位字符,包括数字、大小写字母、特殊字符）', trigger: 'change'},
        }
      }
    },
    methods: {
      handClose(flag) {
        if (flag == true) {
          this.$emit('update:adminAddVisible', false)
        }
      },
      updateEdit() {
        this.$refs['admin_edit'].validate((valid) => {
          if (valid) {
            this.$emit('createAdminAccount', this.adminAddData)
          }
        })
      }
    }
  }
</script>

<style>
  .admin_edit .el-dialog__headerbtn {
    display: none;
  }
</style>
