<template>
  <el-dialog class="role-box" title="角色权限" :before-close="handClose" :visible="rolesVisible">
    <el-form :model="field" :rules="rules">
      <el-form-item label="角色名称" label-width="80px" prop="role_name">
        <el-input size="mini" type="text" v-model="field.role_name"></el-input>
      </el-form-item>

      <el-form-item label="角色权限" label-width="80px" prop="default_role_id">
        <el-select v-model="field.default_role_id" size="mini">
          <el-option
            v-for="ie in defaultRoleList"
            :key="ie.value"
            :label="ie.label"
            :value="ie.value">
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>

    <el-timeline style="max-height: 550px;overflow-y: scroll">
      <el-timeline-item v-for="(value,index) in rolesData" :key="index" :timestamp="$t(value.name)" placement="top">
        <el-card>
          <el-checkbox-group v-model="value.check">
            <el-checkbox v-for="item in value.list" :label="item.value" :key="item.value">{{$t(item.name)}}</el-checkbox>
          </el-checkbox-group>
        </el-card>
      </el-timeline-item>
    </el-timeline>
    <span slot="footer" class="dialog-footer">
      <el-button size="mini" @click.native.prevent="handClose(true)">取 消</el-button>
      <el-button size="mini" type="primary" @click.native.prevent="updateEdit()">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script>
  import ElTimeline from "element-ui/packages/timeline/src/main";

  export default {
    components: {ElTimeline},
    name: "roles",
    props: ['rolesVisible', 'rolesData', 'field', 'defaultRoleList'],
    data(){
      return {
        rules: {
          default_role_id: {required: true, message: '请选择', trigger: 'blur'},
          role_name: {required: true, message: '', trigger: 'blur'},
        }
      }
    },
    methods: {
      handClose(flag) {
        if (flag == true) {
          this.$emit('update:rolesVisible', false)
        }
      },
      updateEdit() {
        // console.log(this.rolesData);return false;
        this.$emit('createUpdateRoles', this.rolesData,this.field)
      }
    }
  }
</script>

<style>
  .role-box .el-dialog__headerbtn {
    display: none;
  }
</style>
