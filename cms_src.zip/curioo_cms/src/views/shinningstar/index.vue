<template>
  <div class="app-container">
    <el-row>
      <el-col :span="6">
        <EditBtn :title="$t('page.Add')" :data.sync="add_data" :field="editField" :btn_name="$t('page.Add')"
                 v-on:update="updateData"></EditBtn>
      </el-col>
    </el-row>
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column :label="$t('page.Title')" prop="title"></el-table-column>
      <el-table-column :label="$t('page.Name')" prop="child_name"></el-table-column>
      <el-table-column label="排序" prop="sort">
        <template slot="header" slot-scope="scope">
          <Sort :input_data.sync="filter_data" field="sort" btn_text="sort"></Sort>
        </template>
      </el-table-column>
      <el-table-column :label="$t('page.Operate')">
        <template slot-scope="scope">
          <EditBtn :title="$t('page.Edit')" :data.sync="scope.row" :field="editField" :btn_name="$t('page.Edit')"
                   v-on:update="updateData"></EditBtn>
          <el-button type="text" size="mini" @click.native.prevent="deleteRow(scope.row)">{{$t('page.Delete')}}</el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="all_data" :output_data.sync="filter_data"></Pagination>
  </div>
</template>

<script>
  import {create,deleteRow,modify,query} from '@/api/shinningstar'
  import Pagination from '@/components/pagination'
  import Sort from '@/components/sort'
  import EditBtn from '@/components/EditBox/index'

  export default {
    name: "index",
    components: {Pagination, Sort, EditBtn},
    data() {
      return {
        all_data: [],
        filter_data: [],
        add_data: {
          cover: [],
          headimg: [],
          sort: 1
        },
        editField: [
          {
            field: 'cover',
            type: 'video',
            label: this.$t('page.VideoPictureGroup'),
            required: true,
            limit: 10,
            tip: this.$t('page.RecommendedSize')+ ':1500x860',
            toOss: false
          },{
            field:'title',
            type:'textarea',
            label: this.$t('page.Title'),
            required: true,
          }, {
            field:'child_name',
            type:'input',
            label: this.$t('page.Name'),
            required: true,
          }, {
            field:'headimg',
            type: 'image',
            label: this.$t('page.HeadPortrait'),
            required: true,
            limit: 1,
            tip:this.$t('page.RecommendedSize')+  ':200x200',
            toOss: false
          }, {
            field:'desc',
            type:'textarea',
            label:this.$t('page.Content'),
            required: true,
          },{
            field: 'sort',
            type: 'number',
            label: 'sort',
            required: true
          }
        ]
      }
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
    methods: {
      updateData(data, fn) {
        let updateData = {
          cover: data.cover.join(','),
          headimg: data.headimg.join(','),
          title: data.title,
          child_name: data.child_name,
          desc: data.desc,
          sort: data.sort
        };
        if (data.id) {
          updateData['id'] = data.id
          modify(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        } else {
          create(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        }
      },
      getList() {
        query().then(response => {
          // console.log(response)
          if (response.code === 200) {
            this.all_data = response.data;
            this.filter_data = response.data;
          }
        })
      },
      deleteRow(data) {
        this.$confirm(this.$t('page.ConfirmDeletion')).then(() => {
          let updateData = {
            id: data.id
          }

          deleteRow(updateData).then(response => {
            if (response.code === 200) {
              this.getList();
            }
          })
        }).catch(() => {
        })
      }
    },
    mounted() {
      // console.log(this.$router)
      this.getList();
    }
  }
</script>

<style scoped>

</style>
