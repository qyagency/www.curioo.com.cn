<template>
    <div class="app-container">

    </div>
</template>

<script>
    export default {
        name: "index"
    }
</script>

<style scoped>

</style>
