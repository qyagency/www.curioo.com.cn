<template>
  <div class="app-container">
    <el-form :model="filterData" label-width="120px">
      <el-row>
        <el-col :span="12">
          <el-form-item :label="$t('page.RegistrationDate')">
            <el-date-picker
              @change="filterFun('create_time')"
              size="mini"
              v-model="filterData.create_time"
              type="daterange"
              format="yyyy/MM/dd"
              value-format="yyyy/MM/dd"
              :range-separator="$t('page.to')"
              :start-placeholder="$t('page.StartDate')"
              :end-placeholder="$t('page.EndDate')">
            </el-date-picker>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="6">
          <el-form-item :label="$t('page.StudentName')">
            <el-input type="text" v-model="filterData.user_name" @input="filterFun('user_name')" size="mini"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item :label="$t('page.StudentCity')">
            <el-select v-model="filterData.user_city" @change="filterFun('user_city')" :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in filterDataOption.user_city_option"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item :label="$t('page.StudentAge')">
            <el-select v-model="filterData.user_age" @change="filterFun('user_age')" :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in filterDataOption.user_age_option"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>

      </el-row>
      <el-row>
        <el-col :span="6">
          <el-form-item :label="$t('page.ParentPhone')">
            <el-input type="text" v-model="filterData.user_mobile" @input="filterFun('user_mobile')"
                      size="mini"></el-input>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item :label="$t('page.Channel')">
            <el-select v-model="filterData.channel" filterable multiple @change="filterFun('channel')"
                       :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in filterDataOption.channel_1_option"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item :label="$t('page.City')">
            <el-select v-model="filterData.city" filterable multiple @change="filterFun('city')"
                       :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in filterDataOption.channel_2_option"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item :label="$t('page.Point/Media')">
            <el-select v-model="filterData.point_position" filterable multiple @change="filterFun('point_position')"
                       :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in filterDataOption.channel_3_option"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="6">
          <el-form-item :label="$t('page.AdvertisingSpace(online)')">
            <el-select v-model="filterData.ad" filterable multiple @change="filterFun('ad')"
                       :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in filterDataOption.channel_4_option"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item :label="$t('page.Activity')">
            <el-select v-model="filterData.activity" filterable multiple @change="filterFun('activity')"
                       :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in filterDataOption.channel_5_option"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item :label="$t('page.Offer')">
            <el-select v-model="filterData.offer" filterable multiple @change="filterFun('offer')"
                       :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in filterDataOption.channel_6_option"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <el-row>
      <el-col :span="3">
        <el-button type="default" @click="reset" size="mini">{{$t('page.ResetOption')}}</el-button>
      </el-col>
      <el-col :span="3">
        <el-button type="default" v-if="canDownload=='1'" @click="download" size="mini">{{$t('page.Download')}}</el-button>
      </el-col>
    </el-row>
    <el-table :data="page_data" :height="tableHeight" id="table">
      <el-table-column type="index"></el-table-column>
      <el-table-column :label="$t('page.StudentName')" prop="user_name"></el-table-column>
      <!--      <el-table-column label="学员性别" prop="user_gender"></el-table-column>-->
      <el-table-column :label="$t('page.ParentPhone')" prop="user_mobile" width="100px"></el-table-column>
      <!--      <el-table-column label="所属关系" prop="user_relation"></el-table-column>-->
      <!--      <el-table-column label="学员学校" prop="user_school"></el-table-column>-->
      <!--      <el-table-column label="学员年级" prop="user_grade"></el-table-column>-->
      <el-table-column :label="$t('page.RegistrationDate')" prop="create_time" width="100px"></el-table-column>
      <!--      <el-table-column label="预约日期" prop="order_date"></el-table-column>-->
      <!--      <el-table-column label="预约时间" prop="order_time"></el-table-column>-->
      <el-table-column :label="$t('page.StudentCity')" prop="user_city"></el-table-column>
      <el-table-column :label="$t('page.StudentAge')" prop="user_age"></el-table-column>
      <el-table-column :label="$t('page.Channel')" prop="channel"></el-table-column>
      <el-table-column :label="$t('page.City')" prop="city"></el-table-column>
      <el-table-column :label="$t('page.Point/Media')" prop="point_position"></el-table-column>
      <el-table-column :label="$t('page.AdvertisingSpace(online)')" prop="ad"></el-table-column>
      <el-table-column :label="$t('page.Activity')" prop="activity"></el-table-column>
      <el-table-column :label="$t('page.Offer')" prop="offer"></el-table-column>
      <el-table-column :label="$t('page.Rating')" prop="user_rate" width="110">
        <template slot-scope="scope">
          <el-select v-model="scope.row.user_rate" @change="rateChange(scope.row)" :placeholder="$t('page.PleaseSelect')" size="mini">
            <el-option
              v-for="item in userRateOption"
              :key="item.value"
              :label="$t(item.label)"
              :value="item.value">
            </el-option>
          </el-select>
        </template>
      </el-table-column>
      <el-table-column :label="$t('page.Remark')" prop="remark">
        <template slot-scope="scope">
          <el-button type="text" @click.native.prevent="changeRemark(scope.row)">{{$t('page.View')}}</el-button>
        </template>
      </el-table-column>
      <el-table-column :label="$t('page.EmployeeName')" prop="sales_name"></el-table-column>
      <el-table-column :label="$t('page.Location')" prop="area_name"></el-table-column>
      <el-table-column :label="$t('page.Store')" prop="store_name"></el-table-column>
      <el-table-column :label="$t('page.Order')">
        <template slot-scope="scope">
          <el-popover
            v-if="scope.row.appointment"
            placement="left"
            title="预约"
            width="200"
            trigger="click">
            <div>
              <div>城市：{{scope.row.appointment.city}}</div>
              <div>日期：{{scope.row.appointment.subscribe_date}}</div>
              <div>时间段：{{scope.row.appointment.subscribe_time}}</div>
            </div>
            <el-button slot="reference" size="mini">{{$t('page.View')}}</el-button>
          </el-popover>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="filter_data" :output_data.sync="page_data"></Pagination>

    <el-dialog
      :visible.sync="changeRemarkVisible"
      width="30%"
      :before-close="handleClose">
      <el-form :model="remarkData">
        <el-form-item :label="$t('page.Remark')">
          <el-input type="textarea" v-model="remarkData.remark"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleClose('true')">{{$t('page.Cancel')}}</el-button>
        <el-button type="primary" @click="makeSureChangeRemark">{{$t('page.OK')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  import {query, changeRemark, changeRate} from '@/api/customer'
  import Sort from '@/components/sort'
  import Pagination from '@/components/pagination'

  import FileSaver from 'file-saver/dist/FileSaver.min'
  import XLSX from 'xlsx'

  export default {
    name: "index",
    data() {
      return {
        filterData: {
          create_time: [],
          order_time: [],
          city: [],
          channel: [],
          ad: [],
          point_position: [],
          activity: [],
          offer: [],
          activity_id: '',
          // form_id: '',
          user_name: '',
          user_gender: '',
          user_age: '',
          user_city: '',
          user_grade: '',
          user_school: '',
          user_relation: '',
        },
        filterDataOption: {
          activity_option: [],
          // form_id_option: [],
          user_gender_option: [],
          user_city_option:[],
          user_grade_option: [],
          user_age_option: [],
          user_school_option: [],
          user_relation_option: [],
          channel_1_option: [],
          channel_2_option: [],
          channel_3_option: [],
          channel_4_option: [],
          channel_5_option: [],
          channel_6_option: [],
        },
        userRateOption: [
          {
            label: 'page.low',
            value: '低'
          }, {
            label: 'page.middle',
            value: '中'
          }, {
            label: 'page.high',
            value: '高'
          }
        ],
        all_data: [],
        filter_data: [],
        page_data: [],
        // 已经使用的规则
        used_rules: {},
        canDownload: 0,
        changeRemarkVisible: false,
        remarkData: {
          remark: '',
          id: ''
        }
      }
    },
    components: {Sort,Pagination},
    computed: {
      tableHeight() {
        return window.innerHeight * 0.6
      }
    },
    methods: {
      handleClose(flg) {
        if (flg) {
          this.changeRemarkVisible = false;
        }
      },
      changeRemark(data) {
        this.remarkData.remark = data.remark;
        this.remarkData.id = data.id;
        this.changeRemarkVisible = true;
      },
      makeSureChangeRemark() {
        let updateData = {
          id: this.remarkData.id,
          remark: this.remarkData.remark
        }
        changeRemark(updateData).then(response => {
          if (response.code === 200) {
            this.$message.success(this.$t('page.ModificationSucceeded'))
            this.changeRemarkVisible = false;
            this.getCustomerList();
          }
        }).catch(err => {
          this.$message.error(this.$t('page.ModificationFailed'))
        })

      },
      rateChange(data) {
        let updateData = {
          id: data.id,
          user_rate: data.user_rate
        }
        changeRate(updateData).then(response => {
          if (response.code === 200) {
            this.$message.success(this.$t('page.ModificationSucceeded'));
            this.getCustomerList();
          }
        }).catch(err => {
          this.$message.error(this.$t('page.ModificationFailed'))
        })
      },
      // 下载
      download() {
        let mapping = {
          user_name:this.$t('page.StudentName'),
          user_age:this.$t('page.StudentAge'),
          user_mobile:this.$t('page.ParentPhone'),
          user_city:this.$t('page.StudentCity'),
          create_time:this.$t('page.CreateTime'),
          user_rate:this.$t('page.Rating'),
          remark:this.$t('page.Remark'),
          channel:this.$t('page.Channel'),
          city:this.$t('page.City'),
          point_position:this.$t('page.Point/Media'),
          ad:this.$t('page.AdvertisingSpace(online)'),
          activity:this.$t('page.Activity'),
          offer:this.$t('page.Offer'),
          store_name:this.$t('page.Store'),
          area_name:this.$t('page.Location'),
          sales_name:this.$t('page.EmployeeName'),
          appointment_city:this.$t('page.AppointmentCity'),
          appointment_subscribe_date:this.$t('page.AppointmentSubscribeDate'),
          appointment_subscribe_time:this.$t('page.AppointmentSubscribeTime'),

        }
        let data = JSON.parse(JSON.stringify(this.filter_data));
        let out = [];
        for(let i =0;i<data.length;i++){
          let dd = data[i];
          let pp = {};
          for(let j in mapping){
            pp[mapping[j]] = dd[j]
          }
          out.push(pp)
        }
        var workBook = {
          SheetNames: ['Sheet1'],
          Sheets: {},
          Props: {}
        };
        workBook.Sheets['Sheet1'] = XLSX.utils.json_to_sheet(out)

        // var wb = XLSX.utils.json_to_sheet(this.filter_data);
        var wbout = XLSX.write(workBook, {bookType: 'xlsx', bookSST: true, type: 'array'})
        try {
          FileSaver.saveAs(new Blob([wbout], {type: 'application/octet-stream'}), '客户名单.xlsx')
        } catch (e) {
          if (typeof console !== 'undefined') console.log(e, wbout)
        }
        return wbout
      },
      // 重置选项
      reset() {
        let data = {};
        for (let obj in this.filterData) {
          if (typeof this.filterData[obj] == 'object') {
            data[obj] = [];
          } else {
            data[obj] = '';
          }
        }
        this.filterData = data;
        this.used_rules = {};
        this.formatData();
      },
      getCustomerList() {
        query().then(response => {
          if (response.code === 200) {
            this.filter_data = response.data;
            this.all_data = response.data;
            this.canDownload = response.can_download;

            this.filterDataOption.activity_option = response.activityOption;
            this.filterDataOption.user_age_option = response.ageOption;
            this.filterDataOption.user_city_option = response.cityOption;
            this.filterDataOption.user_grade_option = response.gradeOption;
            this.filterDataOption.user_school_option = response.schoolOption;
            this.filterDataOption.user_relation_option = response.relationOption;


            this.filterDataOption.channel_1_option = response.allChannel.channel_1;
            this.filterDataOption.channel_2_option = response.allChannel.channel_2;
            this.filterDataOption.channel_3_option = response.allChannel.channel_3;
            this.filterDataOption.channel_4_option = response.allChannel.channel_4;
            this.filterDataOption.channel_5_option = response.allChannel.channel_5;
            this.filterDataOption.channel_6_option = response.allChannel.channel_6;

            this.formatData()
          }
        })
      },
      filterFun(flg) {
        // console.log(flg, this.filterData.user_name);
        let filterInfo = null;
        switch (flg) {
          case 'create_time':
          case 'order_time':
            let startDate = this.dateToTimestamp(this.filterData[flg][0]);
            let endDate = this.dateToTimestampEnd(this.filterData[flg][1]);
            filterInfo = [startDate, endDate];
            console.log(filterInfo)
            break;
          // case 'activity':
          case 'user_name':
          case 'user_age':
          case 'user_mobile':
          case 'user_gender':
          case 'user_city':
          case 'user_grade':
          case 'user_school':
          case 'user_relation':
          case 'channel':
          case 'city':
          case 'ad':
          case 'point_position':
          case 'activity':
          case 'offer':
            filterInfo = this.filterData[flg];
            break;
        }
        this.used_rules[flg] = filterInfo;
        this.formatData()
      },
      formatData() {
        let data = [];
        for (let i = 0; i < this.all_data.length; i++) {
          let single = this.all_data[i];
          let canJoin = true;
          for (let flg in this.used_rules) {
            let filterInfo = this.used_rules[flg];
            switch (flg) {
              case 'create_time':
                let cT = this.dateToTimestamp(single['create_time']);
                if (cT < filterInfo[0] || cT > filterInfo[1]) {
                  canJoin = false;
                }
                break;
              case 'order_time':
                if (single['order_date']) {
                  let oT = this.dateToTimestamp(single['order_date']);
                  if (oT < filterInfo[0] || oT > filterInfo[1]) {
                    canJoin = false;
                  }
                } else {
                  canJoin = false;
                }
                break;
              // case 'activity':
              case 'user_gender':
              case 'user_age':
              case 'user_city':
              case 'user_grade':
              case 'user_school':
              case 'user_relation':
                if (filterInfo != '') {
                  if (!single[flg] || single[flg] != filterInfo) {
                    canJoin = false;
                  }
                }
                break;
              case 'user_name':
              case 'user_mobile':
                if (filterInfo != '') {
                  if (single[flg].indexOf(filterInfo) == -1) {
                    canJoin = false;
                  }
                }
                break;
              case 'channel':
              case 'city':
              case 'ad':
              case 'point_position':
              case 'activity':
              case 'offer':
                if (filterInfo != '') {
                  if (filterInfo.indexOf(single[flg]) == -1) {
                    canJoin = false;
                  }
                }
                break;
            }
          }
          if (canJoin) {
            data.push(single);
          }

        }


        this.filter_data = data;
      },
      // 日期转变为时间戳
      dateToTimestamp(date) {
        let a = new Date(date);
        return a.valueOf(a);
      },
      dateToTimestampEnd(date) {
        let a = new Date(date+' '+'23:59:59');
        return a.valueOf(a);
      },
    }
    ,
    mounted() {
      this.getCustomerList();
    }
  }
</script>

<style scoped>

</style>
