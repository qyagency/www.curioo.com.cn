<template>
  <div class="app-container">
    <el-form :model="filterData" label-width="120px">
      <el-row>
        <el-col :span="6">
          <el-form-item :label="$t('page.ParentName')">
            <el-input type="text" v-model="filterData.parent_name" @input="filterFun('parent_name')" size="mini"></el-input>
          </el-form-item>
        </el-col>

        <el-col :span="6">
          <el-form-item :label="$t('page.Country')">
            <el-select v-model="filterData.user_country" filterable @change="filterFun('user_country')"
                       :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in countryList"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="6">
          <el-form-item :label="$t('page.City')">
            <el-select v-model="filterData.user_city" filterable @change="filterFun('user_city')"
                       :placeholder="$t('page.PleaseSelect')" size="mini">
              <el-option
                v-for="item in cityList"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="6">
          <el-form-item :label="$t('page.Mobile')">
            <el-input type="text" v-model="filterData.user_mobile" @input="filterFun('user_mobile')"
                      size="mini"></el-input>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <el-row>
      <el-col :span="3">
        <el-button type="default" @click="reset" size="mini">{{$t('page.ResetOption')}}</el-button>
      </el-col>
      <el-col :span="3">
        <el-button type="default" v-if="canDownload=='1'" @click="download" size="mini">{{$t('page.Download')}}</el-button>
      </el-col>
    </el-row>

    <el-table :data="page_data" :height="tableHeight" id="table">
      <el-table-column type="index"></el-table-column>
      <el-table-column :label="$t('page.ParentName')" prop="parent_name"></el-table-column>
      <el-table-column :label="$t('page.ChildBirth')" prop="child_birth" width="100px"></el-table-column>
      <el-table-column :label="$t('page.Country')" prop="user_country" width="100px"></el-table-column>
      <el-table-column :label="$t('page.City')" prop="user_city"></el-table-column>
      <el-table-column :label="$t('page.Mobile')" prop="user_mobile"></el-table-column>
      <el-table-column :label="$t('page.Email')" prop="user_email"></el-table-column>
      <el-table-column :label="$t('page.SubmitTime')" prop="submit_time"></el-table-column>

      <el-table-column :label="$t('page.Order')">
        <template slot-scope="scope">
          <el-popover
            v-if="scope.row.subscribe_date"
            placement="left"
            title="预约"
            width="200"
            trigger="click">
            <div>
              <div>日期：{{scope.row.subscribe_date}}</div>
              <div>时间段：{{scope.row.subscribe_time}}</div>
            </div>
            <el-button slot="reference" size="mini">{{$t('page.View')}}</el-button>
          </el-popover>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="filter_data" :output_data.sync="page_data"></Pagination>
  </div>
</template>

<script>
  import {query, changeRemark} from '@/api/overseas_customer'
  import Sort from '@/components/sort'
  import Pagination from '@/components/pagination'

  import FileSaver from 'file-saver/dist/FileSaver.min'
  import XLSX from 'xlsx'

  export default {
    name: "index",
    data() {
      return {
        filterData: {
          create_time: [],
          order_time: [],
          user_country:'',
          user_city:'',
          user_mobile:'',
          user_email:'',
        },
        all_data: [],
        filter_data: [],
        page_data: [],
        // 已经使用的规则
        used_rules: {},
        canDownload: 0,
        remarkData: {
          remark: '',
          id: ''
        },
        cityList:[], //城市筛选
        countryList:[], //国家筛选
      }
    },
    components: {Sort,Pagination},
    computed: {
      tableHeight() {
        return window.innerHeight * 0.6
      }
    },
    methods: {
      // 下载
      download() {
        let mapping = {
          parent_name:this.$t('page.ParentName'),
          child_birth:this.$t('page.ChildBirth'),
          user_country:this.$t('page.Country'),
          user_city:this.$t('page.City'),
          user_mobile:this.$t('page.Mobile'),
          user_email:this.$t('page.Email'),
          submit_time:this.$t('page.SubmitTime'),
          subscribe_date:this.$t('page.SubscribeDate'),
          subscribe_time:this.$t('page.SubscribeTime'),

        }
        let data = JSON.parse(JSON.stringify(this.filter_data));
        let out = [];
        for(let i =0;i<data.length;i++){
          let dd = data[i];
          let pp = {};
          for(let j in mapping){
            pp[mapping[j]] = dd[j]
          }
          out.push(pp)
        }
        var workBook = {
          SheetNames: ['Sheet1'],
          Sheets: {},
          Props: {}
        };
        workBook.Sheets['Sheet1'] = XLSX.utils.json_to_sheet(out)

        // var wb = XLSX.utils.json_to_sheet(this.filter_data);
        var wbout = XLSX.write(workBook, {bookType: 'xlsx', bookSST: true, type: 'array'})
        try {
          FileSaver.saveAs(new Blob([wbout], {type: 'application/octet-stream'}), '客户名单.xlsx')
        } catch (e) {
          if (typeof console !== 'undefined') console.log(e, wbout)
        }
        return wbout
      },
      // 重置选项
      reset() {
        let data = {};
        for (let obj in this.filterData) {
          if (typeof this.filterData[obj] == 'object') {
            data[obj] = [];
          } else {
            data[obj] = '';
          }
        }
        this.filterData = data;
        this.used_rules = {};
        this.formatData();
      },
      getCustomerList() {
        query().then(response => {
          if (response.code === 200) {
            this.filter_data = response.data;
            this.all_data = response.data;
            this.canDownload = response.can_download;
            this.cityList = response.city;
            this.countryList = response.country;

            this.formatData()
          }
        })
      },
      filterFun(flg) {
        console.log(flg, this.filterData.parent_name);
        let filterInfo = null;
        switch (flg) {
          case 'create_time':
          case 'order_time':
            let startDate = this.dateToTimestamp(this.filterData[flg][0]);
            let endDate = this.dateToTimestampEnd(this.filterData[flg][1]);
            filterInfo = [startDate, endDate];
            console.log(filterInfo)
            break;
          case 'parent_name':
            filterInfo = this.filterData.parent_name;
            break;
          case 'user_country':
            filterInfo = this.filterData.user_country;
            break;
          case 'user_city':
            filterInfo = this.filterData.user_city;
            break;
          case 'user_mobile':
            filterInfo = this.filterData.user_mobile;
            break;
          case 'user_email':
            filterInfo = this.filterData.user_email;
            break;

        }
        console.log(flg);
        this.used_rules[flg] = filterInfo;
        this.formatData()
      },
      formatData() {
        let data = [];
        for (let i = 0; i < this.all_data.length; i++) {
          let single = this.all_data[i];
          let canJoin = true;
          for (let flg in this.used_rules) {
            let filterInfo = this.used_rules[flg];
            switch (flg) {
              case 'create_time':
                let cT = this.dateToTimestamp(single['create_time']);
                if (cT < filterInfo[0] || cT > filterInfo[1]) {
                  canJoin = false;
                }
                break;
              case 'order_time':
                if (single['order_date']) {
                  let oT = this.dateToTimestamp(single['order_date']);
                  if (oT < filterInfo[0] || oT > filterInfo[1]) {
                    canJoin = false;
                  }
                } else {
                  canJoin = false;
                }
                break;

              case 'user_country':
              case 'user_city':
              case 'parent_name':
              case 'user_mobile':
                if (filterInfo != '') {
                  if (single[flg].indexOf(filterInfo) == -1) {
                    canJoin = false;
                  }
                }
                break;
            }
          }
          if (canJoin) {
            data.push(single);
          }

        }
console.log(data)
        this.filter_data = data;
      },
      // 日期转变为时间戳
      dateToTimestamp(date) {
        let a = new Date(date);
        return a.valueOf(a);
      },
      dateToTimestampEnd(date) {
        let a = new Date(date+' '+'23:59:59');
        return a.valueOf(a);
      },
    }
    ,
    mounted() {
      this.getCustomerList();
    }
  }
</script>

<style scoped>

</style>
