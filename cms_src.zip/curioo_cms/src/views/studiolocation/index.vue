<template>
  <div class="app-container">
    <el-row>
      <el-col :span="6">
        <EditBtn :title="$t('page.Add')" :data.sync="add_data" :field="editField" :btn_name="$t('page.Add')"
                 v-on:update="updateData"></EditBtn>
      </el-col>
    </el-row>
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column :label="$t('page.filterCountry')" prop="filter_country"></el-table-column>
      <el-table-column :label="$t('page.filterCity')" prop="filter_city"></el-table-column>
      <el-table-column :label="$t('page.StudioLocation')" prop="city"></el-table-column>
      <el-table-column :label="$t('page.Address')" prop="address"></el-table-column>
      <!--
      <el-table-column :label="$t('page.Longitude')" prop="lng"></el-table-column>
       <el-table-column :label="$t('page.Latitude')" prop="lat"></el-table-column>
      -->
      <el-table-column :label="$t('page.Line')" prop="line">
        <template slot-scope="scope">
          <a :href="scope.row.line" target="_blank" class="buttonText" style="white-space: nowrap;">{{scope.row.line}}</a>
        </template>
      </el-table-column>

      <el-table-column :label="$t('page.Phone')" prop="phone"></el-table-column>
      <el-table-column label="排序" prop="sort">
        <template slot="header" slot-scope="scope">
          <Sort :input_data.sync="filter_data" field="sort" btn_text="sort"></Sort>
        </template>
      </el-table-column>
      <el-table-column :label="$t('page.Operate')">
        <template slot-scope="scope">
          <EditBtn :title="$t('page.Edit')" :data.sync="scope.row" :field="editField" :btn_name="$t('page.Edit')"
                   v-on:update="updateData"></EditBtn>
          <el-button type="text" size="mini" @click.native.prevent="deleteRow(scope.row)">{{$t('page.Delete')}}</el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="all_data" :output_data.sync="filter_data"></Pagination>
  </div>
</template>

<script>
  import {create, deleteRow, modify, query} from '@/api/studio_location'
  import Pagination from '@/components/pagination'
  import Sort from '@/components/sort'
  import EditBtn from '@/components/EditBox/index'
  import {getCookie} from "../../utils/auth";

  export default {
    name: "index",
    components: {Pagination, Sort, EditBtn},
    data() {
      return {
        all_data: [],
        filter_data: [],
        add_data: {
          city: '',
          address: '',
          cover:[],
          sort: 1
        },
        lang:getCookie('getLang') ? getCookie('getLang') : 'cn',
        editField: [
          {
            field: 'filter_country',
            type: 'input',
            label: this.$t('page.filterCountry'),
          },
          {
            field: 'filter_city',
            type: 'input',
            label: this.$t('page.filterCity'),
          },
          {
            field: 'city',
            type: 'input',
            label: this.$t('page.StudioLocation'),
          },
          {
            field: 'abroad',
            type: 'select_one',
            label: this.$t('page.Abroad'),
            option:[
              {label:this.$t('page.yes'),value:'1'},
              {label:this.$t('page.no'),value:'0'},
            ]
          },
          {
            field: 'address',
            type: 'input',
            label: this.$t('page.Address'),
          },
          // {
          //   field: 'lng',
          //   type: 'input',
          //   label: this.$t('page.Longitude'),
          // },
          // {
          //   field: 'lat',
          //   type: 'input',
          //   label: this.$t('page.Latitude'),
          // },
          {
            field: 'line',
            type: 'input',
            label: this.$t('page.Line'),
          },
          {
            field: 'phone',
            type: 'input',
            label: this.$t('page.Phone'),
          },
          // {
          //   field: 'cover',
          //   type: 'image',
          //   label: this.$t('page.Pictures'),
          //   required: true,
          //   limit: 1,
          //   tip: this.$t('page.RecommendedSize')+ ':408x250',
          //   toOss: false
          // },
          {
            field: 'sort',
            type: 'number',
            label: 'sort',
            required: true
          }
        ]
      }
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
    methods: {
      updateData(data, fn) {

        let updateData = {
          filter_country:data.filter_country,
          filter_city:data.filter_city,
          city: data.city,
          address: data.address,
          phone: data.phone,
          sort: data.sort,
          abroad: data.abroad,
          // cover:data.cover.join(','),
          // lng: data.lng,
          // lat: data.lat,
          line:data.line,
        };
        if(this.lang==='en'){
          updateData['link'] = data.link;
        }
        if (data.id) {
          updateData['id'] = data.id
          modify(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        } else {
          create(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        }
      },
      getList() {
        query().then(response => {
          // console.log(response)
          if (response.code === 200) {
            this.all_data = response.data;
            this.filter_data = response.data;
            this.resetEditField(response.option);
          }
        })
      },
      deleteRow(data) {
        this.$confirm(this.$t('page.ConfirmDeletion')).then(() => {
          let updateData = {
            id: data.id
          }

          deleteRow(updateData).then(response => {
            if (response.code === 200) {
              this.getList();
            }
          })
        }).catch(() => {
        })
      },
      resetEditField(option){
        // console.log(option)

        if (this.lang === 'en') {
          this.editField = [
            {
              field: 'filter_country',
              type: 'input',
              label: this.$t('page.filterCountry'),
            },
            {
              field: 'filter_city',
              type: 'input',
              label: this.$t('page.filterCity'),
            },
            {
              field: 'city',
              type: 'input',
              label: this.$t('page.City'),
            },
            {
              field: 'abroad',
              type: 'select_one',
              label: this.$t('page.Abroad'),
              option:[
                {label:this.$t('page.yes'),value:'1'},
                {label:this.$t('page.no'),value:'0'},
              ]
            },{
              field: 'address',
              type: 'input',
              label: this.$t('page.Address'),
            },
            // {
            //   field: 'link',
            //   type: 'select_one',
            //   label: this.$t('page.Relation'),
            //   option:option
            // },
            // {
            //   field: 'lng',
            //   type: 'input',
            //   label: this.$t('page.Longitude'),
            // },
            // {
            //   field: 'lat',
            //   type: 'input',
            //   label: this.$t('page.Latitude'),
            // },
            {
              field: 'line',
              type: 'input',
              label: this.$t('page.Line'),
            },
            {
              field: 'phone',
              type: 'input',
              label: this.$t('page.Phone'),
            },
            // {
            //   field: 'cover',
            //   type: 'image',
            //   label: this.$t('page.Pictures'),
            //   required: true,
            //   limit: 1,
            //   tip: this.$t('page.RecommendedSize')+ ':408x250',
            //   toOss: false
            // },
            {
              field: 'sort',
              type: 'number',
              label: 'sort',
              required: true
            }
          ]
        }
      }
    },
    mounted() {
      this.getList();
    }
  }
</script>

<style scoped>

</style>
