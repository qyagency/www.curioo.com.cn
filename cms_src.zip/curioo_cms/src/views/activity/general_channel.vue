<template>
  <div class="app-container">
    <el-row>
      <el-col :span="6">
        <EditBtn title="渠道汇总新增" :data.sync="add_data" :field.sync="editField" btn_name="渠道汇总新增"
                 v-on:update="updateData"></EditBtn>
      </el-col>
    </el-row>
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column label="名称" prop="general_name"></el-table-column>
      <el-table-column label="渠道">
        <template slot-scope="scope">
          {{scope.row.channel_mapping[1]}}
        </template>
      </el-table-column>
      <el-table-column label="推广城市">
        <template slot-scope="scope">
          {{scope.row.channel_mapping[2]}}
        </template>
      </el-table-column>
      <el-table-column label="点位/媒体">
        <template slot-scope="scope">
          {{scope.row.channel_mapping[3]}}
        </template>
      </el-table-column>
      <el-table-column label="广告位">
        <template slot-scope="scope">
          {{scope.row.channel_mapping[4]}}
        </template>
      </el-table-column>
      <el-table-column label="活动">
        <template slot-scope="scope">
          {{scope.row.channel_mapping[5]}}
        </template>
      </el-table-column>
      <el-table-column label="offer">
        <template slot-scope="scope">
          {{scope.row.channel_mapping[6]}}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <!--          <EditBtn title="URL编辑" :data.sync="scope.row" :field="editField" btn_name="编辑"-->
          <!--                   v-on:update="updateData"></EditBtn>-->
          <el-button type="text" size="mini" @click.native.prevent="deleteRow(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="all_data" :output_data.sync="filter_data"></Pagination>
  </div>
</template>

<script>
  import {create, deleteRow, modify, query, channel_option} from '@/api/channel_general'
  import Pagination from '@/components/pagination'
  import Sort from '@/components/sort'
  import EditBtn from '@/components/EditBox/index'

  export default {
    name: "index",
    components: {Pagination, Sort, EditBtn},
    data() {
      return {
        all_data: [],
        filter_data: [],
        add_data: {
          general_name: '',
          channel: '',
          city: '',
          pointPosition: '',
          ad: '',
          activity: '',
          offer: '',
        },
        editField: [
          {
            field: 'general_name',
            type: 'input',
            label: '渠道名称',
            required: true,
          }, {
            field: 'channel',
            type: 'select_one_search',
            label: '渠道',
            option: []
          }, {
            field: 'city',
            type: 'select_one_search',
            label: '推广城市',
            option: []
          }, {
            field: 'pointPosition',
            type: 'select_one_search',
            label: '点位/媒体',
            option: []
          }, {
            field: 'ad',
            type: 'select_one_search',
            label: '广告位',
            option: []
          }, {
            field: 'activity',
            type: 'select_one_search',
            label: '活动',
            option: []
          }, {
            field: 'offer',
            type: 'select_one_search',
            label: 'offer',
            option: []
          }
        ]
      }
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
    methods: {
      updateData(data, fn) {
        let updateData = {
          general_name: data.general_name,
          channel: data.channel,
          city: data.city,
          pointPosition: data.pointPosition,
          ad: data.ad,
          activity: data.activity,
          offer: data.offer,
        };
        if (data.id) {
          updateData['id'] = data.id
          modify(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        } else {
          create(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        }
      },
      getList() {
        query().then(response => {
          if (response.code === 200) {
            this.all_data = response.data;
            this.filter_data = response.data;
          }
        })
      },
      deleteRow(data) {
        this.$confirm('确认删除？').then(() => {
          let updateData = {
            id: data.id
          }

          deleteRow(updateData).then(response => {
            if (response.code === 200) {
              this.getList();
            }
          })
        }).catch(() => {
        })
      },
      getChannelOption() {
        let mapping = {
          'channel': '1',
          'city': '2',
          'pointPosition': '3',
          'ad': '4',
          'activity': '5',
          'offer': '6'
        };
        channel_option().then(response => {
          if (response.code === 200) {
            let channel_option_data = response.data;
            for(let i=0;i<this.editField.length;i++){
              if(mapping[this.editField[i]['field']]){
                this.editField[i]['option'] = channel_option_data[mapping[this.editField[i]['field']]];
              }
            }
            this.getList();
          }
        })
      }
    },
    mounted() {
      console.log(this.$router)
      this.getChannelOption();
    }
  }
</script>

<style scoped>

</style>
