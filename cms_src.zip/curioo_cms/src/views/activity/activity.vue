<template>
  <div class="app-container">
    <el-row>
      <el-col :span="6">
        <EditBtn :title="$t('page.Add')" :data.sync="add_data" :field="editField" :btn_name="$t('page.Add')"
                 v-on:update="updateData"></EditBtn>
      </el-col>
      <el-col :span="6">
        <el-button type="text" size="mini" @click.native.prevent="downloadQrCodeZip()" >{{$t('page.DownloadQRCodesInBatches')}}</el-button>
      </el-col>
    </el-row>
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column :label="$t('page.EventName')" prop="activity_name"></el-table-column>
      <el-table-column :label="$t('page.Channel')" prop="channel"></el-table-column>
      <el-table-column :label="$t('page.City')" prop="city"></el-table-column>
      <el-table-column :label="$t('page.Point/Media')" prop="point_position"></el-table-column>
      <el-table-column :label="$t('page.AdvertisingSpace(online)')" prop="ad"></el-table-column>
      <el-table-column :label="$t('page.Activity')" prop="activity"></el-table-column>
      <el-table-column :label="$t('page.Offer')" prop="offer"></el-table-column>
      <el-table-column :label="$t('page.Link')" prop="baseurl"></el-table-column>
      <el-table-column :label="$t('page.Operate')" width="200px">
        <template slot-scope="scope">
          <!--          <EditBtn title="URL编辑" :data.sync="scope.row" :field="editField" btn_name="编辑"-->
          <!--                   v-on:update="updateData"></EditBtn>-->
          <el-button type="text" size="mini" :class="copyDom+scope.row.id" @click.native.prevent="copyUrl(copyDom+scope.row.id)" data-clipboard-action="copy" :data-clipboard-text="scope.row.general_url">{{$t('page.CopyLink')}}</el-button>
          <el-button type="text" size="mini" @click.native.prevent="downloadQrCode(scope.row.activity_name,scope.row.general_url)">{{$t('page.DownloadQRCodes')}}</el-button>
          <el-button type="text" size="mini" @click.native.prevent="deleteRow(scope.row)">{{$t('page.Delete')}}</el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="all_data" :output_data.sync="filter_data"></Pagination>
  </div>
</template>

<script>
  import {create, deleteRow, modify, query, channel_option} from '@/api/activity'
  import Pagination from '@/components/pagination'
  import Sort from '@/components/sort'
  import EditBtn from '@/components/EditBox/index'
  import Clipboard from 'clipboard'
  import QRCode from 'qrcodejs2'
  import FileSaver from 'file-saver'
  import JSZip from 'jszip'
  export default {
    name: "index",
    components: {Pagination, Sort, EditBtn},
    data() {
      return {
        all_data: [],
        filter_data: [],
        copyDom:'link_',
        add_data: {
          activity_name: '',
          baseurl: '',
          channel_mgt_id: '',
        },
        editField: [
          {
            field: 'activity_name',
            type: 'input',
            label: this.$t('page.EventName'),
            required: true,
          }, {
            field: 'baseurl',
            type: 'select_one_search',
            label: this.$t('page.LinkName'),
            required: true,
            option: []
          }, {
            type: 'showMsg',
            labelGroups: [
              {
                label:this.$t('page.Link')+ '：',
                field: 'baseurl',
                col: 24
              }
            ],
          },  {
            field: 'channel',
            type: 'select_one_search',
            label: this.$t('page.Channel'),
            option: []
          }, {
            field: 'city',
            type: 'select_one_search',
            label: this.$t('page.City'),
            option: []
          }, {
            field: 'point_position',
            type: 'select_one_search',
            label: this.$t('page.Point/Media'),
            option: []
          }, {
            field: 'ad',
            type: 'select_one_search',
            label: this.$t('page.AdvertisingSpace(online)'),
            option: []
          }, {
            field: 'activity',
            type: 'select_one_search',
            label: this.$t('page.Activity'),
            option: []
          }, {
            field: 'offer',
            type: 'select_one_search',
            label: this.$t('page.Offer'),
            option: []
          }
        ]
      }
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
    methods: {
      copyUrl(copyDom){
        let clipboard = new Clipboard('.'+copyDom)
        clipboard.on('success', e => {
          console.log('success',e)
          clipboard.destroy() // 使用destroy可以清楚缓存
        })
        clipboard.on('error', e => {
          console.log('error',e)
          clipboard.destroy()
        })
      },
      downloadQrCode(qrcode_name,url){
        // 单张下载
        let size = 200;
        var canvas = this.createQrcode(size,url);
        // 构建画布
        // 构造url
        let canvasUrl = canvas.toDataURL('image/png');
        // 构造a标签并模拟点击
        var downloadLink = document.createElement('a');
        downloadLink.setAttribute('href', canvasUrl);
        downloadLink.setAttribute('download', qrcode_name+'.png');

        downloadLink.click();

      },
      createQrcode(size,url){
        let div = document.createElement('div');
        new QRCode(div, {
          width: size,
          height: size,
          text: url,
          colorDark: "#000000",
          colorLight: "#ffffff",
          render: 'canvas',
        });
        return div.getElementsByTagName('canvas')[0];
      },
      downloadQrCodeZip(){
        const zip = new JSZip();
        const cache = {}
        const size = 200;
        for(let i=0;i<this.all_data.length;i++){
            let activityName = this.all_data[i]['activity_name'];
            let url = this.all_data[i]['general_url'];

          let data = this.createQrcode(size,url).toDataURL("image/png");

          zip.file(activityName+'.png',data.substring(22),{base64:true})
          cache[activityName] = data
        }

        // let myCanvas = document.getElementById('picture').getElementsByTagName('canvas');
        // for (let index = 0; index < myCanvas.length; index++) {
        //   let data = myCanvas[index].toDataURL("image/png");
        //
        //   let fileName = this.tableData[index].linkUrl;
        //   zip.file(fileName+'.png',data.substring(22),{base64:true})
        //   cache[fileName] = data
        // }
        // 生成二进制流
        zip.generateAsync({type:"blob"}).then(content => {
          // file-saver保存文件
          FileSaver.saveAs(content, "QrCode.zip")
        })
      },
      updateData(data, fn) {
        let updateData = {
          activity_name: data.activity_name,
          baseurl: data.baseurl,
          channel: data.channel,
          city: data.city,
          point_position: data.point_position,
          ad: data.ad,
          activity: data.activity,
          offer: data.offer,
        };
        if (data.id) {
          updateData['id'] = data.id
          modify(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        } else {
          create(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        }
      },
      getList() {
        query().then(response => {
          if (response.code === 200) {
            this.all_data = response.data;
            this.filter_data = response.data;
          }
        })
      },
      deleteRow(data) {
        this.$confirm(this.$t('page.ConfirmDeletion')).then(() => {
          let updateData = {
            id: data.id
          }

          deleteRow(updateData).then(response => {
            if (response.code === 200) {
              this.getList();
            }
          })
        }).catch(() => {
        })
      },
      channel_option() {
        channel_option().then(response => {
          if (response.code === 200) {
            let data = response.data;
            for (let i = 0; i < this.editField.length; i++) {
              if (data[this.editField[i]['field']]) {
                this.editField[i]['option'] = data[this.editField[i]['field']];
              }
            }

            this.getList();
          }
        })
      }
    },
    mounted() {
      // console.log(this.$router)
      this.channel_option();
    }
  }
</script>

<style scoped>
.hidden{
  /*width:0;*/
  /*height:0;*/
  /*opacity: 0;*/
}
</style>
