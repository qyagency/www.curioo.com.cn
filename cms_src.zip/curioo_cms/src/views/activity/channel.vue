<template>
  <div class="app-container">
    <el-row>
      <el-col :span="6">
        <EditBtn :title="$t('page.Add')" :data.sync="add_data" :field="editField" btn_name="新增"
                 v-on:update="updateData"></EditBtn>
      </el-col>
    </el-row>
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column :label="$t('page.Option')" prop="channel_type">
        <template slot-scope="scope">
          {{channel_mapping[scope.row.channel_type]}}
        </template>
      </el-table-column>
      <el-table-column :label="$t('page.Name')" prop="channel_name"></el-table-column>
      <el-table-column :label="$t('page.Operate')">
        <template slot-scope="scope">
          <!--          <EditBtn title="渠道编辑" :data.sync="scope.row" :field="editField" btn_name="编辑"-->
          <!--                   v-on:update="updateData"></EditBtn>-->
          <el-button type="text" size="mini" @click.native.prevent="deleteRow(scope.row)">{{$t('page.Delete')}}
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="all_data" :output_data.sync="filter_data"></Pagination>
  </div>
</template>

<script>
  import {create, deleteRow, modify, query} from '@/api/channel'
  import Pagination from '@/components/pagination'
  import Sort from '@/components/sort'
  import EditBtn from '@/components/EditBox/index'

  export default {
    name: "index",
    components: {Pagination, Sort, EditBtn},
    data() {
      return {
        all_data: [],
        filter_data: [],
        add_data: {
          channel_type: '',
          channel_name: ''
        },
        channel_mapping: {},
        editField: [
          {
            field: 'channel_type',
            type: 'select_one',
            label: this.$t('page.Option'),
            option: this.CHANNELTYPE,
            required: true,
          }, {
            field: 'channel_name',
            type: 'input',
            label: this.$t('page.Name'),
            required: true,
          }
        ]
      }
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
      CHANNELTYPE() {
        return [
          {
            label: this.$t('page.Channel'),
            value: '1'
          }, {
            label: this.$t('page.City'),
            value: '2'
          }, {
            label: this.$t('page.Point/Media'),
            value: '3'
          }, {
            label: this.$t('page.AdvertisingSpace(online)'),
            value: '4'
          }, {
            label: this.$t('page.Activity'),
            value: '5'
          }, {
            label: this.$t('page.Offer'),
            value: '6'
          }
        ]
      }
    },
    methods: {
      updateData(data, fn) {
        let updateData = {
          channel_type: data.channel_type,
          channel_name: data.channel_name
        };
        if (data.id) {
          updateData['id'] = data.id
          modify(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        } else {
          create(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            } else {
              this.$message.error(this.$t('page.FailedToAdd'))
            }
          })
        }
      },
      getList() {
        query().then(response => {
          if (response.code === 200) {
            this.all_data = response.data;
            this.filter_data = response.data;
          }
        })
      },
      deleteRow(data) {
        this.$confirm(this.$t('page.ConfirmDeletion')).then(() => {
          let updateData = {
            id: data.id
          }

          deleteRow(updateData).then(response => {
            if (response.code === 200) {
              this.getList();
            }
          })
        }).catch(() => {
        })
      }
    },
    mounted() {
      // console.log(this.$router)
      for (let i = 0; i < this.CHANNELTYPE.length; i++) {
        this.channel_mapping[this.CHANNELTYPE[i]['value']] = this.CHANNELTYPE[i]['label']
      }
      this.editField =  [
        {
          field: 'channel_type',
          type: 'select_one',
          label: this.$t('page.Option'),
          option: this.CHANNELTYPE,
          required: true,
        }, {
          field: 'channel_name',
          type: 'input',
          label: this.$t('page.Name'),
          required: true,
        }
      ]
      this.getList();
    }
  }
</script>

<style scoped>

</style>
