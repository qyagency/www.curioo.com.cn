<template>
  <div class="app-container">
    <el-row>
      <el-col :span="6">
        <EditBtn :title="$t('page.Add')" :data.sync="add_data" :field="editField" :btn_name="$t('page.Add')"
                 v-on:update="updateData"></EditBtn>
      </el-col>
    </el-row>
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column :label="$t('page.Position')" prop="type"></el-table-column>
      <el-table-column :label="$t('page.WebPictures')" prop="web_cover">
        <template slot-scope="scope">
          <el-image :src="scope.row.web_cover[0]" style="width:100px;height:100px;" fit="contain"></el-image>
        </template>
      </el-table-column>
      <el-table-column :label="$t('page.MobilePictures')" prop="mobile_cover">
        <template slot-scope="scope">
          <el-image :src="scope.row.mobile_cover[0]" style="width:100px;height:100px;" fit="contain"></el-image>
        </template>
      </el-table-column>
      <el-table-column :label="$t('page.JumpLink')" prop="jump_url"></el-table-column>
      <el-table-column label="sort" prop="sort">
        <template slot="header" slot-scope="scope">
          <Sort :input_data.sync="filter_data" field="sort" btn_text="sort"></Sort>
        </template>
      </el-table-column>
      <el-table-column :label="$t('page.Operate')">
        <template slot-scope="scope">
          <EditBtn :title="$t('page.Edit')" :data.sync="scope.row" :field="editField" :btn_name="$t('page.Edit')"
                   v-on:update="updateData"></EditBtn>
          <el-button type="text" size="mini" @click.native.prevent="deleteRow(scope.row)">{{$t('page.Delete')}}
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="all_data" :output_data.sync="filter_data"></Pagination>
  </div>
</template>

<script>
  import {create, deleteRow, modify, query} from '@/api/banner'
  import Pagination from '@/components/pagination'
  import Sort from '@/components/sort'
  import EditBtn from '@/components/EditBox/index'

  export default {
    name: "index",
    components: {Pagination, Sort, EditBtn},
    data() {
      return {
        all_data: [],
        filter_data: [],
        add_data: {
          web_cover: [],
          mobile_cover: [],
          jump_url: '',
          sort: 1
        },
        editField: [
          {
            field: 'type',
            type: 'select_one',
            label: this.$t('page.Position'),
            required: true,
            option: [
              {
                label: 'home',
                value: 'home'
              }, {
                label: 'franchise',
                value: 'franchise'
              }
            ]
          }, {
            field: 'web_cover',
            type: 'image',
            label: this.$t('page.WebPictures'),
            required: true,
            limit: 1,
            tip: this.$t('page.RecommendedSize') + ':1920x830',
            toOss: false
          }, {
            field: 'mobile_cover',
            type: 'image',
            label: this.$t('page.MobilePictures'),
            required: true,
            limit: 1,
            tip: this.$t('page.RecommendedSize') + ':750x868',
            toOss: false
          }, {
            field: 'jump_url',
            type: 'input',
            label: this.$t('page.JumpLink')
          }, {
            field: 'sort',
            type: 'number',
            label: 'sort',
            required: true
          }
        ]
      }
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
    methods: {
      updateData(data, fn) {
        let updateData = {
          web_cover: data.web_cover.join(','),
          mobile_cover: data.mobile_cover.join(','),
          jump_url: data.jump_url,
          type: data.type,
          sort: data.sort
        };
        if (data.id) {
          updateData['id'] = data.id
          modify(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        } else {
          create(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        }
      },
      getList() {
        query().then(response => {
          // console.log(response)
          if (response.code === 200) {
            this.all_data = response.data;
            this.filter_data = response.data;
          }
        })
      },
      deleteRow(data) {
        this.$confirm(this.$t('page.ConfirmDeletion')).then(() => {
          let updateData = {
            id: data.id
          }

          deleteRow(updateData).then(response => {
            if (response.code === 200) {
              this.getList();
            }
          })
        }).catch(() => {
        })
      }
    },
    mounted() {
      this.getList();
    }
  }
</script>

<style scoped>

</style>
