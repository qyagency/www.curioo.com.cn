<template>
  <div class="app-container">
    <el-row>
      <el-col :span="6">
        <EditBtn :title="$t('page.Add')" :data.sync="add_data" :field="editField" :btn_name="$t('page.Add')"
                 v-on:update="updateData"></EditBtn>
      </el-col>
    </el-row>
    <el-table :data="filter_data" :height="tableHeight">
      <el-table-column :label="$t('page.Title')" prop="title"></el-table-column>
      <el-table-column :label="$t('page.GradeType')" prop="grade_type">
        <template slot-scope="scope">
          {{scope.row.grade_type}}
        </template>
      </el-table-column>

      <el-table-column :label="$t('page.Operate')">
        <template slot-scope="scope">
          <EditBtn :title="$t('page.Edit')" :data.sync="scope.row" :field="editField" :btn_name="$t('page.Edit')"
                   v-on:update="updateData"></EditBtn>
          <el-button type="text" size="mini" @click.native.prevent="deleteRow(scope.row)">{{$t('page.Delete')}}</el-button>
        </template>
      </el-table-column>
    </el-table>
    <Pagination :input_data.sync="all_data" :output_data.sync="filter_data"></Pagination>
  </div>
</template>

<script>
  import {create,deleteRow,modify,query,getOptions} from '@/api/grade'
  import Pagination from '@/components/pagination'
  import Sort from '@/components/sort'
  import EditBtn from '@/components/EditBox/index'

  export default {
    name: "index",
    components: {Pagination, Sort, EditBtn},
    data() {
      return {
        all_data: [],
        filter_data: [],
        add_data: {
          certification: [],
          icon:[],
          type:'',
          title:'',
          sub_title:'',
          grade:'',
          age:'',
          course_objectives:'',
          english_communication:'',
          technology:'',
          entrepreneur:'',
          creative_design:'',
          sort: 1
        },

        editField: [
          {
            field: 'grade_type',
            type: 'select_one',
            label: this.$t('page.GradeType'),
            // required: true,
            option:[
              {label:'kd1',value:'kd1'},
              {label:'kd2',value:'kd2'},
              {label:'1',value:'1'},
              {label:'2',value:'2'},
              {label:'3',value:'3'},
              {label:'4',value:'4'},
              {label:'5',value:'5'},
              {label:'6',value:'6'},
            ]
          },{
            field: 'grade',
            type:'input',
            label:this.$t('page.grade'),
            // required: true,
          },{
            field: 'title',
            type:'input',
            label:this.$t('page.Title'),
            // required: true,
          }, {
            field: 'age',
            type:'input',
            label:this.$t('page.Age'),
            // required: true,
          },{
            field: 'course_objectives',
            type:'textarea',
            label:this.$t('page.CourseObjectives'),
            // required: true,
          }, {
            field: 'sub_title',
            type:'input',
            label:this.$t('page.SubTitle'),
          },{
            field: 'line1_0',
            type:'input',
            label:this.$t('page.line1_0'),
            // required: true,
          },{
            field: 'line1_1',
            type:'textarea',
            label:this.$t('page.line1_1'),
            // required: true,
          },{
            field: 'line2_0',
            type:'input',
            label:this.$t('page.line2_0'),
            // required: true,
          },{
            field: 'line2_1',
            type:'textarea',
            label:this.$t('page.line2_1'),
            // required: true,
          },{
            field: 'line3_0',
            type:'input',
            label:this.$t('page.line3_0'),
            // required: true,
          },{
            field: 'line3_1',
            type:'textarea',
            label:this.$t('page.line3_1'),
            // required: true,
          },{
            field: 'line4_0',
            type:'input',
            label:this.$t('page.line4_0'),
            // required: true,
          },{
            field: 'line4_1',
            type:'textarea',
            label:this.$t('page.line4_1'),
            // required: true,
          },{
            field: 'icon',
            type: 'image',
            label: this.$t('page.icon'),
            required: true,
            limit: 1,
            tip: this.$t('page.RecommendedSize') + ':230x343',
            toOss: false
          }, {
            field: 'certification',
            type: 'image',
            label: this.$t('page.Certificate'),
            required: true,
            limit: 100,
            tip: this.$t('page.RecommendedSize')+':440x650',
            toOss: false
          }
        ]
      }
    },
    computed: {
      tableHeight() {
        return window.innerHeight * 0.8
      },
    },
    methods: {
      updateData(data, fn) {
        let updateData = {
          certification: data.certification.join(','),
          grade_type:data.grade_type,
          grade:data.grade,
          icon:data.icon.join(','),
          title:data.title,
          sub_title:data.sub_title,
          age:data.age,
          course_objectives:data.course_objectives,
          line1_0:data.line1_0,
          line1_1:data.line1_1,
          line2_0:data.line2_0,
          line2_1:data.line2_1,
          line2_2:data.line2_2,
          line2_3:data.line2_3,
          line3_0:data.line3_0,
          line3_1:data.line3_1,
          line3_2:data.line3_2,
          line3_3:data.line3_3,
          line4_0:data.line4_0,
          line4_1:data.line4_1,
          line4_2:data.line4_2,
          line4_3:data.line4_3,
        };
        if (data.id) {
          updateData['id'] = data.id
          modify(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        } else {
          create(updateData).then(response => {
            console.log(response)
            if (response.code === 200) {
              fn();
              this.getList();
            }
          })
        }
      },
      getList() {
        query().then(response => {
          // console.log(response)
          if (response.code === 200) {
            this.all_data = response.data;
            this.filter_data = response.data;
          }
        })
      },
      deleteRow(data) {
        this.$confirm(this.$t('page.ConfirmDeletion')).then(() => {
          let updateData = {
            id: data.id
          }

          deleteRow(updateData).then(response => {
            if (response.code === 200) {
              this.getList();
            }
          })
        }).catch(() => {
        })
      },
      getOption(){
        getOptions().then(response=>{
          if(response.code===200){
            let data = response.data;
            for(let i=0;i<this.editField.length;i++){
              if(this.editField[i]['field']==='type'){
                this.editField[i]['option'] =data;
              }
            }
            this.getList();

          }
        })
      }
    },
    mounted() {
      this.getOption();
    }
  }
</script>

<style scoped>

</style>
