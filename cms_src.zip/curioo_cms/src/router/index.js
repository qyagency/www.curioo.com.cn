import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'
import Layout2 from '@/layout2'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      name: 'Dashboard',
      component: () => import('@/views/dashboard/index'),
      meta: {title: 'router.curiooManagement', icon: 'dashboard'}
    }]
  },
]
export const asyncRoutes = [
  {
    path: '/customer',
    component: Layout,
    redirect: '/customer',
    meta: {title: 'router.customer', roles: 'customer'},
    children: [
      {
        path: 'customer',
        name: 'customer',
        component: () => import('@/views/customer/index'),
        meta: {title: 'router.customer', icon: 'kehu', roles: 'customer'}
      },
    ]
  },
  {
    path: '/customer/overseas_index',
    component: Layout,
    redirect: '/customer/overseas_index',
    meta: {title: 'router.overseasCustomer', roles: 'overseasCustomer'},
    children: [
      {
        path: 'customer/overseas_index',
        name: 'overseas customer',
        component: () => import('@/views/customer/overseas_index'),
        meta: {title: 'router.overseasCustomer', icon: 'kehu', roles: 'overseasCustomer'}
      },
    ]
  },
  {
    path: '/activity',
    component: Layout,
    redirect: '/activity',
    meta: {title: 'router.baseInformation', icon: 'activity', roles: 'activity'},
    children: [
      {
        path:'channel',
        name:'选项管理',
        component:()=>import('@/views/activity/channel'),
        meta:{title:'router.OptionManagement',icon:'qudao',roles:'channel'}
      },{
        path:'base_url',
        name:'活动链接',
        component:()=>import('@/views/activity/base_url'),
        meta:{title:'router.ActiveLink',icon:'lianjie',roles:'base_url'}
      },
      {
        path: 'area',
        name: '地区管理',
        component: () => import('@/views/area_mgt/area'),
        meta: {title: 'router.DistrictManagement', icon: 'diqu', roles: 'area'}
      },{
        path: 'store_info',
        name: '门店管理',
        component: () => import('@/views/area_mgt/store_info'),
        meta: {title: 'router.StoreManagement', icon: 'mendian_1', roles: 'store_info'}
      }
    ]
  },
  {
    path: '/activity_online',
    component: Layout,
    redirect: '/activity_online',
    meta: {title: 'router.OnlineEventManagement', icon: 'mendian',roles: 'activity_online'},
    children: [
      {
        path:'activity',
        name:'线上活动管理',
        component:()=>import('@/views/activity/activity'),
        meta:{title:'router.OnlineEventManagement',icon:'activity',roles:'activity_mgt'}
      }

    ]
  },
  {
    path: '/area_mgt',
    component: Layout,
    redirect: '/area_mgt',
    meta: {title: 'router.GroundPusher', icon: 'mendian',roles: 'area_mgt'},
    children: [
      {
        path: 'staff',
        name: '地推人员',
        component: () => import('@/views/staff/index'),
        meta: {title: 'router.GroundPusher', icon: 'xiaoshou', roles: 'staff'}
      },

    ]
  },
  {
    path: '/website',
    component: Layout,
    redirect: '/website',
    meta: {title: 'router.OfficialWebsiteManagement',icon: 'banner', roles: 'banner'},
    children: [
      {
        path: 'banner',
        name: '首页KV',
        component: () => import('@/views/banner/index'),
        meta: {title: 'router.HomeKV', icon: 'banner', roles: 'banner'}
      },
      {
        path: 'grade',
        name: 'grade',
        component: () => import('@/views/grade/index'),
        meta: {title: 'router.GradeSchedule', icon: 'grade', roles: 'grade'}
      },
      {
        path: '/studio',
        component: Layout2,
        redirect: '/studio',
        meta: {title: 'router.StudyHall', icon: '1studio', roles: 'studio'},
        children: [
          {
            path: 'studio',
            name: 'studio管理',
            component: () => import('@/views/studio/index'),
            meta: {title: 'router.HomeStudyHall', icon: 'image', roles: 'studio'}
          },
          {
            path: 'studioLocation',
            name: 'studioLocation管理',
            component: () => import('@/views/studiolocation/index'),
            meta: {title: 'router.SearchStudyHall', icon: 'ionc--', roles: 'studio'}
          },
        ]
      },
      {
        path: 'news',
        name: 'news管理',
        component: () => import('@/views/news/index'),
        meta: {title: 'router.News', icon: 'news', roles: 'news'}
      },
      {
        path: 'curioonline',
        name: 'curioonline管理',
        component: () => import('@/views/curioonline/index'),
        meta: {title: 'router.OnlineClassroom', icon: 'On-line', roles: 'curioonline'}
      },
      {
        path: 'shinningstar',
        name: 'shinningstar管理',
        component: () => import('@/views/shinningstar/index'),
        meta: {title: 'router.CoolBoyStar', icon: 'star', roles: 'shinningstar'}
      },
      {
        path: 'career',
        name: 'career管理',
        component: () => import('@/views/career/index'),
        meta: {title: 'router.Position', icon: 'career-position', roles: 'career'}
      },
      {
        path: 'email',
        name: 'email',
        component: () => import('@/views/other_form/email'),
        meta: {title: 'router.InformationSubscribe', icon: 'email', roles: 'email'}
      },
    ]
  },
  {
    path: '/other_form',
    component: Layout,
    redirect: '/other_form',
    meta: {title: 'router.Partner', icon: 'form', roles: 'other_form'},
    children: [
      {
        path: 'career_form',
        name: 'career_form',
        component: () => import('@/views/other_form/career_form'),
        meta: {title: 'router.Recruitment', icon: 'zhiye', roles: 'career_form'}
      },
      {
        path: 'user_franchise',
        name: 'user_franchise',
        component: () => import('@/views/other_form/user_franchise'),
        meta: {title: 'router.JoinInCooperation', icon: 'jiameng', roles: 'user_franchise'}
      },
    ]
  },
  {
    path: '/admin',
    component: Layout,
    redirect: '/admin',
    meta: {title: 'router.Administrators',icon: 'guanliyuan', roles: 'admin'},
    children: [
      {
        path: 'admin',
        name: '账号管理',
        component: () => import('@/views/admin/index'),
        meta: {title: 'router.AccountManagement', icon: 'admin', roles: 'admin'}
      },{
        path: 'role_list',
        name: '角色管理',
        component: () => import('@/views/admin/role_list'),
        meta: {title: 'router.RoleManagement', icon: 'jiaose', roles: 'role_list'}
      },
    ]
  },

]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  mode: 'hash',
  scrollBehavior: () => ({y: 0}),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
