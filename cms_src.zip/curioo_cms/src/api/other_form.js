import https from '@/utils/https'
import Global from '@/api/global_variable'

/**
 *
 */
export function career_form() {
  return https.get(Global.ROOT_URL + '/OtherForm/careerForm')
}
export function email() {
  return https.get(Global.ROOT_URL + '/OtherForm/email')
}
export function franchise() {
  return https.get(Global.ROOT_URL + '/OtherForm/franchise')
}
