
let ROOT_URL = 'https://www.curioo.com.cn/backend';

console.log(window.location.href);

if(window.location.href.indexOf('localhost')!==-1){
  ROOT_URL = 'http://curiootest.com';
}
if(window.location.href.indexOf('cms-curioo.incker.com')!==-1){
  ROOT_URL = 'http://cms-curioo.incker.com';
  // ROOT_URL = 'http://nike-hr-http.incker.com';
}

// const ROOT_URL = 'http://editor.com:8180';
const OSS_URL = 'https://ressl.incker.com';
export default {ROOT_URL,OSS_URL};
