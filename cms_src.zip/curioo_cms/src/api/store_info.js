import https from '@/utils/https'
import Global from '@/api/global_variable'

/**
 * create
 */
export function create(data) {
  return https.post(Global.ROOT_URL + '/StoreInfo/create',data)
}
/**
 * delete
 */
export function deleteRow(data) {
  return https.post(Global.ROOT_URL + '/StoreInfo/delete',data)
}
/**
 * modify
 */
export function modify(data) {
  return https.post(Global.ROOT_URL + '/StoreInfo/modify',data)
}
/**
 * query
 */
export function query() {
  return https.get(Global.ROOT_URL + '/StoreInfo/query')
}
/**
 * 获取地区option
 */
export function getOptions() {
  return https.get(Global.ROOT_URL + '/StoreInfo/getOptions')
}
/**
 * 获取地区option
 */
export function getStoreOptions() {
  return https.get(Global.ROOT_URL + '/StoreInfo/getStoreOptions')
}
