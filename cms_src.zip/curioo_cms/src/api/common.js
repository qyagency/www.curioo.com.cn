import https from '@/utils/https'
import Global from '@/api/global_variable'

/**
 * 上传图片
 */
export function uploadImg(data) {
  return https.file(Global.ROOT_URL + '/UploadImg/uploadImg', data)
}

