import https from '@/utils/https'
import Global from '@/api/global_variable'


/**
 * modify
 */
export function modify(data) {
  return https.post(Global.ROOT_URL + '/Staff/modify', data)
}

/**
 * query
 */
export function query(data) {
  return https.post(Global.ROOT_URL + '/Staff/query', data)
}

/**
 * change store id
 */
export function changeStoreId(data) {
  return https.post(Global.ROOT_URL + '/Staff/changeStoreId', data)
}

/**
 * change store id
 */
export function changeActivityId(data) {
  return https.post(Global.ROOT_URL + '/Staff/changeActivityId', data)
}

/**
 * 获取option参数
 */
export function getOptions() {
  return https.get(Global.ROOT_URL + "/Staff/getOptions")
}

/**
 * 修改渠道参数
 */
export function channelChange(data) {
  return https.post(Global.ROOT_URL + "/Staff/channelChange", data)
}

