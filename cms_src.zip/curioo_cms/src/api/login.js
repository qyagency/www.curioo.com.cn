import https from '@/utils/https'
import Global from '@/api/global_variable'

/**
 * 登录
 */
export function login(data) {
  return https.post(Global.ROOT_URL + '/Login/login', data)
  // return https.post(Global.ROOT_URL + '/BackEndApi/login', data)
}

/**
 *
 */
export function getUserInfo() {
  return https.get(Global.ROOT_URL + '/login/getUserInfo')
}
