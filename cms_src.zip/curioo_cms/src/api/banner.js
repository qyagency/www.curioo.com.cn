import https from '@/utils/https'
import Global from '@/api/global_variable'

/**
 * create
 */
export function create(data) {
  return https.post(Global.ROOT_URL + '/Banner/create',data)
}
/**
 * delete
 */
export function deleteRow(data) {
  return https.post(Global.ROOT_URL + '/Banner/delete',data)
}
/**
 * modify
 */
export function modify(data) {
  return https.post(Global.ROOT_URL + '/Banner/modify',data)
}
/**
 * query
 */
export function query() {
  return https.get(Global.ROOT_URL + '/Banner/query')
}
