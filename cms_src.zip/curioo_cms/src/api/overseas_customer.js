import https from '@/utils/https'
import Global from '@/api/global_variable'

/**
 * query
 */
export function query() {
  return https.get(Global.ROOT_URL + '/OverseasCustomer/query')
}

