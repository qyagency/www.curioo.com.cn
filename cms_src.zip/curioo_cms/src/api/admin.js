import https from '@/utils/https'
import Global from '@/api/global_variable'

/**
 * 更新权限
 */
export function updateRoleList(data) {
  return https.post(Global.ROOT_URL + '/Admin/updateRoleList', data)
}

/**
 * 获取权限
 */
export function getRoleList() {
  return https.get(Global.ROOT_URL + '/Admin/getRoleList')
}
/**
 * 获取权限
 */
export function getRoleForSelect() {
  return https.get(Global.ROOT_URL + '/Admin/getRoleForSelect')
}

/**
 * 用户更新权限
 */
export function updateRoles(data) {
  return https.post(Global.ROOT_URL + '/Admin/updateRoles', data)
}
/**
 * 用户更新权限
 */
export function updateUserRole(data) {
  return https.post(Global.ROOT_URL + '/Admin/updateUserRole', data)
}

/**
 * 获取用户列表
 */
export function getAdminAccountList() {
  return https.get(Global.ROOT_URL + '/Admin/getAdminAccountList')
}

/**
 * 新增用户
 */
export function createAdminAccount(data) {
  return https.post(Global.ROOT_URL + '/Admin/createAdminAccount', data)
}

/**
 * 删除用户
 */
export function deleteAdminAccount(data) {
  return https.post(Global.ROOT_URL + '/Admin/deleteAdminAccount', data)
}

/**
 * 修改密码
 */
export function changePassword(data) {
  return https.post(Global.ROOT_URL + '/Admin/changePassword', data)
}
