import https from '@/utils/https'
import Global from '@/api/global_variable'

/**
 * create
 */
export function create(data) {
  return https.post(Global.ROOT_URL + '/Customer/create',data)
}
/**
 * delete
 */
export function deleteRow(data) {
  return https.post(Global.ROOT_URL + '/Customer/delete',data)
}
/**
 * modify
 */
export function modify(data) {
  return https.post(Global.ROOT_URL + '/Customer/modify',data)
}
/**
 * query
 */
export function query() {
  return https.get(Global.ROOT_URL + '/Customer/query')
}

/**
 * change rate
 */
export function changeRate(data) {
  return https.post(Global.ROOT_URL+'/Customer/changeRate',data)
}

/**
 * change rate
 */
export function changeRemark(data) {
  return https.post(Global.ROOT_URL+'/Customer/changeRemark',data)
}
