import https from '@/utils/https'
import Global from '@/api/global_variable'

/**
 * create
 */
export function create(data) {
  return https.post(Global.ROOT_URL + '/ChannelGeneral/create',data)
}
/**
 * delete
 */
export function deleteRow(data) {
  return https.post(Global.ROOT_URL + '/ChannelGeneral/delete',data)
}
/**
 * modify
 */
export function modify(data) {
  return https.post(Global.ROOT_URL + '/ChannelGeneral/modify',data)
}
/**
 * query
 */
export function query() {
  return https.get(Global.ROOT_URL + '/ChannelGeneral/query')
}

/**
 * 获取可供选择的渠道
 */
export function channel_option() {
  return https.get(Global.ROOT_URL + '/ChannelGeneral/channel_option')

}
