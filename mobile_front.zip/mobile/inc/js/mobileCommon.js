ROOT_URL='./inc'
var UID= _getCookie('uid');
if (!UID) {
    UID = new Date().getTime() + Math.floor((1000 + Math.random() * 9000));
    _setCookie('uid', UID, Math.pow(999, 2))
}
new Jdate({
    el: '#pop_date',
    format: 'YYYY-MM-DD',
    beginYear: 1900,
    endYear: 2100
})

/**
 * 设置cookieId
 */
function _setCookie(c_name, value, expiredays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + expiredays);
    document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString()) + ";path=/;"
};
var channel;
channel = getUrlParam('channel')
if(!channel){
    channel = _getCookie('channel')
}
_setCookie('channel', channel, Math.pow(999, 2))
/**
 * 获取cookieId
 */
function _getCookie(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) {
                c_end = document.cookie.length;
            }
            return unescape(document.cookie.substring(c_start, c_end));
        }
    }
    return "";
};
$('.toForm').click(function(){

    $('#pop_form').removeClass('disNone')
    $('.form_all').removeClass('disNone')
    $('.success_pop').addClass('disNone')
    $('#pop_forward').addClass('disNone')
    $('.lastThank').addClass('disNone')
   /* draw1(show_num1)*/
})
$('.close_pop').click(function(){
    $('#pop_form').addClass('disNone')
})
function getUrlParam(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)"); //构造一个含有目标参数的正则表达式对象
    var r = window.location.search.substr(1).match(reg); //匹配目标参数
    if (r != null) return (r[2]);
    return null; //返回参数值
};
function regphone(str) {//电话号码
    var reg = /^1\d{10}$/;
    if (reg.test(str)) {
        return true;
    } else {
        return false;
    }
}
// 菜单
var isCloseEn = true,isClose = true;
$('.menu_big_xia_en').click(function () {
    if(isCloseEn){
        isCloseEn = false
        $('.menu_small').animate({
            'height':'207px'
        },300)
    }else{
        isCloseEn = true
        $('.menu_small').animate({
            'height':'0px'
        },300)
    }

})
$('.menu_big_xia').click(function () {
    if(isClose){
        isClose = false
        $('.menu_small').animate({
            'height':'207px'
        },500)
    }else{
        isClose = true
        $('.menu_small').animate({
            'height':'0px'
        },500)
    }

})
$('.menu').click(function(){
    $('#menu_pop').removeClass('disNone')
    $('#menu_box').animate({
        'height':'942px'
    },300,function () {
        $('.closeMenu').removeClass('disNone')
    })
})
$('#menu_pop .cover').click(function(){
    $('.closeMenu').addClass('disNone')
    $('#menu_box').animate({
        'height':'0px'
    },300,function(){
        $('#menu_pop').addClass('disNone')
    })
});
$('.closeMenu').click(function(){
    $('.closeMenu').addClass('disNone')
    $('#menu_box').animate({
        'height':'0px'
    },300,function(){
        $('#menu_pop').addClass('disNone')
    })
})
var indexUid,errorTxt1='',cityData={
    CHINA:['Hong Kong '],
    MALAYSIA:['Kuala Lumpur'],
    OTHER:['OTHER']
};
// $('#d_country').change(function(){
//     $('#d_province').html('')
//     $('#d_province').append("<option>City</option>")
//     if($('#d_country').val()=='CHINA'){
//         for(var i=0;i<cityData['CHINA'].length;i++){
//             $('#d_province').append("<option>"+cityData['CHINA'][i]+"</option>")
//         }
//     }else if($('#d_country').val()=='MALAYSIA'){
//         for(var i=0;i<cityData['MALAYSIA'].length;i++){
//             $('#d_province').append("<option>"+cityData['MALAYSIA'][i]+"</option>")
//         }
//     }else if($('#d_country').val()=='OTHER'){
//         for(var i=0;i<cityData['MALAYSIA'].length;i++){
//             $('#d_province').append("<option>"+cityData['OTHER'][i]+"</option>")
//         }
//     }
// })
$.ajax({
    url: 'https://www.curioo.com.cn/backend/StudioWeb/studioLocation',
    type: 'post',
    data: {
        uid: UID,
        lang: 'en',
    },
    success: function (res) {
        var countryData=[];
        for(var c in res.data){
            countryData[c] = [];
            for(var b =0;b<res.data[c].length;b++){
                if (countryData[c].indexOf(res.data[c][b].filter_city) < 0) {
                    console.log('in')
                    countryData[c].push(res.data[c][b].filter_city)
                }
            }
        }
        if (countryData) {
            for(var c in countryData){
                $('#d_country').append("<option>" + c + "</option>")
            }

        }
        $('#d_country').append("<option>" + "OTHER" + "</option>")

        $('#d_country').change(function () {
            $('#d_province').html('')
            $('#d_province').append("<option>City</option>")
            var cityData = countryData[$('#d_country').val()]
            if (cityData) {
                for (var a = 0; a < cityData.length; a++) {
                    $('#d_province').append("<option>" + cityData[a] + "</option>")
                }
            }
            $('#d_province').append("<option>" + "OTHER" + "</option>")


        })

    }
})

 var erroeTxt1=''
$('.pop_sub').click(function(){
    /*var num = show_num1.join("");*/
    if ($('#connect_name').val() == '') {
        errorTxt1 = 'Please entry your name'
    }
    if ($('#connect_birth').val() == '') {
        errorTxt1 = errorTxt1 + '\n Please entry your Child Date of Birth'
    }
    if ($('#d_country').val() == 'Country') {
        errorTxt1 = errorTxt1 + '\n Please choose  your Country'
    }
    if ($('#d_province').val() == 'City') {
        errorTxt1 = errorTxt1 + '\n Please choose your City '
    }
    if ($('#connect_mobile').val() == '') {
        errorTxt1 = errorTxt1 + '\n Please choose your Contact Number '
    }
    if ($('#connect_email').val() == '') {
        errorTxt1 = errorTxt1 + '\n Please choose your Contact Email'
    }
    if(errorTxt1 ==''){
        $.ajax({
            url: 'https://www.curioo.com.cn/backend/WebApi/guestFormEn',
            type: 'post',
            data: {
                uid:UID,
                parent_name: $('#connect_name').val(),
                child_birth: $('#connect_birth').val(),
                user_country: $('#d_country').val(),
                user_city: $('#d_province').val(),
                user_mobile: $('#connect_mobile').val(),
                user_email: $('#connect_email').val(),
                channel:channel

            },
            success: function (res) {
                indexUid = res.uid
                $('.form_all').addClass('disNone');
                $('.success_pop').removeClass('disNone')
            },
            error: function () {

            }
        });
    }else {
       alert(errorTxt1)
        erroeTxt1 = ''
        return;
    }
})
$('.bookNow').click(function(){
    $('.success_pop').addClass('disNone')
    $('#pop_forward').removeClass('disNone')

})
$('.pop_submit').click(function(){
    errorTxt1=''
    if( $('#pop_date').val()==''){
        errorTxt1 = errorTxt1 + '\n Please choose  date'
    }
    if( $('#pop_time').val()==''){
        errorTxt1 = errorTxt1 + '\n Please choose  time'
    }
    if(errorTxt1==''){
        $.ajax({
            url: 'https://www.curioo.com.cn/backend/WebApi/makeAppointmentEn',
            type: 'post',
            data: {
                uid: indexUid,
                city:$('#d_city').val(),
                subscribe_date: $('#pop_date').val(),
                subscribe_time: $('#pop_time').val(),
                channel: channel ? channel : '47dbfef43a111dd0'
            },
            success: function (res) {
                $('#pop_forward').addClass('disNone')
                $('.lastThank').removeClass('disNone')

            },
            error: function () {

            }
        })
    }else{
        alert(errorTxt1)
        return;
    }
}),

$('.sub_email').click(function(){
    if($('.input_email').val()==''){
        alert('please enter email')
        return
    }else{
        $.ajax({
            url: 'https://www.curioo.com.cn/backend/WebApi/email',
            type: 'post',
            data: {
                uid:UID,
                email:$('.input_email').val(),
                channel:channel

            },
            success: function (res) {
                $('#success_pop').removeClass('disNone')
            },
            error: function () {

            }
        });

    }
})
$('.thank_close').click(function(){
    $('#success_pop').addClass('disNone')
})

//选择年级
var lastId =1,arr=[
    {
        x:47,
        y:100,
        name:'KD1'
    },{
        x:111,
        y:134,
        name:'KD2'
    },{
        x:191,
        y:100,
        name:'1'
    },{
        x:267,
        y:135,
        name:'2'
    },{
        x:334,
        y:162,
        name:'3'
    },{
        x:403,
        y:137,
        name:'4'
    },{
        x:478,
        y:109,
        name:'5'
    },{
        x:545,
        y:137,
        name:'6'
    }],chooseId = 1;

$('.grade_num').removeClass('disNone')
$('.n1').eq(0).removeClass('down').addClass('up')
$('.n1').eq(0).find('.a1').addClass('a1Ac')
$('.n1').eq(0).find('.a1').html('')
$('.n1').eq(0).find('.a2').addClass('a2Ac')
$('.n1').eq(0).find('.a3').addClass('a3Ac')
$('.n1').click(function(){
    $('.grade_num').removeClass('disNone')
    var a = $(this).data('num');
    chooseId = $(this).data('num')
    $('.grade_num').html(arr[a-1].name)
    $('.grade_num').css({
        'left':arr[a-1].x+'px',
        'top':arr[a-1].y+'px'
    })
    if(lastId){
        $('.n1').eq(lastId-1).find('.a1').html(arr[lastId-1].name)
    }
    $('.n1').eq(lastId-1).removeClass('up').addClass('down')
    $('.n1').eq(lastId-1).find('.a1').removeClass('a1Ac')
    $('.n1').eq(lastId-1).find('.a2').removeClass('a2Ac')
    $('.n1').eq(lastId-1).find('.a3').removeClass('a3Ac')
    $(this).removeClass('down').addClass('up')
    lastId =$(this).data('num');
    $(this).find('.a1').addClass('a1Ac')
    $(this).find('.a1').html('')
    $(this).find('.a2').addClass('a2Ac')
    $(this).find('.a3').addClass('a3Ac')
})
$('.grade_num').click(function(){
    window.location.href='gradeEn.html?chooseId='+chooseId
})
$('.bottomBox').load('./inc/layout/bottom.html');

var show_num1 = [];
/*draw1(show_num1);*/
/*function dj1(){
    draw1(show_num1);
}*/
/*function draw1(show_num) {
    var canvas_width=document.getElementById('canvas1').clientWidth;
    var canvas_height=document.getElementById('canvas1').clientHeight;
    var canvas = document.getElementById("canvas1");//获取到canvas的对象，演员
    var context = canvas.getContext("2d");//获取到canvas画图的环境，演员表演的舞台
    canvas.width = canvas_width;
    canvas.height = canvas_height;
    var sCode = "1,2,3,4,5,6,7,8,9,0";
    var aCode = sCode.split(",");
    var aLength = aCode.length;//获取到数组的长度
    for (var i = 0; i <= 3; i++) {
        var j = Math.floor(Math.random() * aLength);//获取到随机的索引值
        var deg = Math.random() * 30 * Math.PI / 180;//产生0~30之间的随机弧度
        var txt = aCode[j];//得到随机的一个内容
        show_num[i] = txt;
        var x = 10 + i * 30;//文字在canvas上的x坐标
        var y = 35 + Math.random() * 20;//文字在canvas上的y坐标
        context.font = "bold 28px 微软雅黑";


        context.translate(x, y);
        context.rotate(deg);

        context.fillStyle = randomColor();
        context.fillText(txt, 0, 0);

        context.rotate(-deg);
        context.translate(-x, -y);
    }
    for (var i = 0; i <= 5; i++) { //验证码上显示线条
        context.strokeStyle = randomColor();
        context.beginPath();
        context.moveTo(Math.random() * canvas_width, Math.random() * canvas_height);
        context.lineTo(Math.random() * canvas_width, Math.random() * canvas_height);
        context.stroke();
    }
    for (var i = 0; i <= 30; i++) { //验证码上显示小点
        context.strokeStyle = randomColor();
        context.beginPath();
        var x = Math.random() * canvas_width;
        var y = Math.random() * canvas_height;
        context.moveTo(x, y);
        context.lineTo(x + 1, y + 1);
        context.stroke();
    }
}*/
function randomColor() {//得到随机的颜色值
    var r = Math.floor(Math.random() * 256);
    var g = Math.floor(Math.random() * 256);
    var b = Math.floor(Math.random() * 256);
    return "rgb(" + r + "," + g + "," + b + ")";
}


